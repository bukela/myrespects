<div>	
	<div id="story" class="tab-pane fade in">
		<form class="campaign_update" method="POST">
			<input type="hidden" name="action" value="story_update" />
			<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
			<div class="goalt">
				<div class="goalh fix">
					<h2>Campaign Story</h2>
				</div>
				<div class="form_input_area goal-input fix">
					<textarea class="cam-str camp-sp-r" name="campaign_story" cols="1" rows="1"><?php echo stripslashes( $a_campaign['campaign_story'] . $a_campaign['campaign_story_more'] ); ?></textarea>
				</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_campaign">save</a></div>
		</form>
	</div>			
</div>