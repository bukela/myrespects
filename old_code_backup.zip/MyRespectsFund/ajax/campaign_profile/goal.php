<div>	
	<div id="goaltitle">
		<form class="campaign_update" method="POST">
			<input type="hidden" name="action" value="goal_update" />
			<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
			<div class="goalt">
				<div class="goalh fix">
					<h2>Campaign Goal &amp; Title</h2>
				</div>
				<div class="form_input_area goal-input fix">
					<label for="">Goal  <span>$</span> </label>
					<input class="form_input_field gput" type="text" name="campaign_goal" value="<?php echo number_format( $a_campaign['campaign_goal'] ); ?>">
				</div>
				<div class="form_input_area goal-input fix">
					<label for="">Title</label>
					<input class="form_input_field gput-2" type="text" name="campaign_title" value="<?php echo $a_campaign['campaign_title']; ?>" maxlength="255">
				</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_campaign">save</a></div>
		</form>
	</div>
</div>