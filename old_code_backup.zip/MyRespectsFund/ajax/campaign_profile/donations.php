<div>	
	<div class="dsdo camp">
		<div class="dthdn">
			<img src="assets/images/icon_people_group.png" alt="">
			<h2>Who Has Donated</h2> <br>
			<h2 class="dth-2">Current Supporters (667)</h2>
		</div>
		<div class="d-det load-donations">
			<!-- fill with js -->
		</div>
		<div class="sho-mr-btn fix"><a class="need_help_btn" onclick="javascript:load_more();">show more</a></div>
	</div>

</div>

<script>

var data = JSON.parse( '<?php echo json_encode( $o_cb->retrieve_donated( $a_campaign['campaign_id'] ), true ); ?>' );
data = data.data;

var current_index = 0;
var total_donations = data.length;
create_html( current_index );

function load_more() {

	current_index += 5;
	if ( total_donations < current_index ) {
		$('.need_help_btn').remove();
	}
	create_html( current_index );
	
}

function create_html( i_start ) {

	for ( i = i_start; i < ( i_start + 5 ); i++ ) {

		console.log( data[i] );

		var html = 	'<div class="single-det">' +
						'<h2><span>$'+data[i].amount+'</span> '+data[i].first_name+' '+data[i].last_name+'   <span class="twtrit">('+data[i].time+')</span></h2>' +
						'<p>'+data[i].description+'</p>' +
					'</div>';

		$('.load-donations').append( html );
	}

	$('.load-donations .single-det:first-of-type').addClass( 'frs-sing-det' );
	
}
</script>