<?php $a_gallery = $o_cb->get_campaign_gallery( $a_campaign['campaign_id'] ); ?>
<div>	
	<form id="photo_upload_form" enctype="multipart/form-data">
		<input type="hidden" name="action" value="photos_update" />
		<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
		<div id="goaltitle">
			<div class="susan-pd-img">
				<img src="<?php echo $a_campaign['main_campaign_image']; ?>" alt="">
			</div>
			<div class="dsdo addph">	
					<div class="dthdn">
						<img class="campffic" src="assets/images/camera_icon.png" alt="">
						<h2 class="camppfp">Campaign Profile Photo</h2>
					</div>
					<div class="list_funeral_right_input fix">
						<div class="list_funeral_item">
							<div class="form_input_area fix form_input_profilephto_area">
								<div class="col-sm-3">
									<label for="">Upload Photo</label>
								</div>
								<div class="col-sm-5">
									<input type="file" class="form_input_field" name="campaign_main_file" />
								</div>
								<div class="col-sm-4">
								</div>			
							</div>
						</div>
						<div class="list_funeral_item">
							<div class="form_input_area fix form_input_profilephto_area">
								<div class="col-sm-3">
									<label for="">Photo Url</label>
								</div>
								<div class="col-sm-5">
									<input class="form_input_field" type="url" name="campaign_main_url" >	
								</div>
								<div class="col-sm-4">
									<p>(Include http:// or https:// in URL)</p>
								</div>			
							</div>
						</div>
					</div>
	
					<div class="dthdn campgal-h">
						<img src="assets/images/camera_icon.png" alt="">
						<h2>Campaign Gallery</h2>
					</div>
					<div class="form_input_area fix form_input_profilephto_area">
						<div class="col-sm-3">
							<label for="">Upload Photo</label>
						</div>
						<div class="col-sm-5">
							<input class="form_input_field" type="file" name="campaign_gallery_file[]" multiple>	
						</div>
						<div class="col-sm-4">
						</div>			
					</div>
					<div class="uploadled-view fix">
						<?php foreach( $a_gallery as $i_image_id => $s_image ) { ?>
							<div class="sinup-image" id="imggal<?php echo $i_image_id; ?>">
								<input type="hidden" name="gallery[]" value="<?php echo $i_image_id; ?>" />
								<img src="<?php echo $s_image; ?>" alt="">
								<div class="cros" id="crogal<?php echo $i_image_id; ?>"> 
									<img src="assets/images/cross.jpg" alt="">
								</div>
							</div>
							<script>
								$("#crogal<?php echo $i_image_id; ?>").click(function(){
									$("#imggal<?php echo $i_image_id; ?>").hide('slow');
									$(this).hide('hide')
									$("#imggal<?php echo $i_image_id; ?>").find('input').attr('name','removed[]');
								});
							</script>
						<?php }	?>
					</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_campaign_photos">save</a></div>
		</div>
	</form>
</div>

<script type="text/javascript">
	jQuery('.ccbtn.update_campaign_photos').click(function(event){
		event.preventDefault();

        var form = $('#photo_upload_form')[0];
        var data = new FormData(form);

		$.ajax( {
			type: "POST",
		    url: "ajax/update_campaign.php",
		    data: data,
		    enctype: 'multipart/form-data',
	        processData: false,  // Important!
	        contentType: false,
	        cache: false,
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

		    	console.log( resp_obj );
			}
		});
	
	});
</script>