<div>	
	<div class="dsdo camp">
		<div class="dthdn">
			<img src="assets/images/tolkit.png" alt="">
			<h2>Campaign Toolkit</h2>
		</div>
	</div>
	<div class="dsdo camp fix">
		<div class="camp-tol-single">
			<div class="stolk-hd">
				<h4>About the Funeral or Cremation</h4>
				<p>Download a pdf on funeral planning that includes:</p>
			</div>
			<div class="tolk-ul fix">
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
			</div>
			<div class="dwnpdf fix">
				<a href="#">
					<img src="assets/images/pdf.png" alt="">
					<h2>DOWNLOAD PDF</h2>
				</a>
			</div>
		</div>
	</div>
	<div class="dsdo camp fix">
		<div class="camp-tol-single">
			<div class="stolk-hd">
				<h4>Notifying Friends &amp; Family</h4>
			</div>
			<div class="tolk-ul fix">
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
			</div>
			<div class="dwnpdf fix">
				<a href="#">
					<img src="assets/images/pdf.png" alt="">
					<h2>DOWNLOAD PDF</h2>
				</a>
			</div>
		</div>
	</div>
	<div class="dsdo camp fix">
		<div class="camp-tol-single">
			<div class="stolk-hd">
				<h4>Notifying Friends &amp; Family</h4>
			</div>
			<div class="tolk-ul fix">
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
				<div class="singl-tll">
					<ul>
						<li><a href="#">- Setup a Facebook event / page</a></li>
						<li><a href="#">- Writing an e-mail to loved ones</a></li>
						<li><a href="#">- When to post and what </a></li>
					</ul>
				</div>
			</div>
			<div class="dwnpdf fix">
				<a href="#">
					<img src="assets/images/pdf.png" alt="">
					<h2>DOWNLOAD PDF</h2>
				</a>
			</div>
		</div>
	</div>
</div>