<div>	
	<form class="campaign_update" method="POST">
		<input type="hidden" name="action" value="details_update" />
		<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
		<div class="dsdo camp">
			<div class="dthdn">
				<img src="assets/images/logo_funeral_mob.png" alt="">
				<h2>Funeral details</h2>
			</div>
		</div>
		<div class="funeral-home-info dsdo camp fix">
			<div class="content">
				<h4>Funeral Home Information</h4>
				<p id="funeral_home_name"><?php echo $a_campaign['funeral_home_name']; ?></p>
				<p id="funeral_home_address"><?php echo $a_campaign['funeral_home_address']. ', '.$a_campaign['funeral_home_city'].' '.$a_campaign['funeral_home_state'].''.$a_campaign['funeral_home_zip']; ?> <span><a href="http://maps.google.com/?q=<?php echo urlencode( $a_campaign['funeral_home_address']. ', '.$a_campaign['funeral_home_city'].' '.$a_campaign['funeral_home_state'].''.$a_campaign['funeral_home_zip'] ); ?>" target="_blank">[ MAP ]</a></span></p>
				<?php echo isset( $a_campaign['funeral_home_phone'] ) ? "<p class='remove_on_connect'>PH: {$a_campaign['funeral_home_phone']}</p>" : ''; ?>
				<?php echo isset( $a_campaign['funeral_home_fax'] ) ? "<p class='remove_on_connect'>FX: {$a_campaign['funeral_home_fax']}</p>" : ''; ?>
				<?php echo isset( $a_campaign['funeral_home_email'] ) ? "<p class='remove_on_connect'><a href='mailto:{$a_campaign['funeral_home_email']}'>{$a_campaign['funeral_home_email']}</a></p>" : ''; ?>
				<?php echo isset( $a_campaign['funeral_home_other_link'] ) ? "<p class='remove_on_connect'><a href='{$a_campaign['funeral_home_other_link']}'>{$a_campaign['funeral_home_other_link']}</a></p>" : ''; ?>
			</div>
			<div class="img">
				<img class='remove_on_connect' src="<?php echo $a_campaign['funeral_home_image']; ?>" alt="">
			</div>
		</div>
		<div class="dfr-home">
			<div class="upp uppos">
				<label for="">find a Different <br> funeral home</label>
				
				<div class="popul-in">
					<input type="hidden" class="form-control" id="funeral_home_id" name="funeral_home_id" placeholder="">
					<input type="tel" class="form_input_field gput popin" id="search_zip_code" maxlength="5" placeholder="Zip Code">
				</div>
				<button onclick="javascript:show_map();" class="do-nothing search_btn ccbtn brw">SEARCH</button>
				<div class="col-sm-12">
					<div id="map-canvas" style="display:none;width:100%;height:300px;"></div>
				</div>
			</div>
		</div>
		
		<div class="dfr-date">
			<div class="upp">
				<label for="">funeral date</label>
				<input class="form_input_field gput datepicker" name="funeral_date" type="text" data-date="<?php echo $a_campaign['funeral_date']; ?>" >
				<a class="iclai"><img src="assets/images/icon_calender.png" alt=""></a>
			</div>
		</div>
		<div class="se-btn"><a class="ccbtn update_campaign">save</a></div>
	</form>
</div>

<script type="text/javascript">

function show_map(e){
	event.preventDefault();
	$('#map-canvas').slideDown(400,function(){
		google_map_init();
		place_pins();
	});
	
}

function google_map_init(){

	map = new google.maps.Map(document.getElementById('map-canvas'), {
    	zoom: 5,
    	center: {lat: 38.9781784, lng: -100.6348431},
    	scrollwheel: false,
  	});
  	infowindow = new google.maps.InfoWindow();
  	bounds = new google.maps.LatLngBounds();
}    

function place_pins(){

	data = window.funeral_home_data;

	if ( data ) {

	    var marker, i;
	
		for ( i = 0; i < data.length; i++ ) {  
			marker = new google.maps.Marker({
				position: new google.maps.LatLng( data[i]['funeral_home_lat'], data[i]['funeral_home_lng'] ),
				map: map
			});

			bounds.extend( marker.position );
			map.fitBounds(bounds);
			map.panToBounds(bounds);

			google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
					html = 	"<div class='step_location fix'>"+
								"<p>" +
									"<span>Funeral Home:</span>" + data[i]['funeral_home_name'] + 
									"<br><span>Address:</span> "+ data[i]['funeral_home_address']+", "+data[i]['funeral_home_city']+" "+data[i]['funeral_home_state']+" "+data[i]['funeral_home_zip'] +
									"<br></span>" +
									"<button id='select-funeral-home' class='connect_btn'" +
										"data-funeral-home-id='"+data[i]['funeral_home_id']+"'" +
										"data-funeral-home-name='"+data[i]['funeral_home_name']+"'"+
										"data-funeral-home-address='"+ data[i]['funeral_home_address']+", "+data[i]['funeral_home_city']+" "+data[i]['funeral_home_state']+" "+data[i]['funeral_home_zip']+"'"+
									">Connect</button>" +
								"</p>" +
							"</div>";
					infowindow.setContent( html );
					infowindow.open(map, marker);
				}
			})(marker, i));
		}
	}
}

$("#search_zip_code").keyup(function(){

	if ( $(this).val().length != 5 ) {
		return;
	}

	$.ajax({
		type: 'POST',
		url: '/ajax/find-funeral-homes.php',
		data: { 'zip': $(this).val() },
		beforeSend:function(){},
		success:function( data ){

			data = JSON.parse( data );

			console.log( data );
			window.funeral_home_data = data;
		},	
		error:function(){}
	});

});

$('form.do-nothing').click(function(event){

});

$('form.campaign_update').on('click', '#select-funeral-home',  function(e){
	e.preventDefault();
	$('#funeral_home_id').val( $(this).data('funeral-home-id') );

	$('#funeral_home_name').text( $(this).data('funeral-home-name') );
	$('#funeral_home_address').text( $(this).data('funeral-home-address') );
	$('.remove_on_connect').remove();
});


</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRQliZkxPQ_xvpRom2CUQOzh-bSbmy5As&callback=google_map_init"></script>
