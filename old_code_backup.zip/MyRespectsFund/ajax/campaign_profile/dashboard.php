<div>
	<form id="photo_upload_form" enctype="multipart/form-data">
		<input type="hidden" name="action" value="dashboard_update" />
		<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
		<div id="home" class="tab-pane fade in active">
			<div class="dsdo camp">
				<div class="dthdn">
					<img src="/assets/images/edit-icon.png" alt="">
					<h2>Campaign Photo</h2>
				</div>
				<div class="prof-pic">
					<img src="<?php echo $a_campaign['main_campaign_image']; ?>" alt="">
					<div class="ebtn ppebtn"><a href="<?php echo $s_current_url."?page=photos" ?>" class="ccbtn">edit</a></div>
				</div>
			</div>
			<div class="dsdo campup">
				<div class="dthdn">
					<img src="/assets/images/edit-icon.png" alt="">
					<h2>Post An Update</h2>
				</div>
				<div class="form_input_area fix">
					<label class="des" for="">description</label>
					<textarea class="deshp" name="update_content" cols="0" rows="0"></textarea>

				</div>
			</div>
			<div class="dsdo addph">	
				<div class="dthdn">
					<img src="/assets/images/camera_icon.png" alt="">
					<h2>add a photo</h2>
				</div>
				<div class="list_funeral_right_input fix">
					<div class="list_funeral_item">
						<div class="form_input_area fix form_input_profilephto_area">
							<div class="col-sm-3">
								<label for="">Upload Photo</label>
							</div>
							<div class="col-sm-5">
								<input type="file" class="form_input_field" name="image" />
							</div>
						</div>
					</div>
					<div class="list_funeral_item">
						<div class="form_input_area fix form_input_profilephto_area">
							<div class="col-sm-3">
								<label for="">Photo Url</label>
							</div>
							<div class="col-sm-5">
								<input class="form_input_field" type="url" name="image_url">	
							</div>
							<div class="col-sm-4">
								<p>(Include http:// or https:// in URL)</p>
							</div>			
						</div>
					</div>
				</div>
			</div>
			<div class="dsdo addvid">	
				<div class="dthdn">
					<img src="/assets/images/video-icon.png" alt="">
					<h2>add a video</h2>
				</div>
				<div class="upp">
					<label for="">Embed code</label>
					<input class="form_input_field gput ebbed" name="video" type="text">
				</div>
				<div class="uppsocial">
				</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_campaign">save</a></div>
		</div>
	</form>
</div>