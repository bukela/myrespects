<div>
<?php $o_user->refresh_data(); ?>	
	<form class="campaign_update" method="POST">
		<input type="hidden" name="action" value="settings_update" />
		<input type="hidden" name="campaign_id" value="<?php echo $a_campaign['campaign_id']; ?>" />
		<input type="hidden" name="user_id" value="<?php echo $o_user->get_id(); ?>" />
		<div class="start_campaign_stepcontent fix">
			<div class="goalh set fix">
				<h2>Campaign Setting</h2>
			</div>
			<div class="start_campaign_formarea fix">		
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">First Name</label>
						<input class="form_input_field" type="text" name="first_name" value="<?php echo $o_user->get_first_name(); ?>" >							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Last Name</label>
						<input class="form_input_field" type="text" name="last_name" value="<?php echo $o_user->get_last_name(); ?>" >							
					</div>
				</div>
							
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Address</label>
						<input class="form_input_field" type="text" name="address" value="<?php echo $o_user->get_address(); ?>" >							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">City</label>
						<input class="form_input_field" type="text" name="city" value="<?php echo $o_user->get_city(); ?>" >							
					</div>
				</div>
							
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">State</label>
							<select name="state" class="form_select_field">
								<option>Please Select A State</option>
								<?php 
								foreach ( $STATES as $s_abbrv => $s_name ) {
									$s_selected = '';
									if ( $s_abbrv == $o_user->get_state() ) {
										$s_selected = 'selected="selected"';
									}
									echo "<option value='$s_abbrv' $s_selected >$s_name</option>";	
								}
								?>
							</select>											
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Zip / Postal Code</label>
						<input class="form_input_field" name="zip" type="text" value="<?php echo $o_user->get_zip(); ?>" >							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">E-mail</label>
						<input class="form_input_field" type="text" name="email" value="<?php echo $o_user->get_email(); ?>" >							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Phone</label>
						<input class="form_input_field" id="text" name="phone_number" type="text" value="<?php echo $o_user->get_phone_number(); ?>" data-mask="(000) 000-0000">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Date of Birth <span> MM / DD / YYYY</span></label>
						<input class="form_input_field datepicker" name="dob" type="text" data-date="<?php echo $o_user->get_dob(); ?>" >							
					</div>
				</div>		
			</div>
		</div>
		<div class="se-btn"><a class="ccbtn update_campaign">save</a></div>
	</form>
</div>