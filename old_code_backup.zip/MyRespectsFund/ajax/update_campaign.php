<?php

$s_action = explode( "_", $_POST['action'] );
$s_subaction = addslashes( $s_action[1] );
$s_action = addslashes( $s_action[0] );


include_once '../classes/campaign_base.php';
$o_cp = new campaign_base();
if ( !isset( $_POST['campaign_id'] ) ) {
	echo json_encode( array( 'status' => 'fail', 'msg' => 'No campaign selected' ), true );
	die();
}
$o_cp->set_protected_var('campaign_id', intval( $_POST['campaign_id'] ) );

switch ( $s_action ) {

	case "goal":
		
		$i_goal = preg_replace( '/\D/', '', $_POST['campaign_goal'] );
		if ( !empty( $i_goal ) && $i_goal > 0 ) {
			$o_cp->update_goal( $i_goal );
		}
		
		$s_title = substr( addslashes( $_POST['campaign_title'] ), 0, 255 );
		if ( !empty( $s_title ) ) {
			$o_cp->update_title($s_title);
		}
		
		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "photos":

		if ( isset( $_FILES['campaign_main_file'] ) && !empty( $_FILES['campaign_main_file'] ) ) {
			
			$o_cp->update_main_campaign_photo( $_POST, $_FILES['campaign_main_file'] );
			
		} elseif ( isset( $_FILES['campaign_main_url'] ) && !empty( $_FILES['campaign_main_url'] ) ) {
			
			$o_cp->update_main_campaign_photo( $_POST, array(), TRUE );
		}
		
		if ( isset( $_FILES['campaign_gallery_file'] ) && !empty( $_FILES['campaign_gallery_file'] ) ) {
				
			$o_cp->update_campaign_photos_gallery( $_POST, $_FILES['campaign_gallery_file'] );
		}

		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "story":
		
		$s_story = addslashes( $_POST['campaign_story'] );
		if ( !empty( $s_story ) ) {
			$o_cp->update_story($s_story);
		}
		
		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "settings":

		include_once '../classes/user_base.php';
		$o_user = new user_base();
		$o_user->update_user( $_POST, TRUE, intval( $_POST['user_id'] ) );
		
		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "dashboard":

		if ( isset( $_FILES ) && !empty( $_FILES ) ) {
			
			$o_cp->post_update( $_POST, $_FILES );
			
		} elseif ( isset( $_POST['image_url'] ) && !empty( $_POST['image_url'] ) ) {
			
			$o_cp->post_update( $_POST, array(), TRUE );
			
		} else {
			
			$o_cp->post_update( $_POST, array(), FALSE );
		}

		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "details":

		if ( isset( $_POST['funeral_home_id'] ) && intval( $_POST['funeral_home_id'] ) > 0 ) {
			$o_cp->update_funeral_home( $_POST['funeral_home_id'] );
		}
		
		if ( isset( $_POST['funeral_date'] ) && !empty( $_POST['funeral_date'] ) ) {
			$o_cp->update_funeral_date( $_POST['funeral_date'] );
		}
		
		echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
		break;
		
	case "withdraw":

		break;
		
	case "messages":

		require_once '../classes/message_base.php';
		$o_mb = new message_base();
		
		if ( $s_subaction == 'send' ) {
			
			
		} elseif ( $s_subaction == 'reply' ) {
			
			if ( $o_mb->reply_message( $_POST ) ) {
			
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
			
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
			
		} elseif ( $s_subaction == 'delete' ) {
			
			if ( $o_mb->delete_message( intval( $_POST['message_id'] ) ) ) {
				
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
				
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
		}
		
		break;
		
	default:
		
		echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
		
		break;
}

unset( $o_cp );