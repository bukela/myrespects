<?php

require_once __DIR__ . '/../classes/db_base.php';

$o_db = new db_base();

$o_result = $o_db->query("SELECT * FROM campaign LIMIT 8");

if( $o_result ) {
	 
}

?>