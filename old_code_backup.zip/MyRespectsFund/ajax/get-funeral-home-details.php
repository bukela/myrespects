<?php

require_once '../classes/funeral_home_base.php';

$o_fhb = new funeral_home_base();

$a_results = $o_fhb->get_details( $_POST['funeral_home_id'] );

echo json_encode( $a_results );

die();
