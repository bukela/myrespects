<?php

require_once '../classes/funeral_home_base.php';

$o_fb = new funeral_home_base();

$a_results = $o_fb->find_funeral_home_by_name( $_POST['funeral_home_name'] );

echo json_encode( $a_results );

die();

