<?php

if( $_POST['first_name'] == '' || $_POST['last_name'] == '' || $_POST['user-email'] == '' || $_POST['user-password'] == '' ) {
	echo "{\"message\": \"All fields are required.\", \"status\": \"Fail\"}";
	die();
}

if($_POST['user-email'] != $_POST['confirm_email']) {
	echo "{\"message\": \"The email addresses entered do not match.\", \"status\": \"Fail\"}";
	die();
}

require_once __DIR__ . '/../classes/user_base.php';

$o_user = new user_base();

$b_result = $o_user->login($_POST);

if( ! $b_result ) {
	echo "{\"message\": \"Something went wrong, please contact us.\", \"status\": \"Fail\"}";
	die();
}

echo "{\"message\": \"Account Created.\", \"status\": \"Success\"}";
die();