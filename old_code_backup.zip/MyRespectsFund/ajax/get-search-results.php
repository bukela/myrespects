<?php

require_once '../classes/campaign_base.php';

$o_cb = new campaign_base();

$a_results = $o_cb->get_search_results( $_POST['search_term'], $_POST['start'] );

echo json_encode( $a_results );

die();
