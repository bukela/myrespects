<?php

/*
 * DB hook to create a campaign. Currently should be called from root/create-campaign.php.
 * @todo Add validation against user session. 
 * 
 */

session_start();

$_POST['campaign_zip'] = $_POST['zip'];

require_once __DIR__ . '/../classes/campaign_base.php';
require_once __DIR__ . '/../classes/user_base.php';

$o_user = new user_base();

$result = $o_user->decode_session_string( $_POST['ss'] );

if ( isset ( $_SESSION['user_base'] ) ) {
	$o_user = unserialize( $_SESSION['user_base'] );
}

if ( !isset( $_SESSION['user_base'] ) || empty( $o_user ) ) {
	$a_result = array("status" => false, "message" => "Please sign in before starting a campaign");
	
	echo json_encode( $a_result );
	die();
}

$i_user_id = intval( $o_user->get_id() );

$o_user->update_user( $_POST );

if( $i_user_id == 0 ) {
	$a_result = array("status" => false, "message" => "No User ID" . $o_user->get_id() . "--");
	
	echo json_encode( $a_result );
	die();
}

$_POST['user_id'] = $i_user_id;

unset( $_POST['ss'] );

$o_campaign = new campaign_base();

$a_result = $o_campaign->create_campaign( $_POST, $_FILES['campaign_image'] );

echo json_encode( $a_result );
die();
?>