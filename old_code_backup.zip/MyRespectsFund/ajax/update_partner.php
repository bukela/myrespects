<?php

$s_action = explode( "_", $_POST['action'] );
$s_subaction = addslashes( $s_action[1] );
$s_action = addslashes( $s_action[0] );


include_once '../classes/funeral_home_base.php';
$o_fb = new funeral_home_base();
if ( !isset( $_POST['funeral_home_id'] ) ) {
	echo json_encode( array( 'status' => 'fail', 'msg' => 'No funeral home selected' ), true );
	die();
}
$o_fb->set_protected_var('funeral_home_id', intval( $_POST['funeral_home_id'] ) );

switch ( $s_action ) {

	
	case "messages":

		require_once '../classes/message_base.php';
		$o_mb = new message_base();
		
		if ( $s_subaction == 'send' ) {

			
			include_once '../classes/campaign_base.php';
			$o_cp = new campaign_base();
			$a_campaign = $o_cp->get_campaign_details($_POST['campaign_id']);
			$_POST['to_user'] = $a_campaign['user_id']; 
			
			if ( $o_mb->send_message( $_POST ) ) {
					
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
					
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
			
			
		} elseif ( $s_subaction == 'reply' ) {
				
			if ( $o_mb->reply_message( $_POST ) ) {
					
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
					
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
				
		} elseif ( $s_subaction == 'delete' ) {
				
			if ( $o_mb->delete_message( intval( $_POST['message_id'] ) ) ) {
		
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
		
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
		}
		
		break;
		
	case "photos":

		if ( isset( $_FILES['funeral_home_image'] ) && !empty( $_FILES['funeral_home_image'] ) ) {
				
			$o_fb->update_funeral_home_image( $_POST, $_FILES['funeral_home_image'] );
				
		} elseif ( isset( $_FILES['funeral_home_image_url'] ) && !empty( $_FILES['funeral_home_image_url'] ) ) {
			
			$o_fb->update_funeral_home_image( $_POST, array(), TRUE );
		}
		
		break;
		
	case "description":
		
		$s_description = addslashes( $_POST['funeral_home_description'] );
		if ( !empty( $s_description ) ) {
			$o_fb->update_description($s_description);
		}
		
		break;
		
	case "settings":

		$o_fb->update_funeral_home_info( $_POST );
		
		break;
		
	case "requests":

		require_once '../classes/email_base.php';
		$o_eb = new email_base();
		
		if ( $s_subaction == 'address' ) {
		
			$a_funeral_home = $o_fb->get_funeral_home_details( $_POST['funeral_home_id'] );

			$s_html = "Please send literature to my funeral home ( ".$a_funeral_home['funeral_home_name']." ) at address:<br>".$a_funeral_home['funeral_home_address']. ',<br>'.$a_funeral_home['funeral_home_city'].' '.$a_funeral_home['funeral_home_state'].''.$a_funeral_home['funeral_home_zip'];
			$s_text = "Please send literature to my funeral home ( ".$a_funeral_home['funeral_home_name']." ) at address: ".$a_funeral_home['funeral_home_address']. ', '.$a_funeral_home['funeral_home_city'].' '.$a_funeral_home['funeral_home_state'].''.$a_funeral_home['funeral_home_zip'];
			
			if ( $o_eb->send_email( 'info@myrespects.org', 'Please send literature to my address', $s_html, $s_text ) ) {
					
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
					
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
				
				
		} elseif ( $s_subaction == 'email' ) {
		
			$a_funeral_home = $o_fb->get_funeral_home_details( $_POST['funeral_home_id'] );

			$s_html = "Please send literature to my funeral home ( ".$a_funeral_home['funeral_home_name']." ) at email: ".$a_funeral_home['funeral_home_email'];
			$s_text = "Please send literature to my funeral home ( ".$a_funeral_home['funeral_home_name']." ) at email: ".$a_funeral_home['funeral_home_email'];
			
			if ( $o_eb->send_email( 'info@myrespects.org', 'Please send literature to my address', $s_html, $s_text ) ) {
					
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
					
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
		
		} else {
		
			
			$a_funeral_home = $o_fb->get_funeral_home_details( $_POST['funeral_home_id'] );

			print_r($_POST);
			
			$s_html = "Please schedule a call with my funeral home ( ".$a_funeral_home['funeral_home_name']." ):
							<br>First Name: ".$a_funeral_home['first_name']."
							<br>Last Name: ".$a_funeral_home['last_name']."
							<br>Email: ".$a_funeral_home['email']."
							<br>Phone: ".$a_funeral_home['phone']."
							<br>Best Time: ".$a_funeral_home['best_time'];
							
			$s_text = "Please schedule a call with my funeral home ( ".$a_funeral_home['funeral_home_name']." ): First Name: ".$a_funeral_home['first_name']." Last Name: ".$a_funeral_home['last_name']." Email: ".$a_funeral_home['email']." Phone: ".$a_funeral_home['phone']." Best Time: ".$a_funeral_home['best_time'];
			
			if ( $o_eb->send_email( 'info@myrespects.org', 'Please schedule a call with me', $s_html, $s_text ) ) {
					
				echo json_encode( array( 'status' => 'success', 'msg' => '' ), true );
			} else {
					
				echo json_encode( array( 'status' => 'fail', 'msg' => '' ), true );
			}
		}
		
		break;
	
}

unset( $o_cp );