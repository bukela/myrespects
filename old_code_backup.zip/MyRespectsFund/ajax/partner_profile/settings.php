<div>	
	<form>
		<input type="hidden" name="action" value="settings_update" />
		<input type="hidden" name="funeral_home_id" value="<?php echo $a_funeral_home['funeral_home_id']; ?>" />
		<div class="start_campaign_stepcontent fix">
			<div class="goalh set fix">
				<h2>Profile Settings</h2>
			</div>
			<div class="start_campaign_formarea fix">		
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Funeral Home Name</label>
						<input class="form_input_field" type="text" name="funeral_home_name" value="<?php echo $a_funeral_home['funeral_home_name']; ?>">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Website URL</label>
						<input class="form_input_field" type="text" name="funeral_home_other_link" value="<?php echo $a_funeral_home['funeral_home_other_link']; ?>">							
					</div>
				</div>	
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Contact First Name</label>
						<input class="form_input_field" type="text" name="funeral_home_contact_name" value="<?php echo $a_funeral_home['funeral_home_contact_name']; ?>">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Contact First Name</label>
						<input class="form_input_field" type="text" name="funeral_home_contact_name_last" value="<?php echo $a_funeral_home['funeral_home_contact_name_last']; ?>">							
					</div>
				</div>
				
							
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Address</label>
						<input class="form_input_field" type="text" name="funeral_home_address" value="<?php echo $a_funeral_home['funeral_home_address']; ?>">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">City</label>
						<input class="form_input_field" type="text" name="funeral_home_city" value="<?php echo $a_funeral_home['funeral_home_city']; ?>">							
					</div>
				</div>
							
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">State</label>
							<select name="funeral_home_state" class="form_select_field">
									<option>Please Select A State</option>
									<?php 
									foreach ( $STATES as $s_abbrv => $s_name ) {
										$s_selected = '';
										if ( $s_abbrv == $a_funeral_home['funeral_home_state'] ) {
											$s_selected = 'selected="selected"';
										}
										echo "<option value='$s_abbrv' $s_selected >$s_name</option>";	
									}
									?>
								</select>													
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Zip / Postal Code</label>
						<input class="form_input_field" type="text" name="funeral_home_zip" value="<?php echo $a_funeral_home['funeral_home_zip']; ?>">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">E-mail</label>
						<input class="form_input_field" type="email" name="funeral_home_email" value="<?php echo $a_funeral_home['funeral_home_email']; ?>">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Phone</label>
						<input class="form_input_field" id="datetimepicker" type="phone" name="funeral_home_phone" value="<?php echo $a_funeral_home['funeral_home_phone']; ?>">							
					</div>
				</div>
					
			</div>
		</div>
		<div class="se-btn"><a class="ccbtn update_partner">save</a></div>
	</form>
</div>