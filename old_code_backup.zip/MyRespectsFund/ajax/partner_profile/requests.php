<div>
	<div class="dsdo campup fix">
		<div class="dthdn asths">
			<h2 class="nomar">Request Literature</h2>
		</div>
		<div class="ned_help_btnrow spwith">
			<a class="need_help_btn reqlit-btn nomar" id="lit-to-address">SEND TO MY ADDRESS</a>
			<a class="need_help_btn reqlit-btn" id="lit-to-email">send to my e-mail</a>
		</div>
	</div>
	<form>
		<input type="hidden" name="action" value="requests_update" />
		<input type="hidden" name="funeral_home_id" value="<?php echo $a_funeral_home['funeral_home_id']; ?>" />
		<div class="dsdo campup fix">
			<div class="dthdn asths">
				<h2>Request A My Respects Call</h2>
			</div>
			<div class="funeral-home-info paddinnone parhomrei fix">
				<div class="content">
					<h4>Funeral Home Information</h4>
					<p id="funeral_home_name"><?php echo $a_funeral_home['funeral_home_name']; ?></p>
					<p id="funeral_home_address"><?php echo $a_funeral_home['funeral_home_address']. ', '.$a_funeral_home['funeral_home_city'].' '.$a_funeral_home['funeral_home_state'].''.$a_funeral_home['funeral_home_zip']; ?> <span><a href="http://maps.google.com/?q=<?php echo urlencode( $a_funeral_home['funeral_home_address']. ', '.$a_funeral_home['funeral_home_city'].' '.$a_funeral_home['funeral_home_state'].''.$a_funeral_home['funeral_home_zip'] ); ?>" target="_blank">[ MAP ]</a></span></p>
					<?php echo isset( $a_funeral_home['funeral_home_phone'] ) ? "<p class='remove_on_connect'>PH: {$a_funeral_home['funeral_home_phone']}</p>" : ''; ?>
					<?php echo isset( $a_funeral_home['funeral_home_fax'] ) ? "<p class='remove_on_connect'>FX: {$a_funeral_home['funeral_home_fax']}</p>" : ''; ?>
					<?php echo isset( $a_funeral_home['funeral_home_email'] ) ? "<p class='remove_on_connect'><a href='mailto:{$a_funeral_home['funeral_home_email']}'>{$a_funeral_home['funeral_home_email']}</a></p>" : ''; ?>
					<?php echo isset( $a_funeral_home['funeral_home_other_link'] ) ? "<p class='remove_on_connect'><a href='{$a_funeral_home['funeral_home_other_link']}'>{$a_funeral_home['funeral_home_other_link']}</a></p>" : ''; ?>
					
				</div>
				<div class="img">
					<img src="<?php echo $a_funeral_home['funeral_home_image']; ?>" alt="">
				</div>
			</div>
			<div class="start_campaign_formarea spmar mimar fix">		
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Contact First Name</label>
						<input class="form_input_field" type="text" name="first_name">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Contact Last Name</label>
						<input class="form_input_field" type="text" name="last_name">							
					</div>
				</div>
							
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Email</label>
						<input class="form_input_field" type="email" name="email">							
					</div>
				</div>
				<div class="step_form_input col-sm-6">
					<div class="form_input_area fix">
						<label for="">Phone</label>
						<input class="form_input_field" type="tel" name="phone">							
					</div>
				</div>
			</div>
			<div class="calchkbox">
				<p>Best Time To Call</p>
	
				<div class="box-rom">
					<div class="cheack chk-rom">
						<input name="best_time" value="morning" type="checkbox"><p>Morning</p>
						<input name="best_time" value="afternoon" type="checkbox"><p>Afternacoon</p>
						<input name="best_time" value="evening" type="checkbox"><p>Evening</p>
					</div>
				</div>
			</div>
	
			<div class="requtsgf-btn"><div class="se-btn"><a class="ccbtn req-sbtn update_partner">REQUEST</a></div></div>
		</div>
	</form>
</div>

<script type="text/javascript">
	jQuery('#lit-to-address').click(function(event){
		event.preventDefault();

		$.ajax( {
			type: "POST",
		    url: "ajax/update_partner.php",
		    data: { 'funeral_home_id' : '<?php echo $a_funeral_home['funeral_home_id']; ?>', 'action' : 'requests_address' },
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

				if(resp_obj.result == 'Success') {
					location.relaod();
				}
		    	
			}
		});
	
	});

	jQuery('#lit-to-email').click(function(event){
		event.preventDefault();

		$.ajax( {
			type: "POST",
		    url: "ajax/update_partner.php",
		    data: form_data,
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

				if(resp_obj.result == 'Success') {
					location.relaod();
				}
		    	
			}
		});
	
	});
</script>
