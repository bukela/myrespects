<div>	
	<form id="photo_upload_form" enctype="multipart/form-data">
		<input type="hidden" name="action" value="photos_update" />
		<input type="hidden" name="funeral_home_id" value="<?php echo $a_funeral_home['funeral_home_id']; ?>" />
		<div id="goaltitle">
			<div class="susan-pd-img">
				<img src="<?php echo $a_funeral_home['funeral_home_image']; ?>" alt="">
			</div>
			<div class="dsdo addph">	
					<div class="dthdn">
						<img src="assets/images/camera_icon.png" alt="">
						<h2>Partner Profile Photo</h2>
					</div>
						<div class="list_funeral_right_input fix">
						<div class="list_funeral_item">
							<div class="form_input_area fix form_input_profilephto_area">
								<div class="col-sm-3">
									<label for="">Upload Photo</label>
								</div>
								<div class="col-sm-5">
									<input class="form_input_field" type="file" name="funeral_home_image">	
								</div>
							</div>
						</div>
						<div class="list_funeral_item">
							<div class="form_input_area fix form_input_profilephto_area">
								<div class="col-sm-3">
									<label for="">Photo Url</label>
								</div>
								<div class="col-sm-5">
									<input class="form_input_field" type="url" name="funeral_home_image_url">	
								</div>
								<div class="col-sm-4">
									<p>(Include http:// or https:// in URL)</p>
								</div>			
							</div>
						</div>
					</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_partner_photos">save</a></div>
		</div>
	</form>
</div>


<script type="text/javascript">
	jQuery('.ccbtn.update_partner_photos').click(function(event){
		event.preventDefault();

        var form = $('#photo_upload_form')[0];
        var data = new FormData(form);

		$.ajax( {
			type: "POST",
		    url: "ajax/update_partner.php",
		    data: data,
		    enctype: 'multipart/form-data',
	        processData: false,  // Important!
	        contentType: false,
	        cache: false,
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

		    	console.log( resp_obj );
			}
		});
	
	});
</script>