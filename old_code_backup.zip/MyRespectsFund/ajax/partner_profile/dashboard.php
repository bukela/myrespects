<div>
	<div id="home" class="tab-pane fade in active">
			<div class="dsdo camp">
				<div class="dthdn">
					<img src="assets/images/edit-icon.png" alt="">
					<h2>Profile Photo</h2>
				</div>
				<div class="prof-pic">
					<img src="assets/images/aldous.jpg " alt="">

					<div class="ebtn ppebtn"><a href="#" class="ccbtn">edit</a></div>
				</div>
			</div>
			<div class="dsdo camp fix">
				<div class="dthdn">
					<img src="assets/images/edit-icon.png" alt="">
					<h2 class="mbfrh">Funeral Home Information</h2>
				</div>
				<div class="funhinfo-clm">
					<div class="ffhome">
						<ul>
							<li><a href="#">44 North Main Street</a></li>
							<li><a href="#">Rutland, Vermont 05701</a></li>
						</ul>
					</div>
					<div class="ffmb">
						<ul>
							<li><a href="#">PH: 802-773-6252</a></li>
							<li><a href="#">FX: 802-773-9393</a></li>
						</ul>
					</div>
				</div>
				<div class="funhinfo-clm ffweb">
					<ul>
						<li><a href="#">info@aldousfuneralhome.com</a></li>
						<li><a href="#">www.aldousfuneralhome.com</a></li>
					</ul>
				</div>
				<div class="ebtn ebtnbb frndetbb"><a href="#" class="ccbtn">edit</a></div>
			</div>

			<div class="dsdo campup">
				<div class="dthdn">
					<img src="assets/images/edit-icon.png" alt="">
					<h2>Post An Update</h2>
				</div>
				<div class="form_input_area fix">
					<label class="des" for="">description</label>
					<textarea class="deshp" name="" id="" cols="0" rows="0"></textarea>

				</div>
			</div>
			<div class="dsdo addph">	
				<div class="dthdn">
					<img src="assets/images/camera_icon.png" alt="">
					<h2>add a photo</h2>
				</div>
				<div class="list_funeral_right_input fix">
					<div class="list_funeral_item">
						<div class="form_input_area fix form_input_profilephto_area">
							<div class="col-sm-3">
								<label for="">Upload Photo</label>
							</div>
							<div class="col-sm-5">
								<input class="form_input_field" type="">	
							</div>
							<div class="col-sm-4">
								<button class="browse_btn">Browse</button>
							</div>			
						</div>
					</div>
					<div class="list_funeral_item">
						<div class="form_input_area fix form_input_profilephto_area">
							<div class="col-sm-3">
								<label for="">Photo Url</label>
							</div>
							<div class="col-sm-5">
								<input class="form_input_field" type="">	
							</div>
							<div class="col-sm-4">
								<p>(Include http:// or https:// in URL)</p>
							</div>			
						</div>
					</div>
				</div>
			</div>
			<div class="dsdo addvid">	
				<div class="dthdn">
					<img src="assets/images/video-icon.png" alt="">
					<h2>add a video</h2>
				</div>
				<div class="upp">
					<label for="">Embed code</label>
					<input class="form_input_field gput ebbed" type="text">
				</div>
			</div>
			<div class="se-btn"><a href="#" class="ccbtn">save</a></div>
		</div>
</div>