<div>	
	<form class="campaign_update" method="POST">
		<input type="hidden" name="action" value="description_update" />
		<input type="hidden" name="funeral_home_id" value="<?php echo $a_funeral_home['funeral_home_id']; ?>" />
		<div id="story" class="tab-pane fade in">
			<div class="goalt">
				<div class="goalh fix">
					<h2>Funeral Home Description</h2>
				</div>
				<div class="form_input_area goal-input fix">
					<textarea class="cam-str" name="funeral_home_description" id="" cols="1" rows="1"><?php echo stripslashes( $a_funeral_home['funeral_home_about'] ); ?></textarea>
				</div>
			</div>
			<div class="se-btn"><a class="ccbtn update_partner">save</a></div>
		</div>
	</form>			
</div>