<div>
	<div class="dsdo campup fix">
		<div class="dthdn">
			<img src="assets/images/icon_people_group.png" alt="">
			<h2>Campaigns Linked</h2>
		</div>
		<?php 
			$a_linked = $o_fb->get_linked_funds( $a_funeral_home['funeral_home_id'] ); 
			if ( !empty( $a_linked ) && is_array( $a_linked ) ) {
				foreach( $a_linked as $a_campaign ) {
					?>
						<div class="single-funr-ex fix">
							<div class="funr-ex-pic">
								<img src="<?php echo $a_campaign['main_campaign_image']; ?>" alt="">
							</div>
							<div class="funr-ex-con">
								<h3>Fundraising for <?php echo $a_campaign['campaign_title']; ?></h3>
								<a class="need_help_btn fun-ex-btn pd7p" href="/campaign.php?id=<?php echo $a_campaign['campaign_id']; ?>">view campgain</a>
							</div>
						</div>
					<?php 
				}
			}	
		?>
	</div>
</div>