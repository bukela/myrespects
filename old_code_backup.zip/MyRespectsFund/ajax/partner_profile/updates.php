<div>
	<form>
		<input type="hidden" name="action" value="messages_send" />
		<input type="hidden" name="from_user" value="<?php echo $o_user->get_id(); ?>" />
		<input type="hidden" name="funeral_home_id" value="<?php echo $a_funeral_home['funeral_home_id']; ?>" />
		<div class="dsdo campup fix">
			<div class="dthdn">
				<img class="msgimg" src="assets/images/msg-icon.png" alt="">
				<h2 class="spremin">Send A Reminder To Funds</h2>
			</div>
		</div>
		<div class="dsdo campup fix">
			<div class="form_input_area fundsce fix">
				<label class="secfund" for="">Select Fund</label>
				<select name="campaign_id" class="form_select_field">
					<option>Select a Fund</option>
					<?php 
						$a_linked = $o_fb->get_linked_funds( $a_funeral_home['funeral_home_id'] ); 
						if ( !empty( $a_linked ) && is_array( $a_linked ) ) {
							foreach( $a_linked as $a_campaign ) {
								?>
									<option value="<?php echo $a_campaign['campaign_id']; ?>"><?php echo $a_campaign['campaign_title']; ?></option>
								<?php 
							}
						}	
					?>
				</select>											
			</div>
		</div>
		<div class="dsdo campup">
			<div class="form_input_area fix">
				<label class="des" for="">description</label>
				<textarea class="deshp" name="message" cols="0" rows="0"></textarea>
			</div>
		</div>
		<div class="se-btn"><a class="ccbtn update_partner">send</a></div>
	</form>
	
	<div class="dsdo campup  spmar fix">
		<div class="dthdn">
			<img class="msgimg" src="assets/images/msg-icon.png" alt="">
			<h2 class="spremin">Send Reminders</h2>
		</div>
	</div>
	<?php 
		$a_sent_messages = $o_messages->get_sent_messages_partner( $o_user->get_id() );
		if ( $a_sent_messages['result'] != true ) {
			unset( $a_sent_messages );
		}
		if ( isset( $a_sent_messages ) ) {
			foreach ( $a_sent_messages['data'] as $a_message ) {

				if ( $a_message['from_user'] != $o_user->get_id() ) 
					continue;
				?>
					<div class="form-mtcl fix">
						<div class="mtcl">
							<h4>From: <?php echo $a_message['name']; ?></h4>
							<h5>Date: <?php echo date( 'F d, Y', strtotime( $a_message['date'] ) ); ?></h5>
							<p><?php echo stripslashes( $a_message['message'] ); ?></p>
				
							<a class="ccbtn delete-message" data-message-id="<?php echo $a_message['id']; ?>">Delete</a>
							
				
						</div>
					</div>
				<?php 
			}
		}
	?>
</div>