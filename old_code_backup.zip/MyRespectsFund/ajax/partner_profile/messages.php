<div>	
	<div class="dsdo campup">
		<div class="dthdn">
			<img src="assets/images/msg-icon.png" alt="">
			<h2>Message</h2>
		</div>
	</div>
	
	<?php 
		if ( isset( $a_messages ) ) {
			foreach ( $a_messages['data'] as $a_message ) {
				?>
					<div class="form-mtcl">
						<form>
							<input type="hidden" name="action" value="messages_reply" />
							<input type="hidden" name="message_id" value="<?php echo $a_message['id']; ?>" />
							<input type="hidden" name="campaign_id" value="<?php echo $a_message['campaign_id']; ?>" />
							<input type="hidden" name="user_id" value="<?php echo $o_user->get_id(); ?>" />
							<input type="hidden" name="from_user" value="<?php echo $a_message['from_user']; ?>" />
							<div class="mtcl cpdpshp">
								<h4>From: <?php echo $a_message['name']; ?></h4>
								<h5>Date: <?php echo date( 'F d, Y', strtotime( $a_message['date'] ) ); ?></h5>
								<p><?php echo stripslashes( $a_message['message'] ); ?></p>
								
								<ul class="capmprolst">
									<li><a id="repbtnp<?php echo $a_message['id']; ?>" href="javascript:void(0)">REPLY</a></li>
									
									<li><a class="ccbtn delete-message" data-message-id="<?php echo $a_message['id']; ?>">Delete</a></li>
								</ul>
					
								<div class="repboxp" id="repextp<?php echo $a_message['id']; ?>">
									<img src="assets/images/arrowdwn.png" alt="arrow">
						
									<textarea name="message-text" cols="0" rows="0"></textarea>
									<a class="ccbtn reply-message">send</a>
								</div>
					
							</div>
						</form>
					</div>	
					<script>
						$("#repbtnp<?php echo $a_message['id']; ?>").click(function(){
							$("#repextp<?php echo $a_message['id']; ?>").slideToggle();
						});
					</script>
				<?php 
			}
		}
	?>
</div>

<?php if ( isset( $_GET['id'] ) && !empty( $_GET['id'] ) ) { ?>
	<script>
		jQuery(document).ready(function(){
			$("#repextp<?php echo intval( $_GET['id'] ); ?>").slideToggle();
			$('html, body').animate({
	            scrollTop: $("#repextp<?php echo intval( $_GET['id'] ); ?>").parents('.form-mtcl').offset().top
	        }, 2000);
		});
	</script>
	
	
<?php } ?>

<script>
	jQuery('.ccbtn.reply-message').click(function(event){
		event.preventDefault();
		
		$.ajax( {
			type: "POST",
		    url: "ajax/update_campaign.php",
		    data: $(this).parents('form').serialize(),
		    success: function( response ) {

		    	document.location = '<?php echo $s_current_url."?page=messages" ?>';
			}
		});
	});
</script>