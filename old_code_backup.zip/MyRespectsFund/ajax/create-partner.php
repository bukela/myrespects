<?php

/*
 * DB hook to create a campaign. Currently should be called from root/create-campaign.php.
 * @todo Add validation against user session. 
 * 
 */

session_start();

require_once __DIR__ . '/../classes/funeral_home_base.php';
require_once __DIR__ . '/../classes/location_base.php';
require_once __DIR__ . '/../classes/user_base.php';

$o_user = new user_base();

$result = $o_user->decode_session_string( $_POST['ss'] );

$o_user = unserialize( $_SESSION['user_base'] );

$i_user_id = intval( $o_user->get_id() );

if( $i_user_id == 0 ) {
	$a_result = array("status" => false, "message" => "");
	
	echo json_encode( $a_result );
	die();
}

$_POST['partner_id'] = $i_user_id;

unset( $_POST['ss'] );

$o_lb = new location_base();

$a_latlng = $o_lb->address_to_lat_lng( $_POST['funeral_home_address'].",+".$_POST['funeral_home_city'].",+".$_POST['funeral_home_state'] );
if ( $a_latlng != false ) {
	$_POST['funeral_home_lat'] = $a_latlng['lat'];
	$_POST['funeral_home_lng'] = $a_latlng['lng'];
}
unset( $a_latlng );

$o_fhb = new funeral_home_base();

if ( $_POST['useimage'] == 'upload' ) {
	
	$a_result = $o_fhb->create_funeral_home( $_POST, $_FILES['campaign_image'] );

} else {
	
	$a_result = $o_fhb->create_funeral_home( $_POST );
}
unset( $o_fhb );

echo json_encode( $a_result );
die();
?>