<?php

session_start();

if ( isset( $_POST['form-name'] ) && $_POST['form-name'] == 'password-reset-form' && $_POST['login_nonce'] == $_SESSION['login_nonce'] ) {

	include_once '../classes/user_base.php';
	$o_user = new user_base();
	
	if ( $o_user->reset_password( $_POST ) === TRUE ) {

		echo json_encode(array(
			'result'	=> 'Success',
			'msg'		=> 'Please check your email for the new password.'
		));

	} else {
		
		echo json_encode(array(
			'result'	=> 'Fail',
			'msg'		=> 'There was an error resetting your password'
		));
	}
}

die();