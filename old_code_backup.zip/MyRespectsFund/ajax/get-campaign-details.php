<?php

require_once '../classes/campaign_base.php';

$o_cb = new campaign_base();

$a_results = $o_cb->get_campaign_details( $_POST['campaign_id'] );

echo json_encode( $a_results );

die();
