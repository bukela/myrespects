<?php 
$page = 'campaign-dashboard';
$additional_meta = '<link type="text/css" rel="stylesheet" href="assets/css/backend-css.css" />';

require_once '_includes/header.php';
require_once 'classes/campaign_base.php';
require_once 'classes/message_base.php';

$o_cb = new campaign_base();
$i_campaign_id = $o_user->get_user_campaign();
if ( $i_campaign_id === FALSE ) {
	header( 'Location: /index.php' );
}
$a_campaign = $o_cb->get_campaign_details( $i_campaign_id );
if ( empty( $a_campaign ) ) {
	header( 'Location: /index.php' );
}

$o_messages = new message_base();
$a_messages = $o_messages->get_all_messages( $i_campaign_id, $o_user->get_id() );
if ( $a_messages['result'] != true ) {
	unset( $a_messages );
} 

$s_current_dashboard_page = isset( $_GET['page'] ) ? addslashes( $_GET['page'] ) : '';

$s_current_url = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];

?>
 <!-- profile starrt -->
<section id="profile-heading">
	<div class="container">
		<div class="col-sm-7">
			<div class="dashboard-top-logo">
				<a href="#"><img src="/assets/images/logo_funeral_mob.png" alt=""></a>
				<div class="dashboard-top-logo-content">
<!-- 					<h6>Funeral Expenses</h6> -->
					<h3>Fundraising for <?php echo $a_campaign['campaign_title']; ?></h3>
				</div>
			</div>
	
			<ul class="contactlist dashboard-contactlist">
				<li><img src="/assets/images/icon_address_pointer.png" alt="" /> <?php echo $a_campaign['funeral_home_city'].", ".$a_campaign['funeral_home_state']; ?></li>
				<li><img src="/assets/images/icon_calender.png" alt="" /> Created: <?php echo date( 'F j, Y', strtotime( $a_campaign['start_date'] ) ); ?></li>
				<li><img src="/assets/images/icon_creator.png" alt="" /> Created: <?php echo $a_campaign['first_name']." ".$a_campaign['last_name']; ?></li>
			</ul>
		</div>
		<div class="col-sm-5">
			<div class="logout">
				<a id="sign-out">log-out</a>
			</div>
			<br>
			<div class="ned_help_btnrow">
				<?php // @todo set up bootstraptour.php and need help overlay ?>
				<a class="need_help_btn dashboard-help-btn" id="dashboard-tour" >dashboard tour</a>
				<a class="need_help_btn dashboard-help-btn" href="mailto:admin@myrespects.org">Need Help?</a>
			</div>
		</div>
	</div>
</section> 
<!-- profie end -->

<!-- dashboard menu start -->
<section id="dashboard" class="dashboard-menu-area">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<div class="dash">
					<h2>CAMPAIGN Dashboard</h2>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- dashboard menu end -->

<!-- dashboard content area start -->
<section id="dash-content" class="dashcont-area clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="dash-mn">
					<!--dashcontent mobile menu start -->
					<div class="mobile-dash-menu fix">	
						<img src="/assets/images/edit-icon.png" alt=""> <h4>edit Menu</h4><img class="dswhite" src="/assets/images/arrow_select.png" alt="">
					</div>
					<!--dashcontent mobile menu end -->
					<ul class="sdo">
						<li class="home-icon"><a><img src="/assets/images/edit-icon.png" alt=""> <h4>edit</h4> </a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'goal' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=goal" ?>">Campaign Goal & Title</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'photos' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=photos" ?>">Campaign Photos</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'story' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=story" ?>">Campaign Story</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'settings' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=settings" ?>">Campaign Settings</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'toolkit' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=toolkit" ?>">Campaign Toolkit </a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'details' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=details" ?>">Funeral Details</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'messages' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=messages" ?>">Messages</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'donations' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=donations" ?>">Who Has Donated</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'withdraw' ? 'class="active"' : ''; ?> ><a href="<?php echo $s_current_url."?page=withdraw" ?>">Withdraw Funds</a></li>
					</ul>
				</div>
			</div>
			
			<div id="dash-ajax-load" class="col-md-6"> <!-- filled with ajax -->
				<?php 
					switch ( $s_current_dashboard_page ) {

						case "goal":
							include_once( 'ajax/campaign_profile/goal.php' );
							break;
						case "photos":
							include_once( 'ajax/campaign_profile/photos.php' );
							break;
						case "story":
							include_once( 'ajax/campaign_profile/story.php' );
							break;
						case "settings":
							include_once( 'ajax/campaign_profile/settings.php' );
							break;
						case "toolkit":
							include_once( 'ajax/campaign_profile/toolkit.php' );
							break;
						case "details":
							include_once( 'ajax/campaign_profile/details.php' );
							break;
						case "donations":
							include_once( 'ajax/campaign_profile/donations.php' );
							break;
						case "withdraw":
							include_once( 'ajax/campaign_profile/donations.php' );
							break;
						case "messages":
							include_once( 'ajax/campaign_profile/messages.php' );
							break;
						default:
							include_once( 'ajax/campaign_profile/dashboard.php' );
							break;
					}
				?>
			 </div>
			
			<div class="col-md-3">
				<div class="draise fix">
					<h3 class="drsh">$<?php echo number_format( $a_campaign['raised'] ); ?> Raised </h3>
					<p>of $<?php echo number_format( $a_campaign['campaign_goal'] ) ?></p>
				</div>
				<div class="msg sdmdgn fix">
					<div class="hdn">
						<img src="/assets/images/edit-icon.png" alt="">
						<h3 class="drsh">Messages <span>( <?php echo isset( $a_messages ) ? $a_messages['count'] : 0; ?> )</span> </h3>
					</div>
					<p><a href="<?php echo $s_current_url; ?>">Post An Update</a></p>
					
					<?php 
						if ( isset( $a_messages ) ) {
							$i_counter = 0;
							foreach ( $a_messages['data'] as $i_message_id => $a_message ) {
								if ( $i_counter >= 2 ) {
									break;
								}
								?>
									<div class="dfrom">
										<h4>From: <?php echo $a_message['name']; ?></h4>
										<h5>Date: <?php echo date( 'F d, Y', strtotime( $a_message['date'] ) ); ?></h5>
										<p><?php echo substr( $a_message['message'], 0, 100 ); ?> ....</p>
							
										<a class="ccbtn" href="<?php echo $s_current_url."?page=messages&id=".$a_message['id']; ?>">REPLY</a>
										<a class="ccbtn delete-message" data-message-id="<?php echo $a_message['id']; ?>">Delete</a>
									</div>				
								<?php 
								$i_counter++;
							}
						}
					?>
					<div class="vbtn"><a class="ccbtn" href="<?php echo $s_current_url."?page=messages" ?>">view all</a></div>
				</div>
				<div class="dclender fix">
					<?php // @todo hook up this? This was a phase 2 task. ?>
					<div class="hdn">
						<img src="/assets/images/edit-icon.png" alt="">
						<h3 class="drsh">My Calendar</h3>
					</div>
					<p><a href="#">edit calendar</a></p>
					<p><a href="#">set Reminder</a></p>
			
					<div class="set-cal">
						<div class="ddcal"><a href="#"><img src="/assets/images/cal_btn.png" alt=""></a></div>
						<div class="dgc"><p>Google Calendar Connected.</p></div>
						<div class="dac"><a href="#"><img src="/assets/images/cross.jpg" alt=""></a></div>
					</div>
				</div>
			</div>
						
			
		</div>
	</div>
</section>

<?php require_once '_includes/footer.php'; ?>

<script type="text/javascript">
	jQuery('.ccbtn.update_campaign').click(function(event){
		event.preventDefault();

		var form_data = $(this).parentsUntil('form').parent().serialize();
		
		$.ajax( {
			type: "POST",
		    url: "ajax/update_campaign.php",
		    data: form_data,
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

				if(resp_obj.result == 'Success') {
					location.relaod();
				}
		    	
			}
		});
	
	});

	jQuery('.ccbtn.delete-message').click(function(event){

		var that = $(this);
		
		$.ajax( {
			type: "POST",
		    url: "ajax/update_campaign.php",
		    data: { 'message_id' : $(this).data('message-id'), 'action' : 'messages_delete', 'campaign_id' : '<?php echo $a_campaign['campaign_id']; ?>' },
		    success: function( response ) {

		    	that.parents('.dfrom').slideUp();
		    	that.parents('.form-mtcl').slideUp();
			}
		});
	});


	jQuery('#dashboard-tour').click(function(){
		tour.restart();
	});

	<?php // @todo: Need content for bootstrap tour ?>
	var tour = new Tour({
	  steps: [
	  {
	    element: "#dash-content",
	    title: "Bootstrap Tour",
	    content: "Need content and targets for this"
	  },{
	    element: "#dashboard",
	    title: "Bootstrap Tour",
	    content: "Need content and targets for this"
	  }
	]});
	tour.init();


</script>