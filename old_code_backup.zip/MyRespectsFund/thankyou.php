<?php 

require_once '_includes/header.php';

require_once 'classes/campaign_base.php';

$o_cb = new campaign_base();

$i_campaign_id = intval( $_GET['cid'] );

if ( $i_campaign_id == 0 || ! isset( $_GET['preapproval_id'] ) ) {
	//error
} else {
	$o_result = $o_db->call("update_donation_as_complete", "'" . addslashes( $_GET['preapproval_id'] ) . "'");

	if( $o_result->num_rows != 1 ) {
		//error
	} else {
		$a_donation_detail = mysqli_fetch_assoc( $o_result );
	}
	
}

$i_total_donation = $o_cb->get_campaign_total_donations( $i_campaign_id );

?>
<section id="profile-heading">
	<div class="container">
		<div class="col-sm-7">
			<h6>Funeral Expenses</h6>
			<h3>Fundraising for Susan A. Smith</h3>
			<ul class="contactlist">
				<li><a href="#"><img src="assets/images/icon_address_pointer.png" alt="" /> San Francisco, CA</a></li>
				<li><a href="#"><img src="assets/images/icon_calender.png" alt="" /> Created: March 15, 2017</a></li>
				<li><a href="#"><img src="assets/images/icon_creator.png" alt="" /> Created: Jonathan E. Gicewicz (Son)</a></li>
			</ul>
		</div>
		<div class="col-sm-5">
			<div class="ned_help_btnrow">
				<a class="need_help_btn" href="#">Need Help?</a>
				<a class="need_help_btn" href="#">BACK TO CAMPAIGN</a>
			</div>
		</div>
	</div>
</section> 


<section id="profile-content" class="container_donate_step"> <!-- #profile-content starts -->
	<div class="container">
		<div class="col-sm-12 thanks_title fix">
			<h1>Thank You! - <span>You Donated $<?php echo ( $a_donation_detail['amount'] ); ?></span></h1>
		</div>
		<div class="col-sm-6">
			<div class="sidebar-profile-image">
				<div class="profile-image">
					<img class="img-responsive" src="assets/images/susan-a-smith.jpg" alt="" />
				</div>
			</div>

		</div>
		<div class="sidebar col-sm-6">

			<div class="mr_donate_step_content fix thanks_page">
				<div class="mr_donate_step_thanks fix">
					
					<h2>Fundraising for Susan A. Smith</h2>
					<div class="thanks_amount_social fix">
						<h2>New Amount raised to date :</h2>
						<h1>$<?php echo( number_format( $i_total_donation ) ); ?> <small>of $13,000</small></h1>
					</div>
					<div class="mr_thanks_sharearea fix">
						<h2>Share</h2>
						<img src="assets/images/social_btns.jpg" alt="" />
					</div>
				</div>
			
			</div>
			
		</div>
		<div class="col-md-12 back_to_main">
			<a href="" class="send_us_btn_he">BACK TO CAMPAIGN</a>
		</div>
	</div>
</section> <!-- #profile-content ends -->
<?php 

require_once '_includes/footer.php';

?>