<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Respects - Coming Soon</title>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> 

<style>
/* Reset */

body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,textarea,p,blockquote,th,td{margin:0;padding:0;}table{border-collapse:collapse;border-spacing:0;}fieldset,img{border:0;}address,caption,dfn,th,var{font-style:normal;font-weight:normal;}li{list-style:none;}caption,th{text-align:left;}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal;}

html,body{
height: 100%;
}

body{
margin:0;
padding:0;
background:#000;
font-family:"Helvetica Neue",Helvetica, Arial;
}

div#shim{
visibility: hidden;
width: 100%;
height: 50%;                                                                     
margin-top: -140px;                                                              
float: left;
}

div#content {
width: 940px;
height: 280px;
margin: 0 auto;
clear: both;
position: relative;
top: -140px;

/* IE4ever Hack: Hide from IE4 **/
position: static;
/** end hack */
}

/* Hide from IE5mac \*//*/
div#shim {
display: none;
}
html, body {
height: auto;
}
/* end hack */
/* ]]> */


.logo_box{
width: 349px;
float: left;
border-right: 1px solid #303030;
height: 280px;
position: relative;
}

h1{
padding: 12px 70px 12px 20px;
position: absolute;
right: 0;
text-align:left;
top: 25%;
float: left;
color: #fff;
letter-spacing: -1px;
font-size: 38px;
}

h1 cufon{
margin-bottom: -4px;
}

h3{
font-size: 24px;
color: #333;
float: left;
margin-right: 15px;
padding-top: 5px;
}

.main_box{
float: left;
width: 500px;
height: 95px;
padding: 25px;
}

form{
width: 590px;
padding: 10px 0;
float: left;
background: url(../assets/images/dots.gif) right top repeat-y;
height: 80px;
}

h2{
font-family: Georgia;
color: #ffe400;
font-size: 24px;
margin-bottom: 20px;
}

h2 span{
color: #fff;
font-size: 16px;
line-height: 26px;
font-style: italic;
}

ul.info{
width: 500px;
padding: 0;
margin: 10px 0 0 0;
float: left;
}

ul.info li{
margin-bottom: 20px;
clear: both;
float: left;
}

ul.info li p{
font-size: 13px;
line-height: 20px;
color: #fff;
float: left;
margin: 0;
}


ul.info li p.social a.tw{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) left top no-repeat;
margin-right: 8px;
float: left;
}

ul.info li p.social a.fb{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) -36px top no-repeat;
float: left;
margin-right: 8px;
}

ul.info li p.social a.li{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) -72px top no-repeat;
float: left;
}

ul.info li p.social a.tw:hover{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) left bottom no-repeat;
float: left;
}

ul.info li p.social a.fb:hover{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) -36px bottom no-repeat;
float: left;
}

ul.info li p.social a.li:hover{
width: 28px;
height: 28px;
background: url(../assets/images/social.png) -72px bottom no-repeat;
float: left;
}



.field{
float: left;
background: url(../assets/images/input.png) left top no-repeat;
width: 425px;
height: 21px;
font-size: 14px;
color: #666;
padding: 10px;
border: none;
}

.submit_butt{
float: left;
background: url(../assets/images/input.png) right top no-repeat;
width: 109px;
height: 41px;
border: none;
cursor: pointer;
}

.submit_butt:hover{
background: url(../assets/images/input.png) right bottom no-repeat;
}

.connect{
width: 145px;
padding-left: 20px;
float: left;
padding-top: 20px;
}

.connect img{
margin-right: 5px;
}
.container_12,.container_16{margin-left:auto;margin-right:auto;width:960px}.grid_1,.grid_2,.grid_3,.grid_4,.grid_5,.grid_6,.grid_7,.grid_8,.grid_9,.grid_10,.grid_11,.grid_12,.grid_13,.grid_14,.grid_15,.grid_16{display:inline;float:left;position:relative;margin-left:10px;margin-right:10px}.container_12 .grid_3,.container_16 .grid_4{width:220px}.container_12 .grid_6,.container_16 .grid_8{width:460px}.container_12 .grid_9,.container_16 .grid_12{width:700px}.container_12 .grid_12,.container_16 .grid_16{width:940px}.alpha{margin-left:0}.omega{margin-right:0}.container_12 .grid_1{width:60px}.container_12 .grid_2{width:140px}.container_12 .grid_4{width:300px}.container_12 .grid_5{width:380px}.container_12 .grid_7{width:540px}.container_12 .grid_8{width:620px}.container_12 .grid_10{width:780px}.container_12 .grid_11{width:860px}.container_16 .grid_1{width:40px}.container_16 .grid_2{width:100px}.container_16 .grid_3{width:160px}.container_16 .grid_5{width:280px}.container_16 .grid_6{width:340px}.container_16 .grid_7{width:400px}.container_16 .grid_9{width:520px}.container_16 .grid_10{width:580px}.container_16 .grid_11{width:640px}.container_16 .grid_13{width:760px}.container_16 .grid_14{width:820px}.container_16 .grid_15{width:880px}.container_12 .prefix_3,.container_16 .prefix_4{padding-left:240px}.container_12 .prefix_6,.container_16 .prefix_8{padding-left:480px}.container_12 .prefix_9,.container_16 .prefix_12{padding-left:720px}.container_12 .prefix_1{padding-left:80px}.container_12 .prefix_2{padding-left:160px}.container_12 .prefix_4{padding-left:320px}.container_12 .prefix_5{padding-left:400px}.container_12 .prefix_7{padding-left:560px}.container_12 .prefix_8{padding-left:640px}.container_12 .prefix_10{padding-left:800px}.container_12 .prefix_11{padding-left:880px}.container_16 .prefix_1{padding-left:60px}.container_16 .prefix_2{padding-left:120px}.container_16 .prefix_3{padding-left:180px}.container_16 .prefix_5{padding-left:300px}.container_16 .prefix_6{padding-left:360px}.container_16 .prefix_7{padding-left:420px}.container_16 .prefix_9{padding-left:540px}.container_16 .prefix_10{padding-left:600px}.container_16 .prefix_11{padding-left:660px}.container_16 .prefix_13{padding-left:780px}.container_16 .prefix_14{padding-left:840px}.container_16 .prefix_15{padding-left:900px}.container_12 .suffix_3,.container_16 .suffix_4{padding-right:240px}.container_12 .suffix_6,.container_16 .suffix_8{padding-right:480px}.container_12 .suffix_9,.container_16 .suffix_12{padding-right:720px}.container_12 .suffix_1{padding-right:80px}.container_12 .suffix_2{padding-right:160px}.container_12 .suffix_4{padding-right:320px}.container_12 .suffix_5{padding-right:400px}.container_12 .suffix_7{padding-right:560px}.container_12 .suffix_8{padding-right:640px}.container_12 .suffix_10{padding-right:800px}.container_12 .suffix_11{padding-right:880px}.container_16 .suffix_1{padding-right:60px}.container_16 .suffix_2{padding-right:120px}.container_16 .suffix_3{padding-right:180px}.container_16 .suffix_5{padding-right:300px}.container_16 .suffix_6{padding-right:360px}.container_16 .suffix_7{padding-right:420px}.container_16 .suffix_9{padding-right:540px}.container_16 .suffix_10{padding-right:600px}.container_16 .suffix_11{padding-right:660px}.container_16 .suffix_13{padding-right:780px}.container_16 .suffix_14{padding-right:840px}.container_16 .suffix_15{padding-right:900px}.container_12 .push_3,.container_16 .push_4{left:240px}.container_12 .push_6,.container_16 .push_8{left:480px}.container_12 .push_9,.container_16 .push_12{left:720px}.container_12 .push_1{left:80px}.container_12 .push_2{left:160px}.container_12 .push_4{left:320px}.container_12 .push_5{left:400px}.container_12 .push_7{left:560px}.container_12 .push_8{left:640px}.container_12 .push_10{left:800px}.container_12 .push_11{left:880px}.container_16 .push_1{left:60px}.container_16 .push_2{left:120px}.container_16 .push_3{left:180px}.container_16 .push_5{left:300px}.container_16 .push_6{left:360px}.container_16 .push_7{left:420px}.container_16 .push_9{left:540px}.container_16 .push_10{left:600px}.container_16 .push_11{left:660px}.container_16 .push_13{left:780px}.container_16 .push_14{left:840px}.container_16 .push_15{left:900px}.container_12 .pull_3,.container_16 .pull_4{left:-240px}.container_12 .pull_6,.container_16 .pull_8{left:-480px}.container_12 .pull_9,.container_16 .pull_12{left:-720px}.container_12 .pull_1{left:-80px}.container_12 .pull_2{left:-160px}.container_12 .pull_4{left:-320px}.container_12 .pull_5{left:-400px}.container_12 .pull_7{left:-560px}.container_12 .pull_8{left:-640px}.container_12 .pull_10{left:-800px}.container_12 .pull_11{left:-880px}.container_16 .pull_1{left:-60px}.container_16 .pull_2{left:-120px}.container_16 .pull_3{left:-180px}.container_16 .pull_5{left:-300px}.container_16 .pull_6{left:-360px}.container_16 .pull_7{left:-420px}.container_16 .pull_9{left:-540px}.container_16 .pull_10{left:-600px}.container_16 .pull_11{left:-660px}.container_16 .pull_13{left:-780px}.container_16 .pull_14{left:-840px}.container_16 .pull_15{left:-900px}.clear{clear:both;display:block;overflow:hidden;visibility:hidden;width:0;height:0}.clearfix:after{clear:both;content:' ';display:block;font-size:0;line-height:0;visibility:hidden;width:0;height:0}* html .clearfix{height:1%}

</style>
</head>
<body>
<div id="shim"></div>
<div id="content">
	<div class="logo_box">
		<h1 id="h1_logo">My<br/>Respects</h1>
	</div>          
	<div class="main_box">
		<h2>We are working on something pretty cool.<br/><span>In the mean time connect with us with the information below</span></h2>
		
		<ul class="info">
			<li>
				<h3>E</h3>
				<p>info@myrespects.org</p>
			</li>
			<li>
				<h3>S</h3>
				<p class="social">
					<a href="#" class="tw"></a>
					<a href="#" class="fb"></a>				
					<a href="#" class="li"></a>
				</p>
			</li>
			<li id="li_login" style="display: none;">
				<form action="index.php" id="login-form" method="post">
					<input type="password" name="verify" id="verify"></input>
					<input type="submit" name="login_submit" class="login_submit" value="Login"></input>
				</form>
			</li>
		</ul>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('#h1_logo').click(function() {
			$('#li_login').show();
		});
	});
</script>

</body>
</html>
