<ul class="nav">
	<!-- Main menu -->
	<li class="<?php echo preg_match( '/index.php/', $_SERVER['REQUEST_URI'] ) == true ? 'current': ''; ?>"><a href="index.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
	<li class="<?php echo preg_match( '/cms.php/', $_SERVER['REQUEST_URI'] ) == true ? 'current': ''; ?>"><a href="cms.php"><i class="glyphicon glyphicon-pencil"></i> CMS</a></li>
	<li class="<?php echo preg_match( '/reporting.php/', $_SERVER['REQUEST_URI'] ) == true ? 'current': ''; ?>"><a href="reporting.php"><i class="glyphicon glyphicon-stats"></i> Reporting</a></li>
</ul>
