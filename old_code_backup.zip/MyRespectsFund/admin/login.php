<?php
session_start();

include_once '../classes/db_base.php';
include_once '../classes/user_base.php';
$o_db = new db_base();

if ( isset( $_SESSION['user_base'] ) && !empty( $_SESSION['user_base'] ) ) {
	$o_user = unserialize( $_SESSION['user_base'] );

	if ( $o_user->is_admin() === TRUE ) {

		header('Location: index.php');
	} else {
		
		// @todo throw error, need to integrate error css/modal first
	}
	
} else {
	$o_user = new user_base( $o_db );
}

if ( isset( $_POST['form-name'] ) && $_POST['form-name'] == 'admin-login-form' && $_POST['login_nonce'] == $_SESSION['login_nonce'] ) {

	if ( $o_user->login( $_POST ) === TRUE ) {

		$_SESSION['login'] = TRUE;
		$_SESSION['user_base'] = serialize( $o_user );
		
		if ( $o_user->is_admin() === TRUE ) {

			header('Location: index.php');
			
		} else {
			
			// @todo throw error, need to integrate error css/modal first
		}

	} else {

		// @todo throw error, need to integrate error css/modal first
		
		$_SESSION['login'] = FALSE;
		unset( $_SESSION['user_base'] );
	}
}

$_SESSION['login_nonce'] = sha1( "extra-security-nonce".microtime( true ) );

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Bootstrap Admin Theme v3</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">
    
    <!-- For Google Login -->
    <meta name="google-signin-client_id" content="40989211664-2lg8e805sqer9lu7op17stlo6e4mttn4.apps.googleusercontent.com">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="login-bg">
  	
  	<!-- 
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-12">
	              Logo
	              <div class="logo">
	                 <h1><a href="index.html">Bootstrap Admin Theme</a></h1>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>
 	-->
 	
	<div class="page-content container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="login-wrapper">
			        <div class="box">
			            <div class="content-wrap">
			            	<form id="admin-login-form" method="POST">
			            		
			            		<input type="hidden" name="login_nonce" value="<?php echo $_SESSION['login_nonce']; ?>" />
								<input type="hidden" name="form-name" value="admin-login-form" />
										
				                <h6>Sign In</h6>
				                <div class="social">
		                            <a class="face_login" onclick="javascript: fbcheckLoginState();">
		                                <span class="face_icon">
		                                    <img src="images/facebook.png" alt="fb">
		                                </span>
		                                <span class="text">Sign in with Facebook</span>
		                            </a>
		                            
		                            <a id="google_login" class="google_login">
		                            	<span class="google_icon">
		                            		<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 48 48" class="abcRioButtonSvg"><g><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path><path fill="none" d="M0 0h48v48H0z"></path></g></svg>
		                            	</span>
										<span class="text">Sign in with Google</span>	                            	
		                            </a>
		                            
		                            <div class="division">
		                                <hr class="left">
		                                <span>or</span>
		                                <hr class="right">
		                            </div>
		                        </div>
				                <input class="form-control" type="text" name="user-email" placeholder="E-mail address">
				                <input class="form-control" type="password" name="user-password" placeholder="Password">
				                <div class="action">
				                	<input type="submit" class="btn btn-primary signup" value="Login" />
				                </div> 
			                </form>               
			            </div>
			        </div>

			    </div>
			</div>
		</div>
	</div>

    <script>

		window.fbAsyncInit = function() {
			FB.init({
				appId      : '392737507767162',
				xfbml      : true,
				version    : 'v2.8'
			});
			FB.AppEvents.logPageView();

		};

		(function(d, s, id){
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) {return;}
			js = d.createElement(s); js.id = id;
			js.src = "//connect.facebook.net/en_US/sdk.js";
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));

		function fbcheckLoginState() {
			FB.getLoginStatus(function(response) {
				if (response.status === 'connected') {

					var input = document.createElement('input');
					input.type = "hidden";
					input.name = "facebook-token";
					input.value = response.authResponse.accessToken;

					var form = document.getElementById('admin-login-form');
					form.append( input );

					form.submit();
					
				} else {
					FB.login(function(response){
						
						if (response.status === 'connected') {

							var input = document.createElement('input');
							input.type = "hidden";
							input.name = "facebook-token";
							input.value = response.authResponse.accessToken;

							var form = document.getElementById('admin-login-form');
							form.append( input );

							form.submit();
							
						} else {
							
							
						}
					});
				}
			});
		}

		function startGoogle(){

			element = document.getElementById('google_login');

			gapi.load('auth2', function() {
				auth2 = gapi.auth2.init({
					client_id: '40989211664-2lg8e805sqer9lu7op17stlo6e4mttn4.apps.googleusercontent.com',
				});

				auth2.attachClickHandler(element, {},
					function(googleUser) {

				        var input = document.createElement('input');
						input.type = "hidden";
						input.name = "google-token";
						input.value = googleUser.getAuthResponse().id_token;
	
						var form = document.getElementById('admin-login-form');
						form.append( input );
	
						form.submit();
					
					}, function(error) {
						console.log('Sign-in error', error);
					}
				);
			});
		}
		
	</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
	<script src="https://apis.google.com/js/platform.js?onload=startGoogle" async defer></script>
	
  </body>
</html>