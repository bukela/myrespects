<?php 
require_once '_includes/header.php';

$b_connected = FALSE;
if ( $o_user->is_logged_in() ) {
	$b_connected = TRUE;
}
?>
								
<!-- #support-campaign starts -->
<form method="post" enctype="multipart/form-data" id="create_campaign_form">
	
	<input type="hidden" name="ss" id="ss" value="<?php echo( $o_user->get_session_string() ); ?>" />
	
	<section class="comomn_page_container search_page_content fix">
		
		<div class="start_campaign_stepone_area fix">
			<div class="container">
					
				<div class="row">
					<div class="col-md-12">
						<div class="start_campaign_stepone fix">
							<div class="start_campaign_steptitle fix">
								<h1>STEP 1 - <span>SIGN UP</span></h1>
								<p style="color:#00aa2c;    font-family: 'Volkhov', serif;"><small><?php echo $b_connected ? 'Connected' : ''; ?></small></p>
							</div>
							
							<div id="campaign_result" class=""></div>
							
							<div class="start_campaign_stepcontent fix">
								<div class="start_campaign_formarea fix">					
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
										
											<label for="first_name">First Name</label>
											<input type="text" id="first_name" name="first_name" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_first_name() : ''; ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="last_name">Last Name</label>
											<input type="text" id="last_name" name="last_name" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_last_name() : ''; ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="phone_number">Phone</label>
											<input type="phone" id="phone_number" name="phone_number" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_phone_number() : ''; ?>" data-mask="(000) 000-0000">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="email">Email</label>
											<input type="email" id="email" name="email" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_email() : ''; ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="address">Address</label>
											<input type="text" id="address" name="address" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_address() : ''; ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="city">City</label>
											<input type="text" id="city" name="city" class="form_input_field" value="<?php echo $b_connected ? $o_user->get_city() : ''; ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="ssn">Social Security #</label>
											<input type="text" id="ssn" name="ssn" class="form_input_field" data-mask="000-00-0000">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="dob">Date of Birth <span>MM / DD / YYYY</span></label>
											<input type="text" id="dob" name="dob" class="form_input_field datepicker" data-date="<?php echo $o_user->get_dob(); ?>">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="stae">State</label>
											<select id="state" name="state" class="form_select_field">
												<option>Please Select A State</option>
												<?php 
												foreach ( $STATES as $s_abbrv => $s_name ) {
													$s_selected = '';
													if ( $s_abbrv == $o_user->get_state() ) {
														$s_selected = 'selected="selected"';
													}
													echo "<option value='$s_abbrv' $s_selected >$s_name</option>";	
												}
												?>
											</select>											
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="zip">Zip / Postal Code</label>
											<input type="phone" id="zip" name="zip" class="form_input_field" data-mask="00000">							
										</div>
									</div>
									<div class="step_form_input col-sm-3">
										<div class="form_input_area fix">
											<label for="campaign_end">When will you need the money?</label>
											<input type="text" id="campaign_end" name="campaign_end" class="form_input_field datepicker">							
										</div>
									</div>
									<div class="step_form_submit fix">
										
										<a data-toggle="collapse" data-target="#step_two" class="strt_camp_step_conti" aria-expanded="true">CONTINUE</a>
									</div> 
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
			
		<div id="step_two" class="start_campaign_step_topshadow fix collapse">
			<div class="start_campaign_stepone_area fix">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="start_campaign_stepone fix">
								<div class="start_campaign_steptitle fix">
									<h1>STEP 2 - <span> CAMPAIGN GOALS, TITLE & PHOTO</span></h1>
								</div>
								<div class="start_campaign_stepcontent fix">
									<div class="start_campaign_formarea fix">
										<div class="step_form_input col-sm-3">
											<label for="" class="your_goal_label">YOUR GOAL</label>
											<div class="form_input_area fix ">
												<label for="campaign_goal"></label>
												<input type="tel" class="form_input_field your_goal_input" name="campaign_goal" id="campaign_goal" />							
											</div>
										</div>
										<div class="step_form_input col-sm-5">
											<div class="form_input_area fix">
												<label for="campaign_title">Campaign Title</label>
												<input type="text" class="form_input_field" name="campaign_title" id="campaign_title" />							
											</div>
										</div>
										<div class="step_form_input col-sm-4">
											<div class="form_input_area fix">
												<label for="campaign_image">Upload Photo</label>
												<input type="file" class="form_input_field upload_photofile" name="campaign_image" id="campaign_image" />	
												<!--   <a href="" class="view_photo">[View Photo]</a> -->						
											</div>
										</div>
										<div class="step_form_submit fix">
											<a data-toggle="collapse" data-target="#step_three"  class="strt_camp_step_conti">CONTINUE</a>
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	
		<div id="step_three" class="start_campaign_step_topshadow fix collapse">
			<div class="start_campaign_stepone_area fix">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="start_campaign_stepone fix">
								<div class="start_campaign_steptitle fix">
									<h1>STEP 3 - <span> Tell us your story</span></h1>
								</div>
								<div class="start_campaign_stepcontent fix">
									<div class="start_campaign_formarea fix">
										<div class="step_form_input col-sm-12">
											<div class="form_input_area fix ">
												<textarea class="textarea_tellstory" name="campaign_story" id="campaign_story" cols="30" rows="10"></textarea>
												<!-- 
												<div class="text-center">
													<button class="example_btn">Examples</button>
												</div>
												 -->												
											</div>
										</div>
										<div class="step_form_submit fix">
											<a data-toggle="collapse" data-target="#step_four"  class="strt_camp_step_conti">CONTINUE</a>
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
		<div id="step_four" class="start_campaign_step_topshadow fix collapse">
			<div class="start_campaign_stepone_area fix">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="start_campaign_stepone fix">
								<div class="start_campaign_steptitle fix">
									<h1>STEP 4 - <span> FIND A FUNERAL HOME</span></h1>
								</div>
								<div class="start_campaign_stepcontent fix">
									<div class="start_campaign_formarea fix">	
										<div class="step_four_inputarea fix">
											
											<div class="step_form_input col-sm-4">
												<div class="form_input_area fix">
													<label for="">Search by Furneral Home Zip Code</label>
													<input type="hidden" class="form-control" id="funeral_home_id" name="funeral_home_id" placeholder="">
    												<input type="tel" class="form-control" id="search_zip_code" maxlength="5" placeholder="">
												</div>
											</div>
											<div class="step_form_input col-sm-2">
												<div class="form_input_area fix serc_btn_area">
												
												<label for=""></label>
													<button onclick="javascript:show_map();" class="do-nothing search_btn">SEARCH</button>							
												</div>
											</div>
											<div class="col-sm-6">
												<div class="step_location fix" style="display:none;" id="funeral_home_name">
													<p><span>Funeral Home: </span></p>
												</div>
											</div>
										</div>
										<div class="step_form_input col-sm-12">
												<div id="map-canvas" style="display:none;width:100%;height:300px;">
    						
    											</div>
											</div>
										
										<div class="step_form_submit fix">
											<a  data-toggle="collapse" data-target="#step_five" class="strt_camp_step_conti">CONTINUE</a>
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div id="step_five" class="start_campaign_step_topshadow fix collapse" aria-expanded="true">
			<div class="start_campaign_stepone_area fix">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="start_campaign_stepone fix">
								<div class="start_campaign_steptitle fix">
									<h1>STEP 5 - <span> SHARE &amp; COMPLETE</span></h1>
								</div>
								<div class="start_campaign_stepcontent fix">
									<div class="start_campaign_formarea fix">
										<div class="social_sharebtn_area fix">
											<img src="assets/images/social_btns.jpg" alt="">
										</div>
										<div class="step_form_submit fix">
											<button type="submit" class="strt_camp_step_conti">Finish!</button>
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
	</section>
</form>
<!-- #support-campaign ends -->
<script type='text/javascript' src='assets/js/jquery.validate.min.js'></script>
<script type='text/javascript' src='assets/js/jquery.validate.additional.min.js'></script>
<script type="text/javascript">

function show_map(e){
	event.preventDefault();
	$('#map-canvas').slideDown(400,function(){
		google_map_init();
	});
}

function google_map_init(){

	map = new google.maps.Map(document.getElementById('map-canvas'), {
    	zoom: 5,
    	center: {lat: 38.9781784, lng: -100.6348431},
    	scrollwheel: false,
  	});
  	infowindow = new google.maps.InfoWindow();
  	bounds = new google.maps.LatLngBounds();
}    

$("#search_zip_code").keyup(function(){

	if ( $(this).val().length != 5 ) {
		return;
	}

	$.ajax({
		type: 'POST',
		url: '/ajax/find-funeral-homes.php',
		data: { 'zip': $(this).val() },
		beforeSend:function(){},
		success:function( data ){

			data = JSON.parse( data );
			console.log( data );

			if ( data ) {

			    var marker, i;
			
				for ( i = 0; i < data.length; i++ ) {  
					marker = new google.maps.Marker({
						position: new google.maps.LatLng( data[i]['funeral_home_lat'], data[i]['funeral_home_lng'] ),
						map: map
					});

					bounds.extend( marker.position );
					map.fitBounds(bounds);
					map.panToBounds(bounds);

					google.maps.event.addListener(marker, 'click', (function(marker, i) {
						return function() {
							html = 	"<div class='step_location fix'>"+
										"<p>" +
											"<span>Funeral Home:</span>" + data[i]['funeral_home_name'] + 
											"<br><span>Address:</span> "+ data[i]['funeral_home_address']+", "+data[i]['funeral_home_city']+" "+data[i]['funeral_home_state']+" "+data[i]['funeral_home_zip'] +
											"<br></span>" +
											"<button id='select-funeral-home' class='connect_btn' data-funeral-home-id='"+data[i]['funeral_home_id']+"' data-funeral-home-name='"+data[i]['funeral_home_name']+"'>Connect</button>" +
										"</p>" +
									"</div>";
							infowindow.setContent( html );
							infowindow.open(map, marker);
						}
					})(marker, i));
				}
			}
		},	
		error:function(){}
	});

});

$('form.do-nothing').click(function(event){

});

$('form#create_campaign_form').on('click', '#select-funeral-home',  function(e){
	e.preventDefault();
	$('#funeral_home_id').val( $(this).data('funeral-home-id') );

	$('#funeral_home_name span').after( $(this).data('funeral-home-name') );
	$('#funeral_home_name').show();
});

$("form#create_campaign_form").submit(function(e){	
	e.preventDefault();
});

$('form#create_campaign_form').validate({ 
    rules: {
        'email': {
            required: true,
            email: true
        },
        'ssn': {
            required: true,
            minlength: 9
        },
        'dob': {
            required: true,
            date: true
        },
        'campaign_end': {
            required: true,
            date: true
        }
    },
    submitHandler: function (form) {
    	var formData = new FormData($('form#create_campaign_form')[0]);
        $.ajax({
            url: "./ajax/create-campaign.php",
            type: 'POST',
            data: formData,
            async: false,
            success: function (data) {  	      
				
    			var results = JSON.parse(data);
				
				var status = results.status;
				
				if(status == false) {
					var msg = "<div class='alert alert-danger alert-dismissable fade in'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Error!</strong> "+results.message+"</div>";
					$('html, body').animate({scrollTop:0}, 'slow');	
    				$('#campaign_result').html(msg);
    			}
				if(status == 'success'){
					var msg = "<div class='alert alert-success alert-dismissable fade in'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong> SignUp Successfully!..</div>";
					$('html, body').animate({scrollTop:0}, 'slow');	
    				$('#campaign_result').html(msg);
    			} 
                
            },
            cache: false,
            contentType: false,
            processData: false
        });

        return false;
    }
});


</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRQliZkxPQ_xvpRom2CUQOzh-bSbmy5As&callback=google_map_init"></script>
<?php 

require_once '_includes/footer.php';

?>