<?php 
use OpenCloud\LoadBalancer\Resource\LoadBalancer;
/*
 * Placeholder UI so we can test functionality
 */

require_once '_includes/header.php';
require_once 'classes/campaign_base.php';

if ( !isset( $_GET['term'] ) || empty( $_GET['term'] ) ) {
	$_GET['term'] = '';
}

$o_cp = new campaign_base();

$i_number_of_results = $o_cp->get_search_results_count( $_GET['term'] );

unset( $o_cp );


?>
	<!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
    	<div class="container">
    		<?php if ( !empty( $_GET['term'] ) && $i_number_of_results > 0 ) { ?>
        		<h1> Results for <?php echo $_GET['term']; ?> </h1>
        		<h3> <?php echo $i_number_of_results; ?> results found </h3>
        	<?php } elseif ( $i_number_of_results > 0 ) { ?>
        		<h1> <?php echo $i_number_of_results; ?> results found </h1>
        	<?php } else { ?>
        		<h1> Campaign Not Found </h1>
        	<?php } ?>
      	</div>
    </div>

    <div class="container">
    	<div class="row">
    		<div class="col-sm-12" id="search-results">
    			<!-- Filled with Ajax -->
    		</div>
    		<div class="col-xs-12">
    			
    			<button class="col-xs-6" id="load-more" onclick="javascript:load_search_results();">More</button>
    		
    		</div>
    	</div>
    </div> <!-- /container -->
    
    
    <script>

    	var start_index = <?php echo isset( $_GET['start'] ) ? intval( $_GET['start'] ) : 0 ; ?>;
		var search_results = [];
    	
    	function get_search_results() {
    		// Dont fiddle with this function. 
    		$.ajax({
				type: 'POST',
				url: '/ajax/get-search-results.php',
				data: { 'search_term': '<?php echo isset( $_GET['term'] ) ? $_GET['term'] : '' ; ?>', 'start': start_index },
				beforeSend:function(){},
				success:function( data ){

					data = JSON.parse( data );

					if ( data.result == true ) {

						search_results = search_results.concat( data.data );
						load_search_results();
						
					} else {
						
						document.getElementById('load-more').remove();
						document.getElementById('search-results').innerHTML = data.message;
					}
				},	
				error:function(){
					document.getElementById('load-more').remove();
					document.getElementById('search-results').innerHTML = data.message;
				}
			});

    	}
    	get_search_results();

    	function load_search_results(){

    		var search_results_container = document.getElementById('search-results');

    		if ( start_index % 30 == 0 && start_index == search_results.length ) {
    			get_search_results();
    			return;
    		}

    		for ( i_counter = start_index; i_counter < start_index + 6; i_counter++ ) {

    			if ( i_counter >= search_results.length ) {
    				document.getElementById('load-more').remove();
					break;
    			}

    			/* possible way to create html for search-result.php page. its a royal pita though.
    			<div > 
					<div class="more text-center">
						<p>$<span id="ex1SliderVal">1,245</span> Raised <small>of $2,500 USD</small></p>
					</div>
					<div class="rangeslider">
						<input id="ex1" data-slider-id='ex1Slider' type="text" data-slider-min="0" data-slider-max="2500" data-slider-step="50" data-slider-value="1245"/>
					</div>
					<div class="more text-center">
						<a href="#">+ VIEW CAMPAIGN</a>						
					</div>
				</div> 
				
				var campaign_container = document.createElement('div');
				campaign_container.className = "campaign bg-light col-sm-3 search_result_item";

				var image_container = document.createElement('div');
				image_container.className = "image";

				var image = document.createElement('img');
				image.className = "img-responsive";
				image.src = search_results[ i_counter ].image;

				var image_span = document.createElement('span');
				<?php // @todo: this text should be dynamic ( I think ) and pulled from something todo with the db. ?>
				image_span.innerHTML = "Funeral Fund";

				image_container.append( image );
				image_container.append( image_span );

				var description_container = document.createElement('div');
				description_container.className = "textbox";

				var name = document.createElement('h4');
				name.innerHTML = search_results[ i_counter ].title;

				var description = document.createElement('p');
				description.innerHTML = search_results[ i_counter ].description;

				description_container.appand( name );
				description_container.appand( description );

				var slider_text_outer_container = document.createElement('div');
				slider_text_outer_container.className = "more text-center";

				var slider_text_inner_container = document.createElement('p');
				slider_text_inner_container.innerHTML = "$";
				
				
				campaign_container.append( image_container );
				campaign_container.append( description_container );
				*/

    			
    			/*
    			 can change any of the element assignments here, have access to the following values in the array:
					id
					title
					image
     				description
    				goal
    				raised
    			*/
				var container = document.createElement('div');
				container.className = "col-xs-12 col-sm-6 col-md-4";

				var image = document.createElement('img');
				image.className = "col-xs-12";
				image.src = search_results[ i_counter ].image;
				container.append( image );

				var title = document.createElement('span');
				title.className = "col-xs-12";
				title.innerHTML = search_results[ i_counter ].title+" "+search_results[ i_counter ].id;
				container.append( title );

				var raised_text = document.createElement('span');
				raised_text.className = "col-xs-12";
				raised_text.innerHTML = "Raised "+ search_results[ i_counter ].raised +" of " + search_results[ i_counter ].goal;
				container.append( raised_text );

				var description = document.createElement('span');
				description.className = "col-xs-12";
				description.innerHTML = search_results[ i_counter ].description;
				container.append( description );

				var read_more = document.createElement('a');
				read_more.className = "col-xs-12";
				read_more.href = "/campaign.php?id=" + search_results[ i_counter ].id;
				read_more.innerHTML = "Read More...";
				container.append( read_more );
				
				search_results_container.append( container );
				/*
					Dont fiddle with anything else.
				*/
    		}
    		start_index += 6;
    	}

    </script>
<?php 

require_once '_includes/footer.php';

?>