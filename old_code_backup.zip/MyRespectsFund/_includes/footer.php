
<section id="newsletter" class="for_desktop"> <!-- #newsletter starts -->
	<div class="container">
		<div class="news">
			<div class="newsarea_width newsletter_first">
				<div class="row">
					<div class="col-sm-12">	
						<h4>How We Help</h4>
						<ul>
							<li><a href="">Link Here For Help</a></li>
							<li><a href="">Link Here For Help</a></li>
							<li><a href="">Link Here For Help</a></li>
							<li><a href="">Link Here For Help</a></li>
							<li><a href="">Link Here For Help</a></li>
						</ul>
						<a href="#" class="help_linkmore">More</a>
					</div>
				</div>
			</div>
			<div class="newsarea_width newsletter_left">
				<div class="row">
					<div class="col-sm-3 text-center">
						<img class="img-responsive" src="assets/images/logo_funeral.png" alt="" />
					</div>
					<div class="col-sm-9">	
						<h5>List your Funeral Home with MyRespects</h5>
						<h4>Funeral Home Sign-Up</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
						<a href="#">Learn More</a>
					</div>
				</div>
			</div>
			<div class="newsarea_width pull-right newsletter_right">
				<div class="row">
					<div class="col-sm-12">
					<div class="newsletter_right_content fix">
							<div class="newsletter_cont_left fix">
								<img class="img-responsive" src="assets/images/icon_newsletter.png" alt="" />
							</div>
							<div class="newsletter_cont_right fix">
								<h5>The MyRespects</h5>
								<h4>E-Newsletter Sign-Up</h4>
								<form>
									<input type="email" value="" />
									<input type="submit" value="SIGN UP TODAY!" />
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> <!-- #newsletter ends -->
<section id="footer" class="for_desktop"> <!-- #footer starts -->
	<div class="container">
		<div class="col-sm-2">
			<h4>LET US HELP</h4>
			<ul>
				<li><a href="#">Ask A Question?</a></li>
				<li><a href="#">Contact Us</a></li>
				<li><a href="#">Checklist</a></li>
				<li><a href="#">Start A Campaign</a></li>
				<li><a href="#">Find A Campaign</a></li>
				<li><a href="#">Login</a></li>
			</ul>
		</div>
		<div class="col-sm-2">
			<h4>ABOUT US</h4>
			<ul>
				<li><a href="#">How We Help</a></li>
				<li><a href="#">Press / News</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>
		</div>
		<div class="center col-sm-4 text-center">
			<a class="logo" href="#"><img class="img-responsive" src="assets/images/logo_footer.png" alt="" /></a>
			<a class="ad" href="#"><img class="img-responsive" src="assets/images/secured_by.png" alt="" /></a>
		</div>
		<div class="col-sm-4 text-right flush">
			<ul class="clients">
				<li><a href="#"><img src="assets/images/cnn_money.png" alt="" /></a></li>
				<li><a href="#"><img src="assets/images/the_boston_globe.png" alt="" /></a></li>
				<li><a href="#"><img src="assets/images/time.png" alt="" /></a></li>
				<li><a href="#"><img src="assets/images/pbs.png" alt="" /></a></li>
				<li><a href="#"><img src="assets/images/bloomers_businessweek.png" alt="" /></a></li>
			</ul>
			<a id="backtotop1" href="#"><img src="assets/images/up_arrow.png" alt="" /></a>
		</div>
		
	</div>
</section> 

<footer class="footer_mobile_main_Area fix for_mobile">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
			<div class="mob_footer_contnt_wrapper fix">
				<div class="mob_footer_logo fix">
					<img src="assets/images/logo_footer.png" alt="" />
				</div>
				<div class="mob_footer_menuarea fix">
					<div id="footmenu">
						<ul>
							<li class="mobsecond_dropli"><a href="">LET US HELP</a>
								<ul class="menu_axpand">
									<li><a href="#">Ask A Question?</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Checklist</a></li>
									<li><a href="#">Start A Campaign</a></li>
									<li><a href="#">Find A Campaign</a></li>
									<li><a href="#">Login</a></li>
								</ul>
								
							</li>
							<li class="mobsecond_dropli"><a href="">ABOUT US</a>
								<ul class="menu_axpand">
									<li><a href="#">How We Help</a></li>
									<li><a href="#">Press / News</a></li>
									<li><a href="#">Contact Us</a></li>
								</ul>
							</li>
							<li><a href="">Get started</a></li>
							<li><a href="">Contact Us</a></li>
						</ul>
						
					</div>		
				</div>		
				<div class="mob_footer_funeral fix">
					<div class="mob_footer_funeral_left fix">
						<img class="img-responsive" src="assets/images/logo_funeral.png" alt="" />
					</div>	
					<div class="mob_footer_funeral_right fix">
						<h5>List your Funeral Home with MyRespects</h5>
						<h4>Funeral Home Sign-Up</h4>
						<div class="text-center">
							<a href="#">Learn More</a>
						</div>
					</div>		
				</div>		
				<div class="mob_footer_signup fix">
					<div class="mob_footer_signup_left fix">
						<img class="img-responsive" src="assets/images/icon_newsletter_mobile.png" alt="" />
					</div>	
					<div class="mob_footer_signup_right fix">
						<h5>The MyRespects</h5>
						<h4>E-Newsletter Sign-Up</h4>
						<form>
							<input type="email" value="" />
							<div class="text-center">
								<input type="submit" value="SIGN UP TODAY!" />
							</div>
						</form>
					</div>	
				</div>		
				<div class="mob_footer_clientlogo fix">
					<ul class="clients">
						<li><a href="#"><img src="assets/images/cnn_money.png" alt="" /></a></li>
						<li><a href="#"><img src="assets/images/the_boston_globe.png" alt="" /></a></li>
						<li><a href="#"><img src="assets/images/time.png" alt="" /></a></li>
						<li><a href="#"><img src="assets/images/pbs.png" alt="" /></a></li>
						<li><a href="#"><img src="assets/images/bloomers_businessweek.png" alt="" /></a></li>
					</ul>
				</div>			
			</div>		
			</div>
		</div>
	</div>

</footer>
<!-- #footer ends -->

 <!-- #copyright starts -->
<section id="copyrights">
	<div class="container">
		<div class="col-xs-12 text-center">
			<p><a href="#">Terms of Use</a> | <a href="#">Privacy Policy</a> | <a href="#">&copy; 2017 My Respects</a></p>
		</div>
	</div>
</section>
<!-- #copyright End -->



<!-- Sign up popup -->
<div id="myModal" class="modal fade pop_signup_area" role="dialog">
  <div class="modal-dialog pop_signup_dialog">

    <!-- Modal content-->
    <div class="modal-content pop_signup_content">
      <div class="modal-header pop_signup_header">
        <button type="button" class="close" data-dismiss="modal"><img src="assets/images/tala_pop.png" alt="" /></button>
        <div class="pop_logo_area fix">
			<img src="assets/images/logo_pop.png" alt="" />
		</div>
        <div class="pop_logo_botom fix">
			<h3>ACCOUNT SIGN-UP</h3>
		</div>
      </div>
      <div class="modal-body pop_signup_body">
       <div class="fb_btnarea fix">
			<a class="fb_imgbtn_singup" onclick="javascript: fbcheckLoginState();">
				<img src="assets/images/fb-login.png" alt="" />
			</a>
			<p><small>We will never post without your permission.</small></p>
		</div>
        <div class="email_btnarea fix">
			<a href="" class="email_imgbtn_singup" data-dismiss="modal" data-toggle="modal" data-target="#myModal_email">
				<img src="assets/images/mail_login.png" alt="" />
			</a>
		</div>
      </div>
      <div class="modal-footer pop_signup_footer">
		<div class="pop_signup_footer_text fix text-center">
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
			et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi 
			ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate,
			By continuing, you agree with the My Respects fees, terms and privacy policy.</p>
		</div>
      </div>
    </div>

  </div>
</div>
<!-- Sign up popup-->

<!-- Sign In popup Start-->
<div id="myModal_login" class="modal fade pop_signup_area" role="dialog">
  <div class="modal-dialog pop_signup_dialog">

    <!-- Modal content-->
    <div class="modal-content pop_signup_content">
      <div class="modal-header pop_signup_header">
        <button type="button" class="close" data-dismiss="modal"><img src="assets/images/tala_pop.png" alt="" /></button>
        <div class="pop_logo_area fix">
			<img src="assets/images/logo_pop.png" alt="" />
		</div>
        <div class="pop_logo_botom fix">
			<h3>ACCOUNT Login</h3>
		</div>
      </div>
      <div class="modal-body pop_signup_body">
		<div class="login_form_area fix">
			<form action="" method="POST" id="login-form">
				<input type="hidden" name="login_nonce" value="<?php echo $_SESSION['login_nonce']; ?>" />
				<input type="hidden" name="form-name" value="login-form" />
				<div class="login_form_wrapper fix">
					<div class="login_form_input_wrap fix">
						<div class="login_form_left fix col-sm-6">
							<div class="form_input_area fix">
								<label for="">Username</label>
								<input type="text" class="form_input_field" id="user-email" name="user-email" />
							</div>
						</div>
						<div class="login_form_right fix col-sm-6">
							<div class="form_input_area fix">
								<label for="">Password</label>
								<input type="password" class="form_input_field" id="user-password" name="user-password" />
								<p class="forgot_text"><a id="forgot-password-link">Forgot Password?</a></p>
								
							</div>
						</div>
					</div>
					<div class="login_form_input_wrap fix">
						<?php if ( !isset( $_SESSION['login'] ) || $_SESSION['login'] === FALSE ) { ?>
							<div class="g-signin2" data-onsuccess="google_login"></div>
						<?php } else { ?>
							<div class="g-signin2" style="display:none;"></div>
						<?php } ?>
					</div>
					<div class="login_form_submit_wrap fix">
						<div class="login_form_left fix col-sm-6">
							<div class="form_capccha_area fix">
								<div class="g-recaptcha" data-sitekey="6LfVPikUAAAAAFjUXMGqRQmGRvO4eqbSqwyB-Sjp"></div>
							</div>
						</div>
						<div class="login_form_right fix col-sm-6">
							<div class="form_input_area fix">
								<input type="submit" id="login-submit" name="login-submit" value="login" class="form_submit_field"/>
							</div>
						</div>
					</div>			
				</div>			
			</form>
		</div>
      </div>
      <div class="modal-footer pop_signup_footer">
		<div class="pop_signup_footer_text fix text-center">
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
			et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi 
			ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate,
			By continuing, you agree with the My Respects fees, terms and privacy policy.</p>
		</div>
      </div>
    </div>

  </div>
</div>
<!-- Sign In popup End-->

<!-- Forgot Password popup Start-->
<div id="myModal_forgotpassword" class="modal fade pop_signup_area" role="dialog">
  <div class="modal-dialog pop_signup_dialog">

    <!-- Modal content-->
    <div class="modal-content pop_signup_content">
      <div class="modal-header pop_signup_header">
        <button type="button" class="close" data-dismiss="modal"><img src="assets/images/tala_pop.png" alt="" /></button>
        <div class="pop_logo_area fix">
			<img src="assets/images/logo_pop.png" alt="" />
		</div>
        <div class="pop_logo_botom fix">
			<h3>Forgot Password</h3>
		</div>
      </div>
      <div class="modal-body pop_signup_body">
		<div class="login_form_area fix">
			<form method="POST" id="password-reset-form">
				<input type="hidden" name="login_nonce" value="<?php echo $_SESSION['login_nonce']; ?>" />
				<input type="hidden" name="form-name" value="password-reset-form" />
				<div class="login_form_wrapper fix">
					<div class="login_form_input_wrap fix">
						<div class="login_form_left fix col-sm-6">
							<div class="form_input_area fix">
								<label for="user-email">Email Address</label>
								<input type="text" class="form_input_field" id="user-email" name="user-email" />
							</div>
						</div>
						<div class="login_form_right fix col-sm-6">
							<div class="form_input_area fix">
								<input type="submit" id="password-reset-submit" name="login-submit" value="Reset" class="form_submit_field"/>
							</div>
						</div>
					</div>
				</div>			
			</form>
		</div>
      </div>
      <div class="modal-footer pop_signup_footer">
		<div class="pop_signup_footer_text fix text-center">
			<p>We will email you a new password.</p>
		</div>
      </div>
    </div>

  </div>
</div>
<!-- Forgot Password popup End-->

<!-- Email Sign up popup Start-->
<div id="myModal_email" class="modal fade pop_signup_area" role="dialog">
  <div class="modal-dialog pop_signup_dialog">

    <!-- Modal content-->
    <div class="modal-content pop_signup_content">
      <div class="modal-header pop_signup_header">
        <button type="button" class="close" data-dismiss="modal"><img src="assets/images/tala_pop.png" alt="" /></button>
        <div class="pop_logo_area fix">
			<img src="assets/images/logo_pop.png" alt="" />
		</div>
        <div class="pop_logo_botom fix">
			<h3>ACCOUNT SIGN-UP WITH E-MAIL</h3>
		</div>
      </div>
      <div class="modal-body pop_signup_body">
		<div class="emaillogin_form_title fix">
			<h2>Your Real Information</h2>
		</div>
		<div class="login_form_area fix">
			<form action="" id="email-signup-form" name="email-signup-form">
				<div class="login_form_wrapper fix">
					<div class="login_form_input_wrap fix">
						<div class="login_form_left fix col-sm-6">
							<div class="form_input_area fix">
								<label for="first_name">First Name</label>
								<input type="text" class="form_input_field" name="first_name" id="first_name" />
							</div>
						</div>
						<div class="login_form_right fix col-sm-6">
							<div class="form_input_area fix">
								<label for="last_name">Last Name</label>
								<input type="text" class="form_input_field" name="last_name" id="last_name" />								
							</div>
						</div>
						<div class="login_form_fullinput fix col-sm-12">
							<div class="form_input_area fix">
								<label for="user-email">Your Email Address (one that you check often)</label>
								<input type="email" class="form_input_field" name="user-email" id="user-email" />						
							</div>
							<div class="form_input_area fix">
								<label for="confirm_email">Confirm Your Email Address</label>
								<input type="email" class="form_input_field" name="confirm_email" id="confirm_email" />						
							</div>
							<div class="form_input_area fix">
								<label for="user-password">Create Your Password</label>
								<input type="password" class="form_input_field" id="user-password" name="user-password" />						
							</div>
						</div>
					</div>		
				</div>			
			</form>
		</div>
      </div>
      <div class="modal-footer pop_signup_footer">
		<div class="pop_signup_footer_text fix text-center">
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
			et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi 
			ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate,
			By continuing, you agree with the My Respects fees, terms and privacy policy.</p>
			<div class="my_res_signbtn_area fix">
				<a href="" class="myres_sinup_imgbtn" id="email_sign_up_button"><img src="assets/images/plus_login.png" alt="" /></a>
			</div>
		</div>
      </div>
    </div>

  </div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		
		$('#email_sign_up_button').click(function(e) {
			e.preventDefault();
			$.ajax( {
				type: "POST",
			    url: "./ajax/create-account.php",
			    data: $('#email-signup-form').serialize(),
			    success: function( response ) {
			    	var resp_obj = JSON.parse( response );
					if(resp_obj.result == 'Success') {
						console.log(resp_obj);
					} else {
						console.log(resp_obj.message);
					}
			    	
				}
			});
		});


		$('#forgot-password-link').click(function(e) {
			$('#myModal_login').modal('hide');
			$('#myModal_forgotpassword').modal('show');
		});

		$('#password-reset-submit').click(function(e) {
			e.preventDefault();
			$.ajax( {
				type: "POST",
			    url: "./ajax/reset-password.php",
			    data: $('#password-reset-form').serialize(),
			    success: function( response ) {
				    console.log(response);
			    	var resp_obj = JSON.parse( response );
					$('').html('<div class="text-center">'+resp_obj.msg+'</div>');
				}
			});
		});
		
	});

</script>
<!-- Sign up popup End-->

<script type='text/javascript' src="assets/js/bootstrap.js"></script>
<script type='text/javascript' src="assets/js/bootstrap-tour.min.js"></script>
<script type='text/javascript' src="assets/js/jquery.bxslider.js"></script>
<script type='text/javascript' src="assets/js/jquery.meanmenu.min.js"></script>
<script type='text/javascript' src="assets/js/main.js"></script>
<script type='text/javascript' src="assets/js/moment.min.js"></script>
<script type='text/javascript' src="assets/js/bootstrap-datetimepicker.min.js"></script>

<script>

	window.fbAsyncInit = function() {
		FB.init({
			appId      : '392737507767162',
			xfbml      : true,
			version    : 'v2.8'
		});
		FB.AppEvents.logPageView();

	};

	(function(d, s, id){
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.id = id;
		js.src = "//connect.facebook.net/en_US/sdk.js";
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));

	function fbcheckLoginState() {
		FB.getLoginStatus(function(response) {
			if (response.status === 'connected') {

				var input = document.createElement('input');
				input.type = "hidden";
				input.name = "facebook-token";
				input.value = response.authResponse.accessToken;

				var form = document.getElementById('login-form');
				form.append( input );

				form.submit();
				
			} else {
				FB.login(function(response){
					if (response.status === 'connected') {

						var input = document.createElement('input');
						input.type = "hidden";
						input.name = "facebook-token";
						input.value = response.authResponse.accessToken;

						var form = document.getElementById('login-form');
						form.append( input );

						form.submit();
						
					} else {
						
						
					}
				},{scope: 'public_profile,email'});
			}
		});
	}

	function share_on_fb( url ) {
		FB.ui({
			method: 'share',
			href: url,
		}, function(response){});
	}

	 
	function google_login( googleUser ){

		var input = document.createElement('input');
		input.type = "hidden";
		input.name = "google-token";
		input.value = googleUser.getAuthResponse().id_token;

		var form = document.getElementById('login-form');
		form.append( input );

// 		form.submit();
	}


	function sign_out(){
		<?php
		/* 
		 - we need to check if they are social login or not
		var auth2 = gapi.auth2.getAuthInstance();
		auth2.signOut().then(function () {
			console.log('User signed out.');
		});
		*/
		?>
		
		FB.logout(function(){});
		
		var form = document.createElement('form');
		form.method = "POST";

		var input = document.createElement('input');
		input.type = "hidden";
		input.name = "form-name";
		input.value = "logout";

		form.append( input );
		document.body.append( form );

		form.submit(); 
	}

	var sign_out_btn = document.getElementById('sign-out');
	if ( sign_out_btn ) {
		sign_out_btn.addEventListener("click", function(){ sign_out() } );
	}

</script>

<!-- Add to Calendar -->
<script type="text/javascript">
		(function () {
            if (window.addtocalendar)if(typeof window.addtocalendar.start == "function")return;
            if (window.ifaddtocalendar == undefined) { window.ifaddtocalendar = 1;
                var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
                s.type = 'text/javascript';s.charset = 'UTF-8';s.async = true;
                s.src = ('https:' == window.location.protocol ? 'https' : 'http')+'://addtocalendar.com/atc/1.5/atc.min.js';
                var h = d[g]('body')[0];h.appendChild(s); }})();
</script>
    
<!-- Twiter js -->
<script>
	window.twttr = (function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0],
		t = window.twttr || {};
		if (d.getElementById(id)) return t;
		js = d.createElement(s);
		js.id = id;
		js.src = "https://platform.twitter.com/widgets.js";
		fjs.parentNode.insertBefore(js, fjs);

		t._e = [];
		t.ready = function(f) {
			t._e.push(f);
		};

		return t;
	}(document, "script", "twitter-wjs"));
</script>

<script>
	$('.datepicker').each(function(k,v){
		if ( $(v).data('date') ) {
			$(v).datetimepicker({
				format: 'MM/DD/YYYY',
				defaultDate: $(v).data('date') 
			});
		} else {
			$(v).datetimepicker({
				format: 'MM/DD/YYYY'
			});
		}
	});
</script>

<!-- For Google Login -->
<script src="https://apis.google.com/js/platform.js" async defer></script>
<script src='https://www.google.com/recaptcha/api.js'></script>

<script type='text/javascript' src='assets/js/jquery.mask.js'></script>

</body>
</html>