<header id="header" class="for_desktop profile_page">
<div class="border_bottom_head top-top-bg fix">
	    <img class="top" src="assets/images/bg_header.jpg" alt="">
		<img src="assets/images/profile_head_bottom.jpg" alt="" />
	</div>
</header> 
  
<header class="for_mobile mobile_header_areamain fix">
	<div class="border_bottom_head fix">
		<img src="assets/images/profile_head_bottom.jpg" alt="" />
	</div>
	<div class="header_top_area fix">
		<div class="header_logo_area fix">
			<img src="assets/images/logo_mobile.png" alt="" />
			<a id="searchkoro" href="#"><img src="assets/images/search_mob.png" alt="" /></a>
		</div>
		<div class="topbar mobile_top">
			<div class="col-xs-12 text-right">
				<div class="search_area fix">
					<form>
						<label>SEARCH</label>
						<input type="search" placeholder="Lorem ipsum dolor...." />
						<input class="bglight" type="submit" value="">
					</form>
				</div>

			</div>
		</div>
	</div>
	<div class="header_menu_area fix">
		<div id="mob_menu_main">
			<ul class="mobile_menu">
				<li><a href="">Home</a></li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a>
					<ul>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
					</ul>
				</li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a>
					<ul>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
						<li><a href="">Navigation</a>
					</ul>
				</li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a></li>
				<li><a href="">Navigation</a></li>
			</ul>
		</div>
	</div>


</header>
 <!-- header ends -->