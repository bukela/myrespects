<header id="header" class="for_desktop <?php echo isset( $page ) ? $page : ''; ?>">
	 <div class="topbar desktop_search">
	     <div class="container">
			<div class="col-sm-12">
				   <div class="col-sm-6 text-left">
				       <button type="button" class="close_btn desktop_clos">X CLOSE SEARCH</button>
			    </div>
			    <div class="col-sm-6 text-right">
	   				<div class="search_area fix">
	   					<form id="search-form" method="GET" action="/search-result.php" onsubmit="javascript:search_form_submit(this);">
	    					<label>SEARCH</label>
	    					<input type="search" id="search-field" name="term" placeholder="Search by Name, Zip Code, or Title" />
	    					<input class="bglight" type="submit" value="">
	    				</form>
	    			</div>
				</div>
			</div>
		</div>   
	</div> 
	<div class="container">
		<div class="header_main_area fix">
			<div class="header_logoarea fix">
				<a href="/"><img src="assets/images/logo.png" alt="" /></a>
			</div>
			<div class="header_maenuarea fix">
				<ul id="main_menu">
					<?php if ( !isset( $page ) || ( isset( $page ) && $page != 'profile_page' ) ) { ?>
					<li><a href="/search-result.php">FIND A CAMPAIGN</a></li>
					<?php } ?>
					<li><a href="start-campaign.php">start a fund now</a></li>
				</ul>
			</div>
			<div class="header_searcharea fix">
				<div class="header_signuplgin fix">
					<ul>
						<?php 
						if ( $o_user->is_logged_in() ) {
						?>
							<li class="signup"><a href="/campaign-dashboard.php">Profile</a></li> 
							<li class="login"><a id="sign-out">LOG-OUT</a></li>
						<?php 
						} else {
						?>
							<li class="signup"><a href="#" data-toggle="modal" data-target="#myModal">SIGN-UP</a></li> 
							<li class="login"><a href="#"  data-toggle="modal" data-target="#myModal_login">LOG-IN</a></li>						
						<?php 
						}
						?> 
					</ul>
				</div>
				<div class="header_search_icon fix">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown active">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img class="cros_img" src="assets/images/icon_close.png" alt="" /><img class="bar_img" src="assets/images/menubar.png" alt="" /></a>
							<ul class="dropdown-menu">
								<li><a href="#">Start A Campaign</a></li>
								<li><a href="#">How We Help</a></li>
								<li><a href="#">Toolkit</a></li>
								<li><a href="#">Help</a></li>
								<li><a href="#">Become an Affiliate</a></li>
							</ul>
						</li>
						<li>
							<a id="search" href="#"><img src="assets/images/icon_search.png" alt="" /></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		
		
	</div>
</header>  

 <div class="topbar mobile_search">
     <div class="container">
			<div class="col-sm-12">
			    <div class="col-sm-6 col-xs-4 text-left">
			        <button type="button" class="close_btn mobile_clos">X CLOSE SEARCH</button>
			    </div>
			    <div class="col-sm-6 col-xs-8 text-right">
    				<div class="search_area fix">
    					<form>
    						<label>SEARCH</label>
    						<input type="search" placeholder="Lorem ipsum dolor...." />
    						<input class="bglight" type="submit" value="">
    					</form>
    				</div>
				</div>

			</div>
		</div>   
    </div>
    
<header class="for_mobile mobile_header_areamain fix">
<div class="header_top_area fix">
	<div class="header_logo_area fix">
		<img src="assets/images/logo_mobile.png" alt="" />
		<a id="searchkoro" href="#"><img src="assets/images/search_mob.png" alt="" /></a>
	</div>
	<div class="topbar mobile_top">
		<div class="col-xs-12 text-right">
			<div class="search_area fix">
				<form>
					<label>SEARCH</label>
					<input type="search" placeholder="Lorem ipsum dolor...." />
					<input class="bglight" type="submit" value="">
				</form>
			</div>

		</div>
	</div>
</div>
<div class="header_menu_area fix">
	<div id="mob_menu_main">
		<ul class="mobile_menu">
			<li><a href="">Home</a></li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a>
				<ul>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
				</ul>
			</li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a>
				<ul>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
					<li><a href="">Navigation</a>
				</ul>
			</li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a></li>
			<li><a href="">Navigation</a></li>
		</ul>
	</div>
</div>


</header>
<!-- header ends -->

