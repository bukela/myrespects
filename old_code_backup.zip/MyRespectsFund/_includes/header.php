<?php 

session_start();

/*
 * very basic pw protection of app... redirect to coming soon page
 */
if ( isset( $_POST['verify'] ) && $_POST['verify'] == "app4myrespects17" ) {
	$_SESSION['auth'] = 'verified';
}

if ( $_SESSION['auth'] != 'verified' ) {
	header( 'location: /coming-soon.php' );
	die();
}

require_once '_includes/static_variables.php';

include_once 'classes/db_base.php';
$o_db = new db_base();

/* for login */
include_once 'classes/user_base.php';

if ( isset( $_POST['form-name'] ) && $_POST['form-name'] == 'logout' ) {
	
	$_SESSION['login'] = FALSE;
	unset( $_SESSION['user_base'] );
}

if ( isset( $_SESSION['user_base'] ) && !empty( $_SESSION['user_base'] ) ) {
	$o_user = unserialize( $_SESSION['user_base'] );
	echo "<!-- LOGGED IN -->";
} else {
	$o_user = new user_base( $o_db );
}

if ( isset( $_POST['form-name'] ) && $_POST['form-name'] == 'login-form' && $_POST['login_nonce'] == $_SESSION['login_nonce'] ) {
	
	if ( $o_user->login( $_POST ) === TRUE ) {
		
		$_SESSION['login'] = TRUE;
		$_SESSION['user_base'] = serialize( $o_user );
		
	} else {
		
		$_SESSION['login'] = FALSE;
		unset( $_SESSION['user_base'] );
	}
}

/* for login security */
$_SESSION['login_nonce'] = sha1( "extra-security-nonce".microtime( true ) );

/* END for login */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    	<meta name="google-signin-client_id" content="40989211664-2lg8e805sqer9lu7op17stlo6e4mttn4.apps.googleusercontent.com">
		
		<?php echo isset( $additional_meta ) ? $additional_meta : ''; ?>
		<title>My Respects | WELCOME</title>
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/css?family=Antic+Slab" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Volkhov:400,400i,700,700i" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.css">
		<link type="text/css" rel="stylesheet" href="assets/css/jquery.bxslider.css" />
		<link href="assets/css/bootstrap-slider.css" rel="stylesheet">
		<link href="assets/css/bootstrap-tour.min.css" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="assets/css/meanmenu.min.css" />
		<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
		<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />
		<link type="text/css" rel="stylesheet" href="assets/css/addtocalendar.css" />
		<link type="text/css" rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css" />
		
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<?php // moved up to header because of broken search results page if it is not loaded before page renders ?>
		<script type='text/javascript' src="assets/js/bootstrap-slider.js"></script>
	</head>
<body>

<?php
	if ( isset( $page ) && in_array( $page, array( 'campaign-dashboard' ) ) ) {
		include 'campaign_dashboard_header.php';
	} elseif ( isset( $page ) && in_array( $page, array( 'partner-dashboard' ) ) ) {
		include 'partner_dashboard_header.php';
	} else {
		include 'main_header.php';
	}
?>