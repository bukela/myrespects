/* user table changes */
ALTER TABLE `my_respects_fund`.`user` 
ADD COLUMN `wepay_user_id` INT(10) NULL COMMENT '' AFTER `user_id`,
ADD COLUMN `wepay_access_token` VARCHAR(256) NULL COMMENT '' AFTER `picture_from`,
ADD COLUMN `wepay_token_type` VARCHAR(64) NULL COMMENT '' AFTER `wepay_access_token`,
ADD COLUMN `wepay_token_expires` INT(10) NULL COMMENT '' AFTER `wepay_token_type`;


/* user update for wepay integration */
USE `my_respects_fund`;
DROP procedure IF EXISTS `user_update_wepay_by_email`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `user_update_wepay_by_email` (
	IN v_email VARCHAR(256),
    IN v_wepay_user_id INT(10),
    IN v_wepay_access_token VARCHAR(256),
    IN v_wepay_token_type VARCHAR(64),
    IN v_wepay_token_expires INT(10)
)
BEGIN

	UPDATE user SET
		wepay_user_id = v_wepay_user_id,
		wepay_access_token = v_wepay_access_token, 
        wepay_token_type = v_wepay_token_type,
        wepay_token_expires = v_wepay_token_expires
	WHERE 
		email = v_email;

END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_wepay_token_by_user_id`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_wepay_token_by_user_id` (
	IN v_user_id INT(10)
)
BEGIN

	SELECT wepay_access_token FROM user WHERE user_id = v_user_id;

END
$$

DELIMITER ;

/* campaign table changes */
ALTER TABLE `my_respects_fund`.`campaign` 
ADD COLUMN `wepay_account_id` INT(10) UNSIGNED NULL COMMENT '' AFTER `user_id`,
ADD COLUMN `wepay_account_state` VARCHAR(64) NULL COMMENT '' AFTER `campaign_story`;

/* camapaign update SP */
USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_update_wepay_by_id`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `campaign_update_wepay_by_id` (
	IN v_campaign_id INT(10),
    IN v_wepay_account_id INT(10),
    IN v_wepay_account_state VARCHAR(64)
)
BEGIN

	UPDATE campaign SET
		wepay_account_id = v_wepay_account_id,
        wepay_account_state = v_wepay_account_state
	WHERE campaign_id = v_campaign_id;

END
$$

DELIMITER ;


/* pre-approval */

CREATE TABLE `my_respects_fund`.`preapproval` (
  `preapproval_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `amount` FLOAT(2) NULL COMMENT '',
  `description` VARCHAR(128) NULL COMMENT '',
  `name` VARCHAR(128) NULL COMMENT '',
  `wepay_preapproval_id` INT(10) NULL COMMENT '',
  `ts_modified` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '',
  `ts_created` VARCHAR(45) NULL COMMENT '',
  PRIMARY KEY (`preapproval_id`)  COMMENT '',
  UNIQUE INDEX `preapproval_id_UNIQUE` (`preapproval_id` ASC)  COMMENT '');


/* above was run on prod */