/*
 * SQL for sprint 1
 * SQL files should be used as release scripts where applicable.
 * These files should not be pushed to production.
 */

/* create schema */ 
CREATE SCHEMA `my_respects_fund` ;

/* image tables */

CREATE TABLE `my_respects_fund`.`user_image` (
  `user_image_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `user_id` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT '',
  `image_name` VARCHAR(260) NOT NULL COMMENT '',
  `container_name` VARCHAR(45) NOT NULL COMMENT '',
  `image_size` INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '',
  `image_type` VARCHAR(16) NOT NULL COMMENT '',
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP COMMENT '',
  PRIMARY KEY (`user_image_id`)  COMMENT '',
  UNIQUE INDEX `user_image_id_UNIQUE` (`user_image_id` ASC)  COMMENT '')
ENGINE = MyISAM;

USE `my_respects_fund`;
DROP procedure IF EXISTS `user_image_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `user_image_insert` (
	IN v_user_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO user_image
		(user_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_user_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'user_image_id';
END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `user_image_delete`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `user_image_delete` (
	IN v_user_image_id INT(10)
)
BEGIN
	DELETE FROM user_image WHERE user_image_id = v_user_image_id;
END
$$

DELIMITER ;



CREATE TABLE `my_respects_fund`.`campaign_image` (
  `campaign_image_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `campaign_id` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT '',
  `image_name` VARCHAR(260) NOT NULL COMMENT '',
  `container_name` VARCHAR(45) NOT NULL COMMENT '',
  `image_size` INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '',
  `image_type` VARCHAR(16) NOT NULL COMMENT '',
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP COMMENT '',
  PRIMARY KEY (`campaign_image_id`)  COMMENT '',
  UNIQUE INDEX `campaign_image_id_UNIQUE` (`campaign_image_id` ASC)  COMMENT '')
ENGINE = MyISAM;

USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_image_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `campaign_image_insert` (
	IN v_campaign_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO campaign_image
		(campaign_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_campaign_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'campaign_image_id';
END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_image_delete`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `campaign_image_delete` (
	IN v_campaign_image_id INT(10)
)
BEGIN
	DELETE FROM campaign_image WHERE campaign_image_id = v_campaign_image_id;
END
$$

DELIMITER ;



CREATE TABLE `my_respects_fund`.`funeral_home_image` (
  `funeral_home_image_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `funeral_home_id` INT(10) UNSIGNED NULL DEFAULT NULL COMMENT '',
  `image_name` VARCHAR(260) NOT NULL COMMENT '',
  `container_name` VARCHAR(45) NOT NULL COMMENT '',
  `image_size` INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '',
  `image_type` VARCHAR(16) NOT NULL COMMENT '',
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP COMMENT '',
  PRIMARY KEY (`funeral_home_image_id`)  COMMENT '',
  UNIQUE INDEX `funeral_home_image_id_UNIQUE` (`funeral_home_image_id` ASC)  COMMENT '')
ENGINE = MyISAM;

USE `my_respects_fund`;
DROP procedure IF EXISTS `funeral_home_image_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `funeral_home_image_insert` (
	IN v_funeral_home_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO funeral_home_image
		(funeral_home_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_funeral_home_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'funeral_home_image_id';
END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `funeral_home_image_delete`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `funeral_home_image_delete` (
	IN v_funeral_home_image_id INT(10)
)
BEGIN
	DELETE FROM funeral_home_image WHERE funeral_home_image_id = v_funeral_home_image_id;
END
$$

DELIMITER ;


/* log table */
CREATE TABLE `my_respects_fund`.`general_log` (
  `general_log_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `user_id` INT(10) NULL COMMENT '',
  `campaign_id` INT(10) NULL COMMENT '',
  `funeral_home_id` INT(10) NULL COMMENT '',
  `log_type` VARCHAR(64) NULL COMMENT '',
  `log_event` VARCHAR(512) NULL COMMENT '',
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP COMMENT '',
  PRIMARY KEY (`general_log_id`)  COMMENT '',
  UNIQUE INDEX `general_log_id_UNIQUE` (`general_log_id` ASC)  COMMENT '');

USE `my_respects_fund`;
DROP procedure IF EXISTS `general_log_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `general_log_insert` (
	IN v_user_id int(10),
	IN v_campaign_id int(10),
	IN v_funeral_home_id int(10),
	IN v_log_type varchar(64),
	IN v_log_event varchar(512)
)
BEGIN

	INSERT INTO general_log
		(user_id, campaign_id, funeral_home_id, log_type, log_event)
	VALUES
		(v_user_id, v_campaign_id, v_funeral_home_id, v_log_type, v_log_event);
END
$$

DELIMITER ;






/* test table - for testing db_base */
CREATE TABLE `my_respects_fund`.`test_table` (
  `test_table_id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `test_value` VARCHAR(45) NOT NULL COMMENT '',
  `ts_created` TIMESTAMP NULL COMMENT '',
  PRIMARY KEY (`test_table_id`)  COMMENT '',
  UNIQUE INDEX `test_table_id_UNIQUE` (`test_table_id` ASC)  COMMENT '');

/* get rid of the table - don't need this table, use above SQL to generate to test */
DROP TABLE `my_respects_fund`.`test_table`

/* test stored procs */

USE `my_respects_fund`;
DROP procedure IF EXISTS `test_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `test_insert` (
	IN  v_test_val VARCHAR(45)
)
BEGIN
	INSERT INTO test_table (test_value) VALUES (v_test_val);
    SELECT LAST_INSERT_ID() as `last_insert_id`;
END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `test_insert`;

USE `my_respects_fund`;
DROP procedure IF EXISTS `test_select`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `test_select` (
	IN v_id INT(10)
)
BEGIN
	SELECT * FROM test_table WHERE test_table_id >= v_id;
END
$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `test_select`;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(256) DEFAULT NULL,
  `last_name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `user_level` varchar(45) NOT NULL DEFAULT 'basic',
  `zip` varchar(5) DEFAULT NULL,
  `picture` text,
  `picture_from` varchar(32) DEFAULT NULL,
  `created_by` enum('google','facebook','normal') DEFAULT NULL,
  `ts_last_login` timestamp NULL DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`));

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_exists`(
	IN v_email_address VARCHAR(256)
)
BEGIN
	SELECT EXISTS( SELECT 1 FROM user WHERE email = v_email_address );
END ;;
DELIMITER ;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_password`(
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256)
)
BEGIN
	IF EXISTS( SELECT 1 FROM user WHERE `email` = v_email AND `password` = v_password ) THEN
		BEGIN
			SELECT `email`, `first_name`, `last_name`, `picture` FROM user WHERE `email` = v_email;
		END;
	ELSE
		BEGIN
			SELECT 0;
		END;
	END IF;
END ;;
DELIMITER ;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_user`(
	IN v_first_name VARCHAR(256),
	IN v_last_name VARCHAR(256),
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256),
	IN v_picture TEXT,
	IN v_picture_from VARCHAR(32),
	IN v_created_by ENUM('google','facebook','normal')
)
BEGIN

	INSERT INTO user (`first_name`,`last_name`,`email`,`password`,`picture`,`picture_from`,`created_by`,`ts_created`)
						VALUES
					 (v_first_name,v_last_name,v_email,v_password,v_picture,v_picture_from,v_created_by,NOW());
	
	SELECT last_insert_id();
END ;;
DELIMITER ;

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_last_login`(
	IN v_email VARCHAR(256)
)
BEGIN
	UPDATE user SET `ts_last_login` = NOW() WHERE `email` = v_email;
END ;;
DELIMITER ;

/* all above have been run on prod */