ALTER TABLE `my_respects_fund`.`user` 
ADD COLUMN `is_admin` INT(1) UNSIGNED NULL DEFAULT 0 AFTER `wepay_token_expires`;

USE `my_respects_fund`;
DROP procedure IF EXISTS `check_user_is_admin`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `check_user_is_admin` (
	IN v_user_id INT(10)
)
BEGIN

	SELECT EXISTS( SELECT 1 FROM user WHERE user_id = v_user_id AND is_admin = 1 );

END$$

DELIMITER ;

/* above was run on prod */