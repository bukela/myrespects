USE `my_respects_fund`;
DROP procedure IF EXISTS `get_user_campaign`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_user_campaign` (
	IN v_user_id INT(10)
)
BEGIN
	SELECT `campaign_id` FROM campaign WHERE `user_id` = v_user_id LIMIT 1;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_insert`(
	IN v_user_id INT(10),
	IN v_funeral_home_id INT(10),
	IN v_campaign_image_id INT(10),
	IN v_campaign_title VARCHAR(256),
	IN v_campaign_goal INT(10), 
	IN v_campaign_zip INT(5),
	IN v_campaign_story TEXT
)
BEGIN

	INSERT INTO campaign
		(user_id, funeral_home_id, campaign_image_id, campaign_title, campaign_goal, campaign_zip, campaign_story,ts_created)
	VALUES
		(v_user_id, v_funeral_home_id, v_campaign_image_id, v_campaign_title, v_campaign_goal, v_campaign_zip, v_campaign_story,NOW());
	
    SELECT LAST_INSERT_ID() as `campaign_id`;
END$$

DELIMITER ;


ALTER TABLE `my_respects_fund`.`user` 
ADD COLUMN `phone_number` VARCHAR(10) NULL AFTER `email`,
ADD COLUMN `address` VARCHAR(256) NULL AFTER `user_level`,
ADD COLUMN `city` VARCHAR(256) NULL AFTER `address`,
ADD COLUMN `state` VARCHAR(2) NULL AFTER `city`,
ADD COLUMN `dob` DATE NULL AFTER `zip`;


USE `my_respects_fund`;
DROP procedure IF EXISTS `update_user_info`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `update_user_info` (
	IN v_user_id INT(10),
	IN v_first_name VARCHAR(256),
	IN v_last_name VARCHAR(256),
	IN v_email VARCHAR(250),
	IN v_address VARCHAR(256),
	IN v_city VARCHAR(256),
	IN v_state VARCHAR(2),
	IN v_zip INT(5),
	IN v_phone_number VARCHAR(10),
	IN v_dob DATE
)
BEGIN

	UPDATE 
		`user` 
	SET 
		`first_name` = v_first_name, `last_name` = v_last_name, `email` = v_email,
		`address` = v_address, `city` = v_city, `state` = v_state, `zip` = v_zip,
		`phone_number` = v_phone_number, `dob` = v_dob
	WHERE user_id = v_user_id;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_insert`;



ALTER TABLE `my_respects_fund`.`campaign` 
ADD COLUMN `campaign_end` DATE NULL AFTER `campaign_story`;


DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_insert`(
	IN v_user_id INT(10),
	IN v_funeral_home_id INT(10),
	IN v_campaign_image_id INT(10),
	IN v_campaign_title VARCHAR(256),
	IN v_campaign_goal INT(10), 
	IN v_campaign_zip INT(5),
	IN v_campaign_story TEXT,
	IN v_campaign_end DATE
)
BEGIN

	INSERT INTO campaign
		(user_id, funeral_home_id, campaign_image_id, campaign_title, campaign_goal, campaign_zip, campaign_story, campaign_end, ts_created)
	VALUES
		(v_user_id, v_funeral_home_id, v_campaign_image_id, v_campaign_title, v_campaign_goal, v_campaign_zip, v_campaign_story, v_campaign_end, NOW());
	
    SELECT LAST_INSERT_ID() as `campaign_id`;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_search_results`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_results`(
	v_search_value TEXT,
	v_start_index INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' )
	GROUP BY
		c.campaign_id	
	ORDER BY
		c.ts_created DESC
	LIMIT v_start_index, 20;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_id = v_campaign_id;
END$$


DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `reset_password`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `reset_password`( 
	IN v_email_address VARCHAR(256),
	IN v_new_password VARCHAR(256)
)
BEGIN

	UPDATE `user` SET `password` = MD5( v_new_password ) WHERE `email` = v_email_address;

	SELECT ROW_COUNT();
END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_local_campaigns`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_local_campaigns` (
	IN v_lat float,
	IN v_lng float
)
BEGIN

	SELECT
		* 
	FROM
		campain
	WHERE
		campaign_zip IN (	SELECT
								`zip_code`,
								(
									6371 *
									acos(
										cos( radians( v_lat ) ) *
										cos( radians( `lat` ) ) *
										cos(
											radians( `lng` ) - radians( v_lng )
										) +
										sin(radians( v_lat )) *
										sin(radians( `lat` ))
									)
								) as `distance`
							FROM
								`zip_code_info`
							HAVING
								`distance` < 10
							ORDER BY
								`distance`
						);

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_local_campaigns`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_local_campaigns`(
	IN v_lat float,
	IN v_lng float
)
BEGIN

	SELECT
		* 
	FROM
		campaign
	WHERE
		campaign_zip IN ( SELECT 
							`zip_code`
							FROM 
								(	
									SELECT
										`zip_code`,
										(
											6371 *
											acos(
												cos( radians( v_lat ) ) *
												cos( radians( `lat` ) ) *
												cos(
													radians( `lng` ) - radians( v_lng )
												) +
												sin(radians( v_lat )) *
												sin(radians( `lat` ))
											)
										) as `distance`
									FROM
										`zip_code_info`
									HAVING
										`distance` < 10
									ORDER BY
										`distance`
								) zip 
							);

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_local_campaigns`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_local_campaigns`(
	IN v_lat float,
	IN v_lng float
)
BEGIN


	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_zip IN 
			( SELECT 
				`zip_code`
				FROM 
					(	
						SELECT
							`zip_code`,
							(
								6371 *
								acos(
									cos( radians( v_lat ) ) *
									cos( radians( `lat` ) ) *
									cos(
										radians( `lng` ) - radians( v_lng )
									) +
									sin(radians( v_lat )) *
									sin(radians( `lat` ))
								)
							) as `distance`
						FROM
							`zip_code_info`
						HAVING
							`distance` < 10
						ORDER BY
							`distance`
					) zip 
				)
	GROUP BY
		c.campaign_id	
	ORDER BY
		c.ts_created DESC
	LIMIT 8;



END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_highest_funded`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_highest_funded`()
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	GROUP BY
		c.campaign_id	
	ORDER BY
		raised DESC
	LIMIT 8;

END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `update_campaign_goal`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `update_campaign_goal` (
	IN v_campaign_id int(10),
	IN v_goal int(10)
)
BEGIN
	UPDATE `campaign` SET `campaign_goal` = v_goal WHERE `campaign_id` = v_campaign_id;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `update_campaign_title`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_title`(
	IN v_campaign_id int(10),
	IN v_title varchar(256)
)
BEGIN
	UPDATE `campaign` SET `campaign_title` = v_title WHERE `campaign_id` = v_campaign_id;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `update_campaign_story`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_story`(
	IN v_campaign_id int(10),
	IN v_story text
)
BEGIN
	UPDATE `campaign` SET `campaign_story` = v_story WHERE `campaign_id` = v_campaign_id;
END$$

DELIMITER ;



ALTER TABLE `my_respects_fund`.`funeral_home` 
ADD COLUMN `funeral_home_fax` VARCHAR(45) NULL AFTER `funeral_home_phone`;


ALTER TABLE `my_respects_fund`.`campaign` 
ADD COLUMN `funeral_date` DATE NULL AFTER `campaign_end`;




USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.funeral_date,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fhi.image_name as `funeral_home_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_fax,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_other_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_id = v_campaign_id;
END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `update_campaign_funeral_home`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_funeral_home`(
	IN v_campaign_id int(10),
	IN v_funeral_home_id int(10)
)
BEGIN
	UPDATE `campaign` SET `funeral_home_id` = v_funeral_home_id WHERE `campaign_id` = v_campaign_id;
END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `update_campaign_funeral_date`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_funeral_date`(
	IN v_campaign_id int(10),
	IN v_funeral_date DATE
)
BEGIN
	UPDATE `campaign` SET `funeral_date` = v_funeral_date WHERE `campaign_id` = v_campaign_id;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `retrieve_basic_donation_info`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `retrieve_basic_donation_info` (
	v_campaign_id int(10)
)
BEGIN

	SELECT first_name, last_name, amount, description, ts_created FROM donation WHERE campaign_id = v_campaign_id;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_gallery`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_campaign_gallery` (
	IN v_campaign_id INT(10)
)
BEGIN

	SELECT 
		campaign_image_id,
		image_name
	FROM
		campaign_image
	WHERE
		campaign_id = v_campaign_id
	AND campaign_image_id != (SELECT 
									campaign_image_id
								FROM
									campaign
								WHERE
									campaign_id = v_campaign_id);

END$$

DELIMITER ;

CREATE TABLE `my_respects_fund`.`messages` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `message` TEXT NULL,
  `to_id` INT NULL,
  `from_id` INT NULL,
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`));

ALTER TABLE `my_respects_fund`.`messages` 
ADD COLUMN `reply_to` INT NULL AFTER `from_id`;

ALTER TABLE `my_respects_fund`.`messages` 
ADD COLUMN `campaign_id` INT NULL AFTER `id`;

ALTER TABLE `my_respects_fund`.`messages` 
CHANGE COLUMN `to_id` `to_user` INT(11) NULL DEFAULT NULL ,
CHANGE COLUMN `from_id` `from_user` INT(11) NULL DEFAULT NULL ;

ALTER TABLE `my_respects_fund`.`messages` 
ADD COLUMN `active_flag` INT(1) NULL DEFAULT 1 AFTER `reply_to`;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_all_messages`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_all_messages` (
	IN v_campaign_id INT
)
BEGIN

	SELECT 
		m.id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.campaign_id = v_campaign_id
		AND m.active_flag = 1;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `delete_message_by_id`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `delete_message_by_id` (
	IN v_message_id INT
)
BEGIN

	UPDATE messages SET active_flag = 0 WHERE id = v_message_id;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_all_messages`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages`(
	IN v_campaign_id INT,
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.campaign_id = v_campaign_id
		AND m.to_user = v_user_id
		AND m.active_flag = 1;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_all_messages`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages`(
	IN v_campaign_id INT,
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.campaign_id = v_campaign_id
		AND m.to_user = v_user_id
		AND m.active_flag = 1;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `reply_to_message`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `reply_to_message` (
	IN v_from_user INT,
	IN v_to_user INT,
	IN v_campaign_id INT,
	IN v_reply_to INT,
	IN v_message TEXT
)
BEGIN

	INSERT INTO messages 
		(`campaign_id`, `message`, `to_user`, `from_user`, `reply_to` ) 
			VALUES 
		( v_campaign_id, v_message, v_to_user, v_from_user, v_reply_to );

END$$

DELIMITER ;


CREATE TABLE `my_respects_fund`.`campaign_updates` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `campaign_id` INT NULL,
  `message` TEXT NULL,
  `image_id` VARCHAR(45) NULL,
  `video` TEXT NULL,
  `ts_created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`));

  
  USE `my_respects_fund`;
DROP procedure IF EXISTS `create_campaign_update`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `create_campaign_update` (
	IN v_campaign_id INT,
	IN v_message TEXT,
	IN v_video TEXT
)
BEGIN

	INSERT INTO campaign_updates (`campaign_id`, `message`, `video` ) VALUES ( v_campaign_id, v_message, v_video);

END$$

DELIMITER ;

  CREATE TABLE `campaign_update_image` (
  `campaign_image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `image_name` varchar(260) NOT NULL,
  `container_name` varchar(45) NOT NULL,
  `image_size` int(10) unsigned DEFAULT '0',
  `image_type` varchar(16) NOT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaign_image_id`),
  UNIQUE KEY `campaign_image_id_UNIQUE` (`campaign_image_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;
  
  
 USE `my_respects_fund`;
DROP procedure IF EXISTS `campaign_update_image_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_update_image_insert`(
	IN v_campaign_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO campaign_image
		(campaign_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_campaign_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'campaign_update_image_id';
END$$

DELIMITER ;
 
 USE `my_respects_fund`;
DROP procedure IF EXISTS `ampaign_update_assign_image_id`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ampaign_update_assign_image_id`(
	IN v_update_id INT(10),
    IN v_image_id INT(10)
)
BEGIN

	UPDATE campaign_updates
		SET image_id = v_image_id
	WHERE id = v_update_id;

END$$

DELIMITER ;

ALTER TABLE `my_respects_fund`.`campaign_update_image` 
CHANGE COLUMN `campaign_image_id` `image_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ,
CHANGE COLUMN `campaign_id` `update_id` INT(10) UNSIGNED NULL DEFAULT NULL ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `create_campaign_update`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_campaign_update`(
	IN v_campaign_id INT,
	IN v_message TEXT,
	IN v_video TEXT
)
BEGIN

	INSERT INTO campaign_updates (`campaign_id`, `message`, `video` ) VALUES ( v_campaign_id, v_message, v_video);
	SELECT LAST_INSERT_ID() as 'update_id';

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.campaign_end,
		c.funeral_date,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fhi.image_name as `funeral_home_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_fax,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_other_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_id = v_campaign_id;
END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_updates`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_campaign_updates` (
	IN v_campaign_id INT
)
BEGIN

	SELECT 
		cu.message,
		cu.video,
		ci.image_name,
		cu.ts_created
	FROM
		campaign_updates cu
			LEFT OUTER JOIN
		campaign_update_image ci ON ci.image_id = cu.id
	WHERE
		campaign_id = v_campaign_id
	ORDER BY cu.ts_created DESC;

END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_user_funeral_home`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_funeral_home`(
	IN v_user_id INT(10)
)
BEGIN
	SELECT `funeral_home_id` FROM funeral_home WHERE `partner_id` = v_user_id LIMIT 1;
END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_funeral_home_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_data`(
	v_funeral_home_id INT
)
BEGIN

	SELECT 
		fhi.image_name as `funeral_home_image`,
		fh.*,
		u.first_name,
		u.last_name
	FROM 
		funeral_home fh
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		user u ON u.user_id = fh.partner_id
	WHERE 
		c.campaign_id = v_funeral_home_id;
END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_funeral_home_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_data`(
	v_funeral_home_id INT
)
BEGIN

	SELECT 
		fhi.image_name as `funeral_home_image`,
		fh.*,
		u.first_name,
		u.last_name
	FROM 
		funeral_home fh
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		user u ON u.user_id = fh.partner_id
	WHERE 
		fh.funeral_home_id = v_funeral_home_id;
END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_all_messages_to_partner`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages_to_partner`(
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.to_user = v_user_id
		AND m.active_flag = 1;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_all_messages_to_partner`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages_to_partner`(
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		m.campaign_id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.to_user = v_user_id
		AND m.active_flag = 1;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `update_partner_description`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_partner_description`(
	IN v_funeral_home_id int(10),
	IN v_description text
)
BEGIN
	UPDATE `funeral_home` SET `funeral_home_about` = v_description WHERE `funeral_home_id` = v_funeral_home_id;
END$$

DELIMITER ;



ALTER TABLE `my_respects_fund`.`funeral_home` 
ADD COLUMN `funeral_home_contact_name_last` VARCHAR(256) NULL AFTER `funeral_home_contact_name`;


USE `my_respects_fund`;
DROP procedure IF EXISTS `update_funeral_home_info`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `update_funeral_home_info` (
	IN v_funeral_home_id INT,
	IN v_funeral_home_name VARCHAR(255),
	IN funeral_home_other_link VARCHAR(255),
	IN funeral_home_contact_name VARCHAR(255),
	IN funeral_home_contact_name_last VARCHAR(255),
	IN funeral_home_address VARCHAR(255),
	IN funeral_home_city VARCHAR(128),
	IN funeral_home_state VARCHAR(255),
	IN funeral_home_zip INT,
	IN funeral_home_email VARCHAR(255),
	IN funeral_home_phone VARCHAR(16)
)
BEGIN

	UPDATE funeral_home SET 
		`funeral_home_name` = v_funeral_home_name, `funeral_home_other_link` = funeral_home_other_link,
		`funeral_home_contact_name` = funeral_home_contact_name,`funeral_home_contact_name_last` = funeral_home_contact_name_last,
		`funeral_home_address` = funeral_home_address,`funeral_home_city` = funeral_home_city,
		`funeral_home_state` = funeral_home_state,`funeral_home_zip` = funeral_home_zip,
		`funeral_home_email` = funeral_home_email,`funeral_home_phone` = funeral_home_phone
	WHERE
		funeral_home_id = v_funeral_home_id;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_funeral_home_linked_funds`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_funeral_home_linked_funds` (
	IN v_funeral_home_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		ci.image_name as `main_campaign_image`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
	WHERE 
		c.funeral_home_id = v_funeral_home_id;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_sent_messages_partner`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_sent_messages_partner`(
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		m.campaign_id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.from_user = v_user_id
		AND m.active_flag = 1;

END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.campaign_end,
		c.funeral_date,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fhi.image_name as `funeral_home_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_fax,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_other_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		u.user_id,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_id = v_campaign_id;
END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `send_message`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `send_message` (
	IN campaign_message TEXT,
	IN campaign_id INT,
	IN from_user INT,
	IN to_user INT
)
BEGIN

	INSERT INTO messages
		(`campaign_id`, `message`,`to_user`,`from_user`)
			VALUES
		(campaign_id,campaign_message,to_user,from_user);

END$$

DELIMITER ;

