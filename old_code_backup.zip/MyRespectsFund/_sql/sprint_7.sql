
/* this routine was being called with email but taking in id */
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_info`(
	v_email TEXT
)
BEGIN
	
	SELECT * FROM user WHERE email = v_email LIMIT 1;

END$$
DELIMITER ;



/* had to adjust limit to fit for how many across they have in the html/css now */
USE `my_respects_fund`;
DROP procedure IF EXISTS `get_search_results`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_results`(
	v_search_value TEXT,
	v_start_index INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' )
	ORDER BY
		c.ts_created DESC
	LIMIT v_start_index, 20;

END$$

DELIMITER ;


USE `my_respects_fund`;
DROP procedure IF EXISTS `get_campaign_data`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.wepay_account_id,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		u.wepay_access_token
		
		-- @todo Still need to link in a donation table to get who donated/how much --> should this be a separate query? we may have a lot of donations
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
	WHERE 
		c.campaign_id = v_campaign_id;
END$$

DELIMITER ;

CREATE TABLE `my_respects_fund`.`donation` (
  `donation_id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '',
  `wepay_preapproval_id` BIGINT NULL COMMENT '',
  `first_name` VARCHAR(128) NULL COMMENT '',
  `last_name` VARCHAR(128) NULL COMMENT '',
  `address` VARCHAR(128) NULL COMMENT '',
  `city` VARCHAR(128) NULL COMMENT '',
  `state` VARCHAR(2) NULL COMMENT '',
  `zip` INT(5) ZEROFILL NULL COMMENT '',
  `email` VARCHAR(256) NULL COMMENT '',
  `amount` FLOAT NULL COMMENT '',
  `description` VARCHAR(256) NULL COMMENT '',
  `anonymous_flag` TINYINT NULL DEFAULT 0 COMMENT '',
  `complete_flag` TINYINT NULL DEFAULT 0 COMMENT '',
  `charged_flag` TINYINT NULL DEFAULT 0 COMMENT '',
  `wepay_url` VARCHAR(512) NULL COMMENT '',
  `ts_modified` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '',
  `ts_created` TIMESTAMP NULL DEFAULT '0000-00-00 00:00:00' COMMENT '',
  PRIMARY KEY (`donation_id`)  COMMENT '',
  UNIQUE INDEX `donation_id_UNIQUE` (`donation_id` ASC)  COMMENT '');

ALTER TABLE `my_respects_fund`.`donation` 
ADD COLUMN `donation_hash` VARCHAR(256) NULL COMMENT '' AFTER `wepay_url`;

ALTER TABLE `my_respects_fund`.`donation` 
ADD COLUMN `campaign_id` INT(10) NULL COMMENT '' AFTER `donation_id`;


USE `my_respects_fund`;
DROP procedure IF EXISTS `donation_insert`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `donation_insert`(
	IN v_wepay_preapproval_id BIGINT,
    IN v_campaign_id INT(10),
	IN v_first_name VARCHAR(128),
	IN v_last_name VARCHAR(128),
	IN v_address VARCHAR(128),
	IN v_city VARCHAR(128),
	IN v_state VARCHAR(2),
	IN v_zip INT(5) ZEROFILL,
	IN v_email VARCHAR(256),
	IN v_amount FLOAT,
	IN v_description VARCHAR(256),
	IN v_wepay_url VARCHAR(512),
    IN v_anonymous_flag TINYINT,
    IN v_donation_hash VARCHAR(256)
)
BEGIN

	INSERT INTO donation
		(wepay_preapproval_id,campaign_id,first_name,last_name,address,city,state,zip,email,amount,description,wepay_url,anonymous_flag,donation_hash,ts_created)
	VALUES
		(v_wepay_preapproval_id,v_campaign_id,v_first_name,v_last_name,v_address,v_city,v_state,v_zip,v_email,v_amount,v_description,v_wepay_url,v_anonymous_flag,v_donation_hash, NOW());

END$$

DELIMITER ;



USE `my_respects_fund`;
DROP procedure IF EXISTS `update_donation_as_complete`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_donation_as_complete`(
	IN v_preapproval_id BIGINT
)
BEGIN

	UPDATE donation
		SET complete_flag = 1
	WHERE wepay_preapproval_id = v_preapproval_id;
    
    SELECT * FROM donation where wepay_preapproval_id = v_preapproval_id AND complete_flag = 1;

END$$

DELIMITER ;

