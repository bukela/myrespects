USE `my_respects_fund`;
DROP procedure IF EXISTS `check_funeral_home_by_name`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `check_funeral_home_by_name` (
	v_funeral_home_name TEXT
)
BEGIN

	SELECT funeral_home_id, funeral_home_name, funeral_home_address, funeral_home_state, funeral_home_city, funeral_home_zip, funeral_home_email, funeral_home_phone From funeral_home WHERE funeral_home_name LIKE CONCAT('%', v_funeral_home_name, '%');
	
END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `funeral_home_update`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_update`(
	IN v_funeral_home_id INT(10),
	IN v_partner_id INT(10),
	IN v_funeral_home_name VARCHAR(256),
	IN v_funeral_home_contact_name VARCHAR(256),
	IN v_funeral_home_phone VARCHAR(16),
	IN v_funeral_home_email VARCHAR(256),
	IN v_funeral_home_address VARCHAR(256),
	IN v_funeral_home_city VARCHAR(128),
	IN v_funeral_home_state VARCHAR(2),
	IN v_funeral_home_zip INT(5) ZEROFILL,
	IN v_funeral_home_lat VARCHAR(256),
	IN v_funeral_home_lng VARCHAR(256),
	IN v_funeral_home_facebook_link VARCHAR(256),
	IN v_funeral_home_twitter_link VARCHAR(256),
	IN v_funeral_home_google_link VARCHAR(256),
	IN v_funeral_home_other_link VARCHAR(256),
	IN v_funeral_home_about TEXT,
	IN v_funeral_home_place_id TEXT
)
BEGIN

	UPDATE funeral_home SET
		partner_id = v_partner_id, 
		funeral_home_name = v_funeral_home_name, 
		funeral_home_contact_name = v_funeral_home_contact_name, 
		funeral_home_phone = v_funeral_home_phone, 
		funeral_home_email = v_funeral_home_email, 
		funeral_home_address = v_funeral_home_address, 
		funeral_home_city = v_funeral_home_city, 
		funeral_home_state = v_funeral_home_state, 
		funeral_home_zip = v_funeral_home_zip, 
		funeral_home_lat = v_funeral_home_lat, 
		funeral_home_lng = v_funeral_home_lng, 
		funeral_home_facebook_link = v_funeral_home_facebook_link, 
		funeral_home_twitter_link = v_funeral_home_twitter_link, 
		funeral_home_google_link = v_funeral_home_google_link, 
		funeral_home_other_link = v_funeral_home_other_link, 
		funeral_home_about = v_funeral_home_about, 
		funeral_home_place_id = v_partner_id
	WHERE funeral_home_id = v_funeral_home_place_id;

	SELECT v_funeral_home_id as `funeral_home_id`;

END$$

DELIMITER ;

USE `my_respects_fund`;
DROP procedure IF EXISTS `get_funeral_home_details`;

DELIMITER $$
USE `my_respects_fund`$$
CREATE PROCEDURE `get_funeral_home_details` (
	v_funeral_home_id INT
)
BEGIN
	
	SELECT 
		`funeral_home`.`funeral_home_id`,
		`funeral_home`.`partner_id`,
		`funeral_home`.`funeral_home_name`,
		`funeral_home`.`funeral_home_contact_name`,
		`funeral_home`.`funeral_home_phone`,
		`funeral_home`.`funeral_home_email`,
		`funeral_home`.`funeral_home_address`,
		`funeral_home`.`funeral_home_city`,
		`funeral_home`.`funeral_home_state`,
		`funeral_home`.`funeral_home_zip`,
		`funeral_home`.`funeral_home_lat`,
		`funeral_home`.`funeral_home_lng`,
		`funeral_home`.`funeral_home_facebook_link`,
		`funeral_home`.`funeral_home_twitter_link`,
		`funeral_home`.`funeral_home_google_link`,
		`funeral_home`.`funeral_home_other_link`,
		`funeral_home`.`funeral_home_about`,
		`funeral_home`.`funeral_home_place_id`
	FROM `my_respects_fund`.`funeral_home`
	WHERE `funeral_home_id` = v_funeral_home_id;

END$$

DELIMITER ;

/* above was run on prod */