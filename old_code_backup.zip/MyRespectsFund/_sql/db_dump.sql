CREATE DATABASE  IF NOT EXISTS `my_respects_fund` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `my_respects_fund`;
-- MySQL dump 10.13  Distrib 5.6.17, for osx10.6 (i386)
--
-- Host: localhost    Database: my_respects_fund
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign` (
  `campaign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `wepay_account_id` int(10) unsigned DEFAULT NULL,
  `funeral_home_id` int(10) DEFAULT NULL,
  `campaign_image_id` int(10) DEFAULT NULL,
  `campaign_title` varchar(256) NOT NULL,
  `campaign_goal` int(10) DEFAULT NULL,
  `campaign_zip` int(5) unsigned zerofill DEFAULT NULL,
  `campaign_story` text,
  `campaign_end` date DEFAULT NULL,
  `funeral_date` date DEFAULT NULL,
  `wepay_account_state` varchar(64) DEFAULT NULL,
  `ts_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`campaign_id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaign_image`
--

DROP TABLE IF EXISTS `campaign_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_image` (
  `campaign_image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `image_name` varchar(260) NOT NULL,
  `container_name` varchar(45) NOT NULL,
  `image_size` int(10) unsigned DEFAULT '0',
  `image_type` varchar(16) NOT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`campaign_image_id`),
  UNIQUE KEY `campaign_image_id_UNIQUE` (`campaign_image_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `campaign_update_image`
--

DROP TABLE IF EXISTS `campaign_update_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_update_image` (
  `image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `update_id` int(10) unsigned DEFAULT NULL,
  `image_name` varchar(260) NOT NULL,
  `container_name` varchar(45) NOT NULL,
  `image_size` int(10) unsigned DEFAULT '0',
  `image_type` varchar(16) NOT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `campaign_image_id_UNIQUE` (`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `campaign_updates`
--

DROP TABLE IF EXISTS `campaign_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) DEFAULT NULL,
  `message` text,
  `image_id` varchar(45) DEFAULT NULL,
  `video` text,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `donation`
--

DROP TABLE IF EXISTS `donation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donation` (
  `donation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) DEFAULT NULL,
  `wepay_preapproval_id` bigint(20) DEFAULT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip` int(5) unsigned zerofill DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `anonymous_flag` tinyint(4) DEFAULT '0',
  `complete_flag` tinyint(4) DEFAULT '0',
  `charged_flag` tinyint(4) DEFAULT '0',
  `wepay_url` varchar(512) DEFAULT NULL,
  `donation_hash` varchar(256) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`donation_id`),
  UNIQUE KEY `donation_id_UNIQUE` (`donation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `funeral_home`
--

DROP TABLE IF EXISTS `funeral_home`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funeral_home` (
  `funeral_home_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) DEFAULT NULL,
  `funeral_home_name` varchar(256) DEFAULT NULL,
  `funeral_home_contact_name` varchar(256) DEFAULT NULL,
  `funeral_home_contact_name_last` varchar(256) DEFAULT NULL,
  `funeral_home_phone` varchar(16) DEFAULT NULL,
  `funeral_home_fax` varchar(45) DEFAULT NULL,
  `funeral_home_email` varchar(256) DEFAULT NULL,
  `funeral_home_address` varchar(256) DEFAULT NULL,
  `funeral_home_city` varchar(128) DEFAULT NULL,
  `funeral_home_state` varchar(2) DEFAULT NULL,
  `funeral_home_zip` int(5) unsigned zerofill DEFAULT NULL,
  `funeral_home_lat` varchar(256) DEFAULT NULL,
  `funeral_home_lng` varchar(256) DEFAULT NULL,
  `funeral_home_facebook_link` varchar(256) DEFAULT NULL,
  `funeral_home_twitter_link` varchar(256) DEFAULT NULL,
  `funeral_home_google_link` varchar(256) DEFAULT NULL,
  `funeral_home_other_link` varchar(256) DEFAULT NULL,
  `funeral_home_about` text,
  `funeral_home_place_id` varchar(45) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`funeral_home_id`),
  UNIQUE KEY `funeral_home_id_UNIQUE` (`funeral_home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `funeral_home_image`
--

DROP TABLE IF EXISTS `funeral_home_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funeral_home_image` (
  `funeral_home_image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `funeral_home_id` int(10) unsigned DEFAULT NULL,
  `image_name` varchar(260) NOT NULL,
  `container_name` varchar(45) NOT NULL,
  `image_size` int(10) unsigned DEFAULT '0',
  `image_type` varchar(16) NOT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`funeral_home_image_id`),
  UNIQUE KEY `funeral_home_image_id_UNIQUE` (`funeral_home_image_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `general_log`
--

DROP TABLE IF EXISTS `general_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_log` (
  `general_log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `campaign_id` int(10) DEFAULT NULL,
  `funeral_home_id` int(10) DEFAULT NULL,
  `log_type` varchar(64) DEFAULT NULL,
  `log_event` varchar(512) DEFAULT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`general_log_id`),
  UNIQUE KEY `general_log_id_UNIQUE` (`general_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) DEFAULT NULL,
  `message` text,
  `to_user` int(11) DEFAULT NULL,
  `from_user` int(11) DEFAULT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `active_flag` int(1) DEFAULT '1',
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `preapproval`
--

DROP TABLE IF EXISTS `preapproval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preapproval` (
  `preapproval_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` float DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `wepay_preapproval_id` int(10) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`preapproval_id`),
  UNIQUE KEY `preapproval_id_UNIQUE` (`preapproval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `test_table`
--

DROP TABLE IF EXISTS `test_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table` (
  `test_table_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_value` varchar(45) NOT NULL,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`test_table_id`),
  UNIQUE KEY `test_table_id_UNIQUE` (`test_table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `wepay_user_id` int(10) DEFAULT NULL,
  `first_name` varchar(256) DEFAULT NULL,
  `last_name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `user_level` varchar(45) NOT NULL DEFAULT 'basic',
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(256) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip` varchar(5) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `picture` text,
  `picture_from` varchar(32) DEFAULT NULL,
  `wepay_access_token` varchar(256) DEFAULT NULL,
  `wepay_token_type` varchar(64) DEFAULT NULL,
  `wepay_token_expires` int(10) DEFAULT NULL,
  `is_admin` int(1) unsigned DEFAULT '0',
  `created_by` enum('google','facebook','normal') DEFAULT NULL,
  `ts_last_login` timestamp NULL DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `user_image`
--

DROP TABLE IF EXISTS `user_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_image` (
  `user_image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `image_name` varchar(260) NOT NULL,
  `container_name` varchar(45) NOT NULL,
  `image_size` int(10) unsigned DEFAULT '0',
  `image_type` varchar(16) NOT NULL,
  `ts_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_image_id`),
  UNIQUE KEY `user_image_id_UNIQUE` (`user_image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `zip_code_info`
--

DROP TABLE IF EXISTS `zip_code_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zip_code_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zip_code` varchar(16) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `lng` varchar(45) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `country` varchar(2) DEFAULT NULL,
  `place_id` varchar(256) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8301 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Dumping routines for database 'my_respects_fund'
--
/*!50003 DROP PROCEDURE IF EXISTS `campaign_assign_main_image` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_assign_main_image`(
	IN v_campaign_id INT(10),
    IN v_campaign_image_id INT(10)
)
BEGIN

	UPDATE campaign
		SET campaign_image_id = v_campaign_image_id
	WHERE campaign_id = v_campaign_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_image_delete`(
	IN v_campaign_image_id INT(10)
)
BEGIN
	DELETE FROM campaign_image WHERE campaign_image_id = v_campaign_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_image_insert`(
	IN v_campaign_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO campaign_image
		(campaign_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_campaign_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'campaign_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_insert`(
	IN v_user_id INT(10),
	IN v_funeral_home_id INT(10),
	IN v_campaign_image_id INT(10),
	IN v_campaign_title VARCHAR(256),
	IN v_campaign_goal INT(10), 
	IN v_campaign_zip INT(5),
	IN v_campaign_story TEXT,
	IN v_campaign_end DATE
)
BEGIN

	INSERT INTO campaign
		(user_id, funeral_home_id, campaign_image_id, campaign_title, campaign_goal, campaign_zip, campaign_story, campaign_end, ts_created)
	VALUES
		(v_user_id, v_funeral_home_id, v_campaign_image_id, v_campaign_title, v_campaign_goal, v_campaign_zip, v_campaign_story, v_campaign_end, NOW());
	
    SELECT LAST_INSERT_ID() as `campaign_id`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_update_assign_image_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_update_assign_image_id`(
	IN v_update_id INT(10),
    IN v_image_id INT(10)
)
BEGIN

	UPDATE campaign_updates
		SET image_id = v_image_id
	WHERE id = v_update_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_update_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_update_image_insert`(
	IN v_update_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO campaign_image
		(update_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_update_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'campaign_update_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_update_wepay_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_update_wepay_by_id`(
	IN v_campaign_id INT(10),
    IN v_wepay_account_id INT(10),
    IN v_wepay_account_state VARCHAR(64)
)
BEGIN

	UPDATE campaign SET
		wepay_account_id = v_wepay_account_id,
        wepay_account_state = v_wepay_account_state
	WHERE campaign_id = v_campaign_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_funeral_home_by_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_funeral_home_by_name`(
	v_funeral_home_name TEXT
)
BEGIN

		SELECT funeral_home_id, funeral_home_name, funeral_home_address, funeral_home_state, funeral_home_city, funeral_home_zip, funeral_home_email, funeral_home_phone From funeral_home WHERE funeral_home_name LIKE CONCAT('%', v_funeral_home_name, '%');
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_exists`(
	IN v_email_address VARCHAR(256)
)
BEGIN
	SELECT EXISTS( SELECT 1 FROM user WHERE email = v_email_address );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_is_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_is_admin`(
	IN v_user_id INT(10)
)
BEGIN

	SELECT EXISTS( SELECT 1 FROM user WHERE user_id = v_user_id AND is_admin = 1 );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_password`(
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256)
)
BEGIN
	IF EXISTS( SELECT 1 FROM user WHERE `email` = v_email AND `password` = v_password ) THEN
		BEGIN
			SELECT `email`, `first_name`, `last_name`, `picture` FROM user WHERE `email` = v_email;
		END;
	ELSE
		BEGIN
			SELECT 0;
		END;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_campaign_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_campaign_update`(
	IN v_campaign_id INT,
	IN v_message TEXT,
	IN v_video TEXT
)
BEGIN

	INSERT INTO campaign_updates (`campaign_id`, `message`, `video` ) VALUES ( v_campaign_id, v_message, v_video);
	SELECT LAST_INSERT_ID() as 'update_id';

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_user`(
	IN v_first_name VARCHAR(256),
	IN v_last_name VARCHAR(256),
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256),
	IN v_picture TEXT,
	IN v_picture_from VARCHAR(32),
	IN v_created_by ENUM('google','facebook','normal')
)
BEGIN

	INSERT INTO user (`first_name`,`last_name`,`email`,`password`,`picture`,`picture_from`,`created_by`,`ts_created`)
						VALUES
					 (v_first_name,v_last_name,v_email,v_password,v_picture,v_picture_from,v_created_by,NOW());
	
	SELECT last_insert_id();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_message_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_message_by_id`(
	IN v_message_id INT
)
BEGIN

	UPDATE messages SET active_flag = 0 WHERE id = v_message_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_image_delete`(
	IN v_funeral_home_image_id INT(10)
)
BEGIN
	DELETE FROM funeral_home_image WHERE funeral_home_image_id = v_funeral_home_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_image_insert`(
	IN v_funeral_home_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO funeral_home_image
		(funeral_home_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_funeral_home_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'funeral_home_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_insert`(
	IN v_partner_id INT(10),
	IN v_funeral_home_name VARCHAR(256),
	IN v_funeral_home_contact_name VARCHAR(256),
	IN v_funeral_home_phone VARCHAR(16),
	IN v_funeral_home_email VARCHAR(256),
	IN v_funeral_home_address VARCHAR(256),
	IN v_funeral_home_city VARCHAR(128),
	IN v_funeral_home_state VARCHAR(2),
	IN v_funeral_home_zip INT(5) ZEROFILL,
	IN v_funeral_home_lat VARCHAR(256),
	IN v_funeral_home_lng VARCHAR(256),
	IN v_funeral_home_facebook_link VARCHAR(256),
	IN v_funeral_home_twitter_link VARCHAR(256),
	IN v_funeral_home_google_link VARCHAR(256),
	IN v_funeral_home_other_link VARCHAR(256),
	IN v_funeral_home_about TEXT,
	IN v_funeral_home_place_id TEXT
)
BEGIN

	INSERT INTO funeral_home
		(partner_id, funeral_home_name, funeral_home_contact_name, funeral_home_phone, funeral_home_email, funeral_home_address, funeral_home_city, funeral_home_state, funeral_home_zip, funeral_home_lat, funeral_home_lng, funeral_home_facebook_link, funeral_home_twitter_link, funeral_home_google_link, funeral_home_other_link, funeral_home_about, funeral_home_place_id, ts_created)
	VALUES 
		(v_partner_id, v_funeral_home_name, v_funeral_home_contact_name, v_funeral_home_phone, v_funeral_home_email, v_funeral_home_address, v_funeral_home_city, v_funeral_home_state, v_funeral_home_zip, v_funeral_home_lat, v_funeral_home_lng, v_funeral_home_facebook_link, v_funeral_home_twitter_link, v_funeral_home_google_link, v_funeral_home_other_link, v_funeral_home_about, v_funeral_home_place_id, NOW());
        
	SELECT LAST_INSERT_ID() as `funeral_home_id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_search`(
	v_lat VARCHAR(256),
	v_lng VARCHAR(256)
)
BEGIN

	SELECT funeral_home_id, funeral_home_name, funeral_home_address, funeral_home_city, funeral_home_state, funeral_home_zip, funeral_home_lat, funeral_home_lng, funeral_home_place_id
	FROM funeral_home 
	WHERE 
		(3959 
			* ACOS( 
				COS( RADIANS( v_lat ) )
				* COS( RADIANS( funeral_home_lat ) )
				* COS( RADIANS( funeral_home_lng ) - RADIANS( v_lng ) )
				+ SIN( RADIANS( v_lat ) )
				* SIN( RADIANS( funeral_home_lat ) )
			)
		) < 30;
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_update`(
	IN v_funeral_home_id INT(10),
	IN v_partner_id INT(10),
	IN v_funeral_home_name VARCHAR(256),
	IN v_funeral_home_contact_name VARCHAR(256),
	IN v_funeral_home_phone VARCHAR(16),
	IN v_funeral_home_email VARCHAR(256),
	IN v_funeral_home_address VARCHAR(256),
	IN v_funeral_home_city VARCHAR(128),
	IN v_funeral_home_state VARCHAR(2),
	IN v_funeral_home_zip INT(5) ZEROFILL,
	IN v_funeral_home_lat VARCHAR(256),
	IN v_funeral_home_lng VARCHAR(256),
	IN v_funeral_home_facebook_link VARCHAR(256),
	IN v_funeral_home_twitter_link VARCHAR(256),
	IN v_funeral_home_google_link VARCHAR(256),
	IN v_funeral_home_other_link VARCHAR(256),
	IN v_funeral_home_about TEXT,
	IN v_funeral_home_place_id TEXT
)
BEGIN

	UPDATE funeral_home SET
		partner_id = v_partner_id, 
		funeral_home_name = v_funeral_home_name, 
		funeral_home_contact_name = v_funeral_home_contact_name, 
		funeral_home_phone = v_funeral_home_phone, 
		funeral_home_email = v_funeral_home_email, 
		funeral_home_address = v_funeral_home_address, 
		funeral_home_city = v_funeral_home_city, 
		funeral_home_state = v_funeral_home_state, 
		funeral_home_zip = v_funeral_home_zip, 
		funeral_home_lat = v_funeral_home_lat, 
		funeral_home_lng = v_funeral_home_lng, 
		funeral_home_facebook_link = v_funeral_home_facebook_link, 
		funeral_home_twitter_link = v_funeral_home_twitter_link, 
		funeral_home_google_link = v_funeral_home_google_link, 
		funeral_home_other_link = v_funeral_home_other_link, 
		funeral_home_about = v_funeral_home_about, 
		funeral_home_place_id = v_partner_id
	WHERE funeral_home_id = v_funeral_home_place_id;

	SELECT v_funeral_home_id as `funeral_home_id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `general_log_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `general_log_insert`(
	IN v_user_id int(10),
	IN v_campaign_id int(10),
	IN v_funeral_home_id int(10),
	IN v_log_type varchar(64),
	IN v_log_event varchar(512)
)
BEGIN

	INSERT INTO general_log
		(user_id, campaign_id, funeral_home_id, log_type, log_event)
	VALUES
		(v_user_id, v_campaign_id, v_funeral_home_id, v_log_type, v_log_event);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_messages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages`(
	IN v_campaign_id INT,
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.campaign_id = v_campaign_id
		AND m.to_user = v_user_id
		AND m.active_flag = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_messages_to_partner` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_messages_to_partner`(
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		m.campaign_id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.to_user = v_user_id
		AND m.active_flag = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_campaign_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.campaign_end,
		c.funeral_date,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fhi.image_name as `funeral_home_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_fax,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_other_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		u.user_id,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_id = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_campaign_gallery` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_gallery`(
	IN v_campaign_id INT(10)
)
BEGIN

	SELECT 
		campaign_image_id,
		image_name
	FROM
		campaign_image
	WHERE
		campaign_id = v_campaign_id
	AND campaign_image_id != (SELECT 
									campaign_image_id
								FROM
									campaign
								WHERE
									campaign_id = v_campaign_id);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_campaign_updates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_updates`(
	IN v_campaign_id INT
)
BEGIN

	SELECT 
		cu.message,
		cu.video,
		ci.image_name,
		cu.ts_created
	FROM
		campaign_updates cu
			LEFT OUTER JOIN
		campaign_update_image ci ON ci.image_id = cu.id
	WHERE
		campaign_id = v_campaign_id
	ORDER BY cu.ts_created DESC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_funeral_home_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_data`(
	v_funeral_home_id INT
)
BEGIN

	SELECT 
		fhi.image_name as `funeral_home_image`,
		fh.*,
		u.first_name,
		u.last_name
	FROM 
		funeral_home fh
			LEFT JOIN
		funeral_home_image fhi ON fhi.funeral_home_id = fh.funeral_home_id
			LEFT JOIN
		user u ON u.user_id = fh.partner_id
	WHERE 
		fh.funeral_home_id = v_funeral_home_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_funeral_home_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_details`(
	v_funeral_home_id INT
)
BEGIN
	
	SELECT 
		`funeral_home`.`funeral_home_id`,
		`funeral_home`.`partner_id`,
		`funeral_home`.`funeral_home_name`,
		`funeral_home`.`funeral_home_contact_name`,
		`funeral_home`.`funeral_home_phone`,
		`funeral_home`.`funeral_home_email`,
		`funeral_home`.`funeral_home_address`,
		`funeral_home`.`funeral_home_city`,
		`funeral_home`.`funeral_home_state`,
		`funeral_home`.`funeral_home_zip`,
		`funeral_home`.`funeral_home_lat`,
		`funeral_home`.`funeral_home_lng`,
		`funeral_home`.`funeral_home_facebook_link`,
		`funeral_home`.`funeral_home_twitter_link`,
		`funeral_home`.`funeral_home_google_link`,
		`funeral_home`.`funeral_home_other_link`,
		`funeral_home`.`funeral_home_about`,
		`funeral_home`.`funeral_home_place_id`
	FROM `my_respects_fund`.`funeral_home`
	WHERE `funeral_home_id` = v_funeral_home_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_funeral_home_linked_funds` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_linked_funds`(
	IN v_funeral_home_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		ci.image_name as `main_campaign_image`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
	WHERE 
		c.funeral_home_id = v_funeral_home_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_highest_funded` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_highest_funded`()
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	GROUP BY
		c.campaign_id	
	ORDER BY
		raised DESC
	LIMIT 8;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_local_campaigns` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_local_campaigns`(
	IN v_lat float,
	IN v_lng float
)
BEGIN


	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_zip IN 
			( SELECT 
				`zip_code`
				FROM 
					(	
						SELECT
							`zip_code`,
							(
								6371 *
								acos(
									cos( radians( v_lat ) ) *
									cos( radians( `lat` ) ) *
									cos(
										radians( `lng` ) - radians( v_lng )
									) +
									sin(radians( v_lat )) *
									sin(radians( `lat` ))
								)
							) as `distance`
						FROM
							`zip_code_info`
						HAVING
							`distance` < 10
						ORDER BY
							`distance`
					) zip 
				)
	GROUP BY
		c.campaign_id	
	ORDER BY
		c.ts_created DESC
	LIMIT 8;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_location_info_by_zip` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_location_info_by_zip`(
	IN v_zip VARCHAR(16)
)
BEGIN
	SELECT lat, lng, city, country, state, zip_code FROM zip_code_info WHERE zip_code = v_zip;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_search_results` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_results`(
	v_search_value TEXT,
	v_start_index INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`,
		SUM( d.amount ) as `raised`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		donation d ON d.campaign_id = c.campaign_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' )
	GROUP BY
		c.campaign_id	
	ORDER BY
		c.ts_created DESC
	LIMIT v_start_index, 20;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_search_result_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_result_count`(
	v_search_value TEXT
)
BEGIN
	
	SELECT 
		COUNT(*)
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_sent_messages_partner` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_sent_messages_partner`(
	IN v_user_id INT
)
BEGIN

	SELECT 
		m.id,
		m.campaign_id,
		CONCAT( u.first_name, " ", u.last_name ) AS name,
		m.message,
		m.from_user,
		m.ts_created as `date`
	FROM
		messages m
		JOIN user u ON u.user_id = from_user
	WHERE
		m.from_user = v_user_id
		AND m.active_flag = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_user_campaign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_campaign`(
	IN v_user_id INT(10)
)
BEGIN
	SELECT `campaign_id` FROM campaign WHERE `user_id` = v_user_id LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_user_funeral_home` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_funeral_home`(
	IN v_user_id INT(10)
)
BEGIN
	SELECT `funeral_home_id` FROM funeral_home WHERE `partner_id` = v_user_id LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_user_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_info`(
	v_user_email TEXT
)
BEGIN
	
	SELECT * FROM user WHERE email = v_user_email LIMIT 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_wepay_token_by_user_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_wepay_token_by_user_id`(
	IN v_user_id INT(10)
)
BEGIN

	SELECT wepay_access_token FROM user WHERE user_id = v_user_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reply_to_message` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reply_to_message`(
	IN v_from_user INT,
	IN v_to_user INT,
	IN v_campaign_id INT,
	IN v_reply_to INT,
	IN v_message TEXT
)
BEGIN

	INSERT INTO messages 
		(`campaign_id`, `message`, `to_user`, `from_user`, `reply_to` ) 
			VALUES 
		( v_campaign_id, v_message, v_to_user, v_from_user, v_reply_to );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `reset_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `reset_password`( 
	IN v_email_address VARCHAR(256),
	IN v_new_password VARCHAR(256)
)
BEGIN

	UPDATE `user` SET `password` = MD5( v_new_password ) WHERE `email` = v_email_address;

	SELECT ROW_COUNT();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `retrieve_basic_donation_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `retrieve_basic_donation_info`(
	v_campaign_id int(10)
)
BEGIN

	SELECT first_name, last_name, amount, description, ts_created FROM donation WHERE campaign_id = v_campaign_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `send_message` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `send_message`(
	IN campaign_message TEXT,
	IN campaign_id INT,
	IN from_user INT,
	IN to_user INT
)
BEGIN

	INSERT INTO messages
		(`campaign_id`, `message`,`to_user`,`from_user`)
			VALUES
		(campaign_id,campaign_message,to_user,from_user);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_campaign_funeral_date` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_funeral_date`(
	IN v_campaign_id int(10),
	IN v_funeral_date DATE
)
BEGIN
	UPDATE `campaign` SET `funeral_date` = v_funeral_date WHERE `campaign_id` = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_campaign_funeral_home` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_funeral_home`(
	IN v_campaign_id int(10),
	IN v_funeral_home_id int(10)
)
BEGIN
	UPDATE `campaign` SET `funeral_home_id` = v_funeral_home_id WHERE `campaign_id` = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_campaign_goal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_goal`(
	IN v_campaign_id int(10),
	IN v_goal int(10)
)
BEGIN
	UPDATE `campaign` SET `campaign_goal` = v_goal WHERE `campaign_id` = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_campaign_story` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_story`(
	IN v_campaign_id int(10),
	IN v_story text
)
BEGIN
	UPDATE `campaign` SET `campaign_story` = v_story WHERE `campaign_id` = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_campaign_title` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_campaign_title`(
	IN v_campaign_id int(10),
	IN v_title varchar(256)
)
BEGIN
	UPDATE `campaign` SET `campaign_title` = v_title WHERE `campaign_id` = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_funeral_home_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_funeral_home_info`(
	IN v_funeral_home_id INT,
	IN v_funeral_home_name VARCHAR(255),
	IN funeral_home_other_link VARCHAR(255),
	IN funeral_home_contact_name VARCHAR(255),
	IN funeral_home_contact_name_last VARCHAR(255),
	IN funeral_home_address VARCHAR(255),
	IN funeral_home_city VARCHAR(128),
	IN funeral_home_state VARCHAR(255),
	IN funeral_home_zip INT,
	IN funeral_home_email VARCHAR(255),
	IN funeral_home_phone VARCHAR(16)
)
BEGIN

	UPDATE funeral_home SET 
		`funeral_home_name` = v_funeral_home_name, `funeral_home_other_link` = funeral_home_other_link,
		`funeral_home_contact_name` = funeral_home_contact_name,`funeral_home_contact_name_last` = funeral_home_contact_name_last,
		`funeral_home_address` = funeral_home_address,`funeral_home_city` = funeral_home_city,
		`funeral_home_state` = funeral_home_state,`funeral_home_zip` = funeral_home_zip,
		`funeral_home_email` = funeral_home_email,`funeral_home_phone` = funeral_home_phone
	WHERE
		funeral_home_id = v_funeral_home_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_last_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_last_login`(
	IN v_email VARCHAR(256)
)
BEGIN
	UPDATE user SET `ts_last_login` = NOW() WHERE `email` = v_email;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_partner_description` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_partner_description`(
	IN v_funeral_home_id int(10),
	IN v_description text
)
BEGIN
	UPDATE `funeral_home` SET `funeral_home_about` = v_description WHERE `funeral_home_id` = v_funeral_home_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_user_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_info`(
	IN v_user_id INT(10),
	IN v_first_name VARCHAR(256),
	IN v_last_name VARCHAR(256),
	IN v_email VARCHAR(250),
	IN v_address VARCHAR(256),
	IN v_city VARCHAR(256),
	IN v_state VARCHAR(2),
	IN v_zip INT(5),
	IN v_phone_number VARCHAR(10),
	IN v_dob DATE
)
BEGIN

	UPDATE 
		`user` 
	SET 
		`first_name` = v_first_name, `last_name` = v_last_name, `email` = v_email,
		`address` = v_address, `city` = v_city, `state` = v_state, `zip` = v_zip,
		`phone_number` = v_phone_number, `dob` = v_dob
	WHERE user_id = v_user_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_image_delete`(
	IN v_user_image_id INT(10)
)
BEGIN
	DELETE FROM user_image WHERE user_image_id = v_user_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_image_insert`(
	IN v_user_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO user_image
		(user_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_user_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'user_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_update_wepay_by_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_update_wepay_by_email`(
	IN v_email VARCHAR(256),
    IN v_wepay_user_id INT(10),
    IN v_wepay_access_token VARCHAR(256),
    IN v_wepay_token_type VARCHAR(64),
    IN v_wepay_token_expires INT(10)
)
BEGIN

	UPDATE user SET
		wepay_user_id = v_wepay_user_id,
		wepay_access_token = v_wepay_access_token, 
        wepay_token_type = v_wepay_token_type,
        wepay_token_expires = v_wepay_token_expires
	WHERE 
		email = v_email;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-02  3:34:01
