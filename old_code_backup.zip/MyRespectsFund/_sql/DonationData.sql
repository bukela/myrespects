-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: my_respects_fund
-- ------------------------------------------------------
-- Server version	5.6.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign` (
  `campaign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `wepay_account_id` int(10) unsigned DEFAULT NULL,
  `funeral_home_id` int(10) DEFAULT NULL,
  `campaign_image_id` int(10) DEFAULT NULL,
  `campaign_title` varchar(256) NOT NULL,
  `campaign_goal` int(10) DEFAULT NULL,
  `campaign_zip` int(5) unsigned zerofill DEFAULT NULL,
  `campaign_story` text,
  `wepay_account_state` varchar(64) DEFAULT NULL,
  `ts_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`campaign_id`),
  UNIQUE KEY `campaign_id_UNIQUE` (`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` VALUES (1,1,2041580157,38,0,'This is my campaign title for my funeral',5000,00000,'this is my story','pending','2017-05-17 21:00:51','0000-00-00 00:00:00'),(2,1,823471919,2,1,'Test Campaign',10000,00000,'This is the story of this stock image guy.','pending','2017-05-17 21:04:49','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donation`
--

DROP TABLE IF EXISTS `donation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donation` (
  `donation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) DEFAULT NULL,
  `wepay_preapproval_id` bigint(20) DEFAULT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip` int(5) unsigned zerofill DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `anonymous_flag` tinyint(4) DEFAULT '0',
  `complete_flag` tinyint(4) DEFAULT '0',
  `charged_flag` tinyint(4) DEFAULT '0',
  `wepay_url` varchar(512) DEFAULT NULL,
  `donation_hash` varchar(256) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`donation_id`),
  UNIQUE KEY `donation_id_UNIQUE` (`donation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donation`
--

LOCK TABLES `donation` WRITE;
/*!40000 ALTER TABLE `donation` DISABLE KEYS */;
INSERT INTO `donation` VALUES (1,1,120297598,'Test','Tester','123 Test Street','Test City','CO',12001,'test@testemail.com',100,'This is a comment',0,1,0,'https://stage.wepay.com/api/preapproval/120297598/49baf816','13ecfe6000d011674072e02c74dad867','2017-05-25 20:28:15','2017-05-25 19:18:38'),(2,1,23405877,'Adam','Donation','321 Test Street','Albany','NV',12009,'adamfahrenkopf@gmail.com',200,'This is a test comment for my donation.',0,1,0,'https://stage.wepay.com/api/preapproval/23405877/03f871ae','0ecdb8316fb0a2fe529c55a3a1c675cc','2017-05-29 17:41:45','2017-05-29 17:40:43');
/*!40000 ALTER TABLE `donation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funeral_home`
--

DROP TABLE IF EXISTS `funeral_home`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funeral_home` (
  `funeral_home_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) DEFAULT NULL,
  `funeral_home_name` varchar(256) DEFAULT NULL,
  `funeral_home_contact_name` varchar(256) DEFAULT NULL,
  `funeral_home_phone` varchar(16) DEFAULT NULL,
  `funeral_home_email` varchar(256) DEFAULT NULL,
  `funeral_home_address` varchar(256) DEFAULT NULL,
  `funeral_home_city` varchar(128) DEFAULT NULL,
  `funeral_home_state` varchar(2) DEFAULT NULL,
  `funeral_home_zip` int(5) unsigned zerofill DEFAULT NULL,
  `funeral_home_lat` varchar(256) DEFAULT NULL,
  `funeral_home_lng` varchar(256) DEFAULT NULL,
  `funeral_home_facebook_link` varchar(256) DEFAULT NULL,
  `funeral_home_twitter_link` varchar(256) DEFAULT NULL,
  `funeral_home_google_link` varchar(256) DEFAULT NULL,
  `funeral_home_other_link` varchar(256) DEFAULT NULL,
  `funeral_home_about` text,
  `funeral_home_place_id` varchar(45) DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`funeral_home_id`),
  UNIQUE KEY `funeral_home_id_UNIQUE` (`funeral_home_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funeral_home`
--

LOCK TABLES `funeral_home` WRITE;
/*!40000 ALTER TABLE `funeral_home` DISABLE KEYS */;
INSERT INTO `funeral_home` VALUES (1,0,'New Comer Funerals and Cremations','','+1 518-456-4442','','343 New Karner Road','Colonie','NY',12205,'42.7290084','-73.8543001','','','','','','ChIJqbW5hUVz3okRhbvNsgkfF18',NULL,'2017-05-17 20:54:51'),(2,0,'New Comer Funerals and Cremations','','+1 518-456-4442','','343 New Karner Road','Colonie','NY',12205,'42.7290084','-73.8543001','','','','','','ChIJqbW5hUVz3okRhbvNsgkfF18',NULL,'2017-05-17 20:54:51'),(3,0,'DeMarco-Stone Funeral Home','','+1 518-355-5770','','1605 Helderberg Avenue','Rotterdam','NY',12306,'42.785611','-73.95976','','','','','','ChIJL_s4Ib5x3okROjL6iWVDBZ0',NULL,'2017-05-17 20:54:51'),(4,0,'DeMarco-Stone Funeral Home','','+1 518-355-5770','','1605 Helderberg Avenue','Rotterdam','NY',12306,'42.785611','-73.95976','','','','','','ChIJL_s4Ib5x3okROjL6iWVDBZ0',NULL,'2017-05-17 20:54:51'),(5,0,'W J Lyons Jr Funeral Home Inc','','+1 518-286-3400','','1700 Washington Avenue','Rensselaer','NY',12144,'42.6540614','-73.7034842','','','','','','ChIJG03bAKsJ3okRnHNWcpNSuhU',NULL,'2017-05-17 20:54:52'),(6,0,'W J Lyons Jr Funeral Home Inc','','+1 518-286-3400','','1700 Washington Avenue','Rensselaer','NY',12144,'42.6540614','-73.7034842','','','','','','ChIJG03bAKsJ3okRnHNWcpNSuhU',NULL,'2017-05-17 20:54:52'),(7,0,'Bond Funeral Home','','+1 518-346-8424','','1614 Guilderland Avenue','Schenectady','NY',12306,'42.799613','-73.959863','','','','','','ChIJ-0jq8-dx3okR88LAsIGBvRI',NULL,'2017-05-17 20:54:52'),(8,0,'Bond Funeral Home','','+1 518-346-8424','','1614 Guilderland Avenue','Schenectady','NY',12306,'42.799613','-73.959863','','','','','','ChIJ-0jq8-dx3okR88LAsIGBvRI',NULL,'2017-05-17 20:54:52'),(9,0,'Glenville Funeral Home','','+1 518-399-1630','','9 Glenridge Road','Scotia','NY',12302,'42.869195','-73.929229','','','','','','ChIJgYZyQxts3okR2qIvOvMJXGM',NULL,'2017-05-17 20:54:53'),(10,0,'Glenville Funeral Home','','+1 518-399-1630','','9 Glenridge Road','Scotia','NY',12302,'42.869195','-73.929229','','','','','','ChIJgYZyQxts3okR2qIvOvMJXGM',NULL,'2017-05-17 20:54:53'),(11,0,'McLoughlin & Mason Funeral Home','','+1 518-235-1722','','8 109th Street','Troy','NY',12182,'42.766929','-73.679822','','','','','','ChIJjwJHg98P3okRxgsn34EGBrs',NULL,'2017-05-17 20:54:53'),(12,0,'McLoughlin & Mason Funeral Home','','+1 518-235-1722','','8 109th Street','Troy','NY',12182,'42.766929','-73.679822','','','','','','ChIJjwJHg98P3okRxgsn34EGBrs',NULL,'2017-05-17 20:54:53'),(13,0,'A J Cunningham Funeral Home','','+1 518-966-8313','','4898 New York 81','Greenville','NY',12083,'42.416139','-74.0234739','','','','','','ChIJg0i3qBjG3YkRHXThdDcTHTg',NULL,'2017-05-17 20:54:54'),(14,0,'A J Cunningham Funeral Home','','+1 518-966-8313','','4898 New York 81','Greenville','NY',12083,'42.416139','-74.0234739','','','','','','ChIJg0i3qBjG3YkRHXThdDcTHTg',NULL,'2017-05-17 20:54:54'),(15,0,'Mereness-Putnam Funeral Home','','+1 518-234-3549','','171 Elm Street','Cobleskill','NY',12043,'42.677753','-74.494365','','','','','','ChIJvUB78Msm3IkRIECNhwxosnM',NULL,'2017-05-17 20:54:54'),(16,0,'Mereness-Putnam Funeral Home','','+1 518-234-3549','','171 Elm Street','Cobleskill','NY',12043,'42.677753','-74.494365','','','','','','ChIJvUB78Msm3IkRIECNhwxosnM',NULL,'2017-05-17 20:54:54'),(17,0,'Babcock Funeral Home Inc','','+1 518-756-8333','','19 Pulver Avenue','Ravena','NY',12143,'42.4730678','-73.8128458','','','','','','ChIJH0x2InLo3YkRCK0UXQCFdNs',NULL,'2017-05-17 20:54:54'),(18,0,'Babcock Funeral Home Inc','','+1 518-756-8333','','19 Pulver Avenue','Ravena','NY',12143,'42.4730678','-73.8128458','','','','','','ChIJH0x2InLo3YkRCK0UXQCFdNs',NULL,'2017-05-17 20:54:55'),(19,0,'Riley Mortuary Inc','','+1 518-842-2810','','110 Division Street','Amsterdam','NY',12010,'42.9426086','-74.198295','','','','','','ChIJRxUNxMZh3okRMtDmYUrQ07c',NULL,'2017-05-17 20:54:55'),(20,0,'Riley Mortuary Inc','','+1 518-842-2810','','110 Division Street','Amsterdam','NY',12010,'42.9426086','-74.198295','','','','','','ChIJRxUNxMZh3okRMtDmYUrQ07c',NULL,'2017-05-17 20:54:55'),(21,0,'William Leahy Funeral Home','','+1 518-272-3541','','336 3rd Street','Troy','NY',12180,'42.7191588','-73.6926432','','','','','','ChIJ6_hgqBsP3okRY1cXMAfN1PE',NULL,'2017-05-17 20:54:55'),(22,0,'William Leahy Funeral Home','','+1 518-272-3541','','336 3rd Street','Troy','NY',12180,'42.7191588','-73.6926432','','','','','','ChIJ6_hgqBsP3okRY1cXMAfN1PE',NULL,'2017-05-17 20:54:55'),(23,0,'McVeigh Funeral Home','','+1 518-489-0188','','208 North Allen Street','Albany','NY',12206,'42.67345','-73.785174','','','','','','ChIJQUxqdq4L3okRIRNGbefgACg',NULL,'2017-05-17 20:54:56'),(24,0,'McVeigh Funeral Home','','+1 518-489-0188','','208 North Allen Street','Albany','NY',12206,'42.67345','-73.785174','','','','','','ChIJQUxqdq4L3okRIRNGbefgACg',NULL,'2017-05-17 20:54:56'),(25,0,'William J Rockefeller Funeral Home, Inc.','','+1 518-449-7047','','165 Columbia Turnpike','Rensselaer','NY',12144,'42.620069','-73.734404','','','','','','ChIJtXT4kgji3YkROGa1jY94T3k',NULL,'2017-05-17 20:54:56'),(26,0,'William J Rockefeller Funeral Home, Inc.','','+1 518-449-7047','','165 Columbia Turnpike','Rensselaer','NY',12144,'42.620069','-73.734404','','','','','','ChIJtXT4kgji3YkROGa1jY94T3k',NULL,'2017-05-17 20:54:56'),(27,0,'Levine Memorial Chapel Inc','','+1 518-438-1002','','649 Washington Avenue','Albany','NY',12206,'42.6670768','-73.7804911','','','','','','ChIJBWMUJk0K3okR56avoGhlwxk',NULL,'2017-05-17 20:54:56'),(28,0,'Levine Memorial Chapel Inc','','+1 518-438-1002','','649 Washington Avenue','Albany','NY',12206,'42.6670768','-73.7804911','','','','','','ChIJBWMUJk0K3okR56avoGhlwxk',NULL,'2017-05-17 20:54:56'),(29,0,'Philip J Brendese Funeral Home','','+1 518-237-8296','','133 Broad Street','Waterford','NY',12188,'42.7917309','-73.682967','','','','','','ChIJkeqU_0MQ3okRJpNukikOHaQ',NULL,'2017-05-17 20:54:57'),(30,0,'Philip J Brendese Funeral Home','','+1 518-237-8296','','133 Broad Street','Waterford','NY',12188,'42.7917309','-73.682967','','','','','','ChIJkeqU_0MQ3okRJpNukikOHaQ',NULL,'2017-05-17 20:54:57'),(31,0,'Catricala Funeral Home, Inc.','','+1 518-371-5334','','1597 U.S. 9','','NY',12065,'42.8518209','-73.756009','','','','','','ChIJ6cN_HPkT3okRahRmIa6_1YM',NULL,'2017-05-17 20:54:57'),(32,0,'Catricala Funeral Home, Inc.','','+1 518-371-5334','','1597 U.S. 9','','NY',12065,'42.8518209','-73.756009','','','','','','ChIJ6cN_HPkT3okRahRmIa6_1YM',NULL,'2017-05-17 20:54:57'),(33,0,'Tebbutt Funeral Home','','+1 518-489-4451','','633 Central Avenue','Albany','NY',12206,'42.6745258','-73.7831945','','','','','','ChIJJVOjJ64L3okRIK2hXymCIdE',NULL,'2017-05-17 20:54:57'),(34,0,'Tebbutt Funeral Home','','+1 518-489-4451','','633 Central Avenue','Albany','NY',12206,'42.6745258','-73.7831945','','','','','','ChIJJVOjJ64L3okRIK2hXymCIdE',NULL,'2017-05-17 20:54:57'),(35,0,'Daniel Keenan Funeral Home','','+1 518-463-1594','','490 Delaware Avenue','Albany','NY',12209,'42.6392421','-73.7862501','','','','','','ChIJOyHFJnsK3okRPhmI2bUlFXo',NULL,'2017-05-17 20:54:58'),(36,0,'Daniel Keenan Funeral Home','','+1 518-463-1594','','490 Delaware Avenue','Albany','NY',12209,'42.6392421','-73.7862501','','','','','','ChIJOyHFJnsK3okRPhmI2bUlFXo',NULL,'2017-05-17 20:54:58'),(37,0,'Applebee Funeral Home Inc','','+1 518-439-2715','','403 Kenwood Avenue','Delmar','NY',12054,'42.622693','-73.83363','','','','','','ChIJVT3YLgzg3YkRjPsisIOu3N8',NULL,'2017-05-17 20:54:58'),(38,0,'Applebee Funeral Home Inc','','+1 518-439-2715','','403 Kenwood Avenue','Delmar','NY',12054,'42.622693','-73.83363','','','','','','ChIJVT3YLgzg3YkRjPsisIOu3N8',NULL,'2017-05-17 20:54:58'),(39,0,'Bryce Funeral Home Inc','','+1 518-272-7281','','276 Pawling Avenue','Troy','NY',12180,'42.7127843','-73.6667245','','','','','','ChIJ1Y6NtmgP3okRSdaN5GyjWaw',NULL,'2017-05-17 20:54:59'),(40,0,'Bryce Funeral Home Inc','','+1 518-272-7281','','276 Pawling Avenue','Troy','NY',12180,'42.7127843','-73.6667245','','','','','','ChIJ1Y6NtmgP3okRSdaN5GyjWaw',NULL,'2017-05-17 20:54:59');
/*!40000 ALTER TABLE `funeral_home` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `wepay_user_id` int(10) DEFAULT NULL,
  `first_name` varchar(256) DEFAULT NULL,
  `last_name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `user_level` varchar(45) NOT NULL DEFAULT 'basic',
  `zip` varchar(5) DEFAULT NULL,
  `picture` text,
  `picture_from` varchar(32) DEFAULT NULL,
  `wepay_access_token` varchar(256) DEFAULT NULL,
  `wepay_token_type` varchar(64) DEFAULT NULL,
  `wepay_token_expires` int(10) DEFAULT NULL,
  `is_admin` int(1) unsigned DEFAULT '0',
  `created_by` enum('google','facebook','normal') DEFAULT NULL,
  `ts_last_login` timestamp NULL DEFAULT NULL,
  `ts_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ts_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,208908684,'Adam','Fahrenkopf','adamfahrenkopf@gmail.com','098f6bcd4621d373cade4e832627b4f6','basic',NULL,'','normal','STAGE_860b69785b933e89ca7f5c5dffc6002a805d50f89e41c2a653bfc7f7a933e65f','BEARER',3877606,0,'normal','2017-05-29 16:24:01','2017-05-29 16:24:01','2017-05-17 20:54:14');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'my_respects_fund'
--
/*!50003 DROP PROCEDURE IF EXISTS `campaign_assign_main_image` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_assign_main_image`(
	IN v_campaign_id INT(10),
    IN v_campaign_image_id INT(10)
)
BEGIN

	UPDATE campaign
		SET campaign_image_id = v_campaign_image_id
	WHERE campaign_id = v_campaign_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_image_delete`(
	IN v_campaign_image_id INT(10)
)
BEGIN
	DELETE FROM campaign_image WHERE campaign_image_id = v_campaign_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_image_insert`(
	IN v_campaign_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO campaign_image
		(campaign_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_campaign_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'campaign_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_insert`(
	IN v_user_id INT(10),
	IN v_funeral_home_id INT(10),
	IN v_campaign_image_id INT(10),
	IN v_campaign_title VARCHAR(256),
	IN v_campaign_goal INT(10), 
	IN v_campaign_zip INT(5),
	IN v_campaign_story TEXT
)
BEGIN

	INSERT INTO campaign
		(user_id, funeral_home_id, campaign_image_id, campaign_title, campaign_goal, campaign_zip, campaign_story)
	VALUES
		(v_user_id, v_funeral_home_id, v_campaign_image_id, v_campaign_title, v_campaign_goal, v_campaign_zip, v_campaign_story);
	
    SELECT LAST_INSERT_ID() as `campaign_id`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `campaign_update_wepay_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `campaign_update_wepay_by_id`(
	IN v_campaign_id INT(10),
    IN v_wepay_account_id INT(10),
    IN v_wepay_account_state VARCHAR(64)
)
BEGIN

	UPDATE campaign SET
		wepay_account_id = v_wepay_account_id,
        wepay_account_state = v_wepay_account_state
	WHERE campaign_id = v_campaign_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_funeral_home_by_name` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_funeral_home_by_name`(
	v_funeral_home_name TEXT
)
BEGIN

	SELECT funeral_home_id, funeral_home_name, funeral_home_address, funeral_home_state, funeral_home_city, funeral_home_zip, funeral_home_email, funeral_home_phone From funeral_home WHERE funeral_home_name LIKE CONCAT('%', v_funeral_home_name, '%');
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_exists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_exists`(
	IN v_email_address VARCHAR(256)
)
BEGIN
	SELECT EXISTS( SELECT 1 FROM user WHERE email = v_email_address );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_is_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_is_admin`(
	IN v_user_id INT(10)
)
BEGIN

	SELECT EXISTS( SELECT 1 FROM user WHERE user_id = v_user_id AND is_admin = 1 );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `check_user_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_password`(
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256)
)
BEGIN
	IF EXISTS( SELECT 1 FROM user WHERE `email` = v_email AND `password` = v_password ) THEN
		BEGIN
			SELECT `email`, `first_name`, `last_name`, `picture` FROM user WHERE `email` = v_email;
		END;
	ELSE
		BEGIN
			SELECT 0;
		END;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_user`(
	IN v_first_name VARCHAR(256),
	IN v_last_name VARCHAR(256),
	IN v_email VARCHAR(256),
	IN v_password VARCHAR(256),
	IN v_picture TEXT,
	IN v_picture_from VARCHAR(32),
	IN v_created_by ENUM('google','facebook','normal')
)
BEGIN

	INSERT INTO user (`first_name`,`last_name`,`email`,`password`,`picture`,`picture_from`,`created_by`,`ts_created`)
						VALUES
					 (v_first_name,v_last_name,v_email,v_password,v_picture,v_picture_from,v_created_by,NOW());
	
	SELECT last_insert_id();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `donation_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `donation_insert`(
	IN v_wepay_preapproval_id BIGINT,
    IN v_campaign_id INT(10),
	IN v_first_name VARCHAR(128),
	IN v_last_name VARCHAR(128),
	IN v_address VARCHAR(128),
	IN v_city VARCHAR(128),
	IN v_state VARCHAR(2),
	IN v_zip INT(5) ZEROFILL,
	IN v_email VARCHAR(256),
	IN v_amount FLOAT,
	IN v_description VARCHAR(256),
	IN v_wepay_url VARCHAR(512),
    IN v_anonymous_flag TINYINT,
    IN v_donation_hash VARCHAR(256)
)
BEGIN

	INSERT INTO donation
		(wepay_preapproval_id,campaign_id,first_name,last_name,address,city,state,zip,email,amount,description,wepay_url,anonymous_flag,donation_hash,ts_created)
	VALUES
		(v_wepay_preapproval_id,v_campaign_id,v_first_name,v_last_name,v_address,v_city,v_state,v_zip,v_email,v_amount,v_description,v_wepay_url,v_anonymous_flag,v_donation_hash, NOW());

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_image_delete`(
	IN v_funeral_home_image_id INT(10)
)
BEGIN
	DELETE FROM funeral_home_image WHERE funeral_home_image_id = v_funeral_home_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_image_insert`(
	IN v_funeral_home_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO funeral_home_image
		(funeral_home_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_funeral_home_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'funeral_home_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_insert`(
	IN v_partner_id INT(10),
	IN v_funeral_home_name VARCHAR(256),
	IN v_funeral_home_contact_name VARCHAR(256),
	IN v_funeral_home_phone VARCHAR(16),
	IN v_funeral_home_email VARCHAR(256),
	IN v_funeral_home_address VARCHAR(256),
	IN v_funeral_home_city VARCHAR(128),
	IN v_funeral_home_state VARCHAR(2),
	IN v_funeral_home_zip INT(5) ZEROFILL,
	IN v_funeral_home_lat VARCHAR(256),
	IN v_funeral_home_lng VARCHAR(256),
	IN v_funeral_home_facebook_link VARCHAR(256),
	IN v_funeral_home_twitter_link VARCHAR(256),
	IN v_funeral_home_google_link VARCHAR(256),
	IN v_funeral_home_other_link VARCHAR(256),
	IN v_funeral_home_about TEXT,
	IN v_funeral_home_place_id TEXT
)
BEGIN

	INSERT INTO funeral_home
		(partner_id, funeral_home_name, funeral_home_contact_name, funeral_home_phone, funeral_home_email, funeral_home_address, funeral_home_city, funeral_home_state, funeral_home_zip, funeral_home_lat, funeral_home_lng, funeral_home_facebook_link, funeral_home_twitter_link, funeral_home_google_link, funeral_home_other_link, funeral_home_about, funeral_home_place_id, ts_created)
	VALUES 
		(v_partner_id, v_funeral_home_name, v_funeral_home_contact_name, v_funeral_home_phone, v_funeral_home_email, v_funeral_home_address, v_funeral_home_city, v_funeral_home_state, v_funeral_home_zip, v_funeral_home_lat, v_funeral_home_lng, v_funeral_home_facebook_link, v_funeral_home_twitter_link, v_funeral_home_google_link, v_funeral_home_other_link, v_funeral_home_about, v_funeral_home_place_id, NOW());
        
	SELECT LAST_INSERT_ID() as `funeral_home_id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_search` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_search`(
	v_lat VARCHAR(256),
	v_lng VARCHAR(256)
)
BEGIN

	SELECT funeral_home_id, funeral_home_name, funeral_home_address, funeral_home_city, funeral_home_state, funeral_home_zip, funeral_home_lat, funeral_home_lng, funeral_home_place_id
	FROM funeral_home 
	WHERE 
		(3959 
			* ACOS( 
				COS( RADIANS( v_lat ) )
				* COS( RADIANS( funeral_home_lat ) )
				* COS( RADIANS( funeral_home_lng ) - RADIANS( v_lng ) )
				+ SIN( RADIANS( v_lat ) )
				* SIN( RADIANS( funeral_home_lat ) )
			)
		) < 30;
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `funeral_home_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `funeral_home_update`(
	IN v_funeral_home_id INT(10),
	IN v_partner_id INT(10),
	IN v_funeral_home_name VARCHAR(256),
	IN v_funeral_home_contact_name VARCHAR(256),
	IN v_funeral_home_phone VARCHAR(16),
	IN v_funeral_home_email VARCHAR(256),
	IN v_funeral_home_address VARCHAR(256),
	IN v_funeral_home_city VARCHAR(128),
	IN v_funeral_home_state VARCHAR(2),
	IN v_funeral_home_zip INT(5) ZEROFILL,
	IN v_funeral_home_lat VARCHAR(256),
	IN v_funeral_home_lng VARCHAR(256),
	IN v_funeral_home_facebook_link VARCHAR(256),
	IN v_funeral_home_twitter_link VARCHAR(256),
	IN v_funeral_home_google_link VARCHAR(256),
	IN v_funeral_home_other_link VARCHAR(256),
	IN v_funeral_home_about TEXT,
	IN v_funeral_home_place_id TEXT
)
BEGIN

	UPDATE funeral_home SET
		partner_id = v_partner_id, 
		funeral_home_name = v_funeral_home_name, 
		funeral_home_contact_name = v_funeral_home_contact_name, 
		funeral_home_phone = v_funeral_home_phone, 
		funeral_home_email = v_funeral_home_email, 
		funeral_home_address = v_funeral_home_address, 
		funeral_home_city = v_funeral_home_city, 
		funeral_home_state = v_funeral_home_state, 
		funeral_home_zip = v_funeral_home_zip, 
		funeral_home_lat = v_funeral_home_lat, 
		funeral_home_lng = v_funeral_home_lng, 
		funeral_home_facebook_link = v_funeral_home_facebook_link, 
		funeral_home_twitter_link = v_funeral_home_twitter_link, 
		funeral_home_google_link = v_funeral_home_google_link, 
		funeral_home_other_link = v_funeral_home_other_link, 
		funeral_home_about = v_funeral_home_about, 
		funeral_home_place_id = v_partner_id
	WHERE funeral_home_id = v_funeral_home_place_id;

	SELECT v_funeral_home_id as `funeral_home_id`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `general_log_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `general_log_insert`(
	IN v_user_id int(10),
	IN v_campaign_id int(10),
	IN v_funeral_home_id int(10),
	IN v_log_type varchar(64),
	IN v_log_event varchar(512)
)
BEGIN

	INSERT INTO general_log
		(user_id, campaign_id, funeral_home_id, log_type, log_event)
	VALUES
		(v_user_id, v_campaign_id, v_funeral_home_id, v_log_type, v_log_event);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_campaign_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_campaign_data`(
	v_campaign_id INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		c.campaign_story,
		c.wepay_account_id,
		DATE(c.ts_created) as `start_date`,
		ci.image_name as `main_campaign_image`,
		fh.funeral_home_name,
		fh.funeral_home_phone,
		fh.funeral_home_email,
		fh.funeral_home_address,
		fh.funeral_home_city,
		fh.funeral_home_state,
		fh.funeral_home_zip,
		fh.funeral_home_facebook_link,
		fh.funeral_home_twitter_link,
		fh.funeral_home_google_link,
		fh.funeral_home_about,
		u.first_name,
		u.last_name,
		u.wepay_access_token
		
		-- @todo Still need to link in a donation table to get who donated/how much --> should this be a separate query? we may have a lot of donations
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
			LEFT JOIN
		funeral_home fh ON fh.funeral_home_id = c.funeral_home_id
	WHERE 
		c.campaign_id = v_campaign_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_funeral_home_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_funeral_home_details`(
	v_funeral_home_id INT
)
BEGIN
	
	SELECT 
		`funeral_home`.`funeral_home_id`,
		`funeral_home`.`partner_id`,
		`funeral_home`.`funeral_home_name`,
		`funeral_home`.`funeral_home_contact_name`,
		`funeral_home`.`funeral_home_phone`,
		`funeral_home`.`funeral_home_email`,
		`funeral_home`.`funeral_home_address`,
		`funeral_home`.`funeral_home_city`,
		`funeral_home`.`funeral_home_state`,
		`funeral_home`.`funeral_home_zip`,
		`funeral_home`.`funeral_home_lat`,
		`funeral_home`.`funeral_home_lng`,
		`funeral_home`.`funeral_home_facebook_link`,
		`funeral_home`.`funeral_home_twitter_link`,
		`funeral_home`.`funeral_home_google_link`,
		`funeral_home`.`funeral_home_other_link`,
		`funeral_home`.`funeral_home_about`,
		`funeral_home`.`funeral_home_place_id`
	FROM `my_respects_fund`.`funeral_home`
	WHERE `funeral_home_id` = v_funeral_home_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_location_info_by_zip` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_location_info_by_zip`(
	IN v_zip VARCHAR(16)
)
BEGIN
	SELECT lat, lng, city, country, state, zip_code FROM zip_code_info WHERE zip_code = v_zip;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_search_results` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_results`(
	v_search_value TEXT,
	v_start_index INT
)
BEGIN

	SELECT 
		c.campaign_id,
		c.campaign_title,
		c.campaign_goal,
		ci.image_name,
		LEFT( c.campaign_story, 280 ) AS `campaign_story`
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
			LEFT JOIN
		campaign_image ci ON ci.campaign_image_id = c.campaign_image_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' )
	ORDER BY
		c.ts_created DESC
	LIMIT v_start_index, 30;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_search_result_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_search_result_count`(
	v_search_value TEXT
)
BEGIN
	
	SELECT 
		COUNT(*)
	FROM 
		campaign c
			LEFT JOIN
		user u ON u.user_id = c.user_id
	WHERE 
		c.campaign_zip = v_search_value 
		OR c.campaign_title LIKE CONCAT('%', v_search_value , '%')
		OR CONCAT( u.first_name,' ',u.last_name ) LIKE CONCAT( '%', v_search_value, '%' );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_user_info` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_info`(
	v_email TEXT
)
BEGIN
	
	SELECT * FROM user WHERE email = v_email LIMIT 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_wepay_token_by_user_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_wepay_token_by_user_id`(
	IN v_user_id INT(10)
)
BEGIN

	SELECT wepay_access_token FROM user WHERE user_id = v_user_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_donation_as_complete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_donation_as_complete`(
	IN v_preapproval_id BIGINT
)
BEGIN

	UPDATE donation
		SET complete_flag = 1
	WHERE wepay_preapproval_id = v_preapproval_id;
    
    SELECT * FROM donation where wepay_preapproval_id = v_preapproval_id AND complete_flag = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_last_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_last_login`(
	IN v_email VARCHAR(256)
)
BEGIN
	UPDATE user SET `ts_last_login` = NOW() WHERE `email` = v_email;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_image_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_image_delete`(
	IN v_user_image_id INT(10)
)
BEGIN
	DELETE FROM user_image WHERE user_image_id = v_user_image_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_image_insert` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_image_insert`(
	IN v_user_id INT(10),
	IN v_image_name VARCHAR(260),
	IN v_container_name VARCHAR(45),
	IN v_image_size INT(10),
	IN v_image_type VARCHAR(16)
)
BEGIN
	INSERT INTO user_image
		(user_id, image_name, container_name, image_size, image_type)
	VALUES
		(v_user_id, v_image_name, v_container_name, v_image_size, v_image_type);
		
	SELECT LAST_INSERT_ID() as 'user_image_id';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_update_wepay_by_email` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_update_wepay_by_email`(
	IN v_email VARCHAR(256),
    IN v_wepay_user_id INT(10),
    IN v_wepay_access_token VARCHAR(256),
    IN v_wepay_token_type VARCHAR(64),
    IN v_wepay_token_expires INT(10)
)
BEGIN

	UPDATE user SET
		wepay_user_id = v_wepay_user_id,
		wepay_access_token = v_wepay_access_token, 
        wepay_token_type = v_wepay_token_type,
        wepay_token_expires = v_wepay_token_expires
	WHERE 
		email = v_email;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-29 13:43:55
