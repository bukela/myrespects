<?php 
/*
 * Placeholder UI so we can test functionality
 */

require_once '_includes/header.php';

?>

<!-- #Page title starts -->
<section class="page_title_areamain fix">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="page_title_areaall fix">
					<div class="start_campagn_titleara fix">
						<div class="start_campagn_title_wrappr fix">
							<div class="page_title_are fix start_campagn_pgtitle">
								<h1>List Your Funeral Home</h1>
							</div>
							<div class="page_subtitle_are fix">
								<p>Please fill out the information below and we will add you to our database.The database is used by funeral fund owners to find funeral homes.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- #Page title End-->

<!-- #support-campaign starts -->
<section class="comomn_page_container search_page_content fix">
	<div class="list_funeral_homearea fix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="list_funeral_homearea_form fix">
    			<?php 
    				/* should also check active campaigns */
    				if( ! $o_user->is_logged_in() ) {
    					echo "You need to login...";
    				} else {
    			?>
				<form action="" method="post" enctype="multipart/form-data" id="create_campaign_form">
					<input type="hidden" name="ss" id="ss" value="<?php echo( $o_user->get_session_string() ); ?>" />
					<div class="list_funeral_left fix col-sm-6">
								<div class="list_funeral_left_title fix">
									<h2>Funeral Home Contact Information</h2>
								</div>
								<div class="list_funeral_left_input fix">
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_name">Funeral Home Name</label>
											<input type="text" class="form_input_field" id="funeral_home_name" name="funeral_home_name" placeholder="Home Name">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_contact_name">Contact Name</label>
											<input type="text" class="form_input_field" id="funeral_home_contact_name" name="funeral_home_contact_name" placeholder="Contact Name">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_address">Address</label>
											<input type="text" class="form_input_field" id="funeral_home_address" name="funeral_home_address" placeholder="Address">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_city">City</label>
											<input type="text" class="form_input_field" id="funeral_home_city" name="funeral_home_city" placeholder="City">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_state">State</label>
											<select name="funeral_home_state" id="funeral_home_state" class="form_select_field">
												<option value="">State 1</option>
												<option value="">State 2</option>
												<option value="">State 3</option>
											</select>				
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_zip">Zip/Postal code</label>
											<input type="text" class="form_input_field" id="funeral_home_zip" name="funeral_home_zip" placeholder="Zip Code">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="">Phone</label>
											<input type="tel" class="form_input_field" id="funeral_home_phone" name="funeral_home_phone" placeholder="Phone Number">					
										</div>
									</div>
									<div class="col-sm-6 list_funeral_item">
										<div class="form_input_area fix">
											<label for="funeral_home_email">Email</label>
											<input type="email" class="form_input_field" id="funeral_home_email" name="funeral_home_email" placeholder="Email">					
										</div>
									</div>
									<div class="col-sm-12 list_funeral_item">
										<div class="form_input_area fix">
											<label for="">Communities Served</label>
											<textarea class="list_funera_textarea" name="" id="" cols="30" rows="10"></textarea>					
										</div>
									</div>
									<div class="col-sm-12 list_funeral_item">
										<div id="possible-matches" style="display:none;" class="row">
											<!-- populated with ajax -->
										</div>
									</div>
								</div>
							</div>
							<div class="list_funeral_right fix col-sm-6">
								<div class="list_funeral_right_top fix">
									<div class="list_funeral_right_title fix">
										<h2>Funeral Home Social Media</h2>
										<div class="add_more_btnarea fix">
											<button class="addmore_btn">+ ADD MORE</button>
										</div>
									</div>
									<div class="list_funeral_right_input fix">
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_socialarea">
												<div class="col-sm-3">
													<label for="funeral_home_facebook_link">Facebook</label>
												</div>
												<div class="col-sm-5">
													<input type="text" class="form_input_field" id="funeral_home_facebook_link" name="funeral_home_facebook_link" placeholder="Facebook">	
												</div>
												<div class="col-sm-4">
													<i class="fa fa-facebook" aria-hidden="true"></i>
												</div>			
											</div>
										</div>
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_socialarea">
												<div class="col-sm-3">
													<label for="funeral_home_twitter_link">Twitter</label>
												</div>
												<div class="col-sm-5">
													<input type="text" class="form_input_field" id="funeral_home_twitter_link" name="funeral_home_twitter_link" placeholder="Twitter">	
												</div>
												<div class="col-sm-4">
													<i class="fa fa-twitter" aria-hidden="true"></i>
												</div>			
											</div>
										</div>
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_socialarea">
												<div class="col-sm-3">
													<label for="funeral_home_google_link">Google +</label>
												</div>
												<div class="col-sm-5">
													<input type="text" class="form_input_field" id="funeral_home_google_link" name="funeral_home_google_link" placeholder="Google+">	
												</div>
												<div class="col-sm-4">
													<i class="fa fa-google-plus" aria-hidden="true"></i>
												</div>			
											</div>
										</div>
										
										
									</div>
								</div>
								<div class="list_funeral_right_bottom fix">
									<div class="list_funeral_right_title fix profile_photo">
										<h2>Funeral Home Profile Photo</h2>
										
									</div>
									<div class="list_funeral_right_input fix">
										
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_profilephto_area">
												<div class="col-sm-3">
													<label for="campaign_image">Upload Photo</label>
												</div>
												<div class="col-sm-5">
													<label class="btn btn-default btn-file">
    													<input type="file" accept="image/*" onchange="javascript:previewImageFromUpload(this.files[0]);" name="campaign_image" id="campaign_image">
													</label>	
												</div>
												<div class="col-sm-4">
													<button class="browse_btn">Browse</button>
												</div>			
											</div>
										</div>
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_profilephto_area">
												<div class="col-sm-3">
													<label for="image_url">Photo Url</label>
												</div>
												<div class="col-sm-5">
													<input type="text" class="form_input_field" id="image_url" name="image_url" placeholder="URL" onchange="javascript:previewImageFromURL(this.value);">	
												</div>
												<div class="col-sm-4">
													<p>(Include http:// or https:// in URL)</p>
												</div>			
											</div>
										</div>
										<div class="list_funeral_item">
											<div class="form_input_area fix form_input_profilephto_area">
												<div class="col-sm-3">
													<label for="facebook-image">Facebook</label>
												</div>
												<div class="col-sm-5">
													<input type="hidden" name="facebook_image">
													<br />
													<button type="button" id="facebook-image" class="btn btn-default">Faceebook Image</button>	
												</div>
												<div class="col-sm-4">
													<div class="face_book_btn">
														<a href=""><img class="img-responsive" src="assets/images/button_facebook.png" alt=""></a>
													</div>
												</div>	
												<div class="form-group col-xs-3">
													<button class="btn btn-default" id="remove-image" style="display:none;">Remove Image</button>
    												<img class="col-xs-12" id="funeral_home_image" />
												</div>
  				
							  					<input type="hidden" id="useimage" name="useimage" />
							  					<input type="hidden" id="sideload-image" name="sideload-image" />
							  				
							  					<input type="hidden" id="funeral_home_id" name="funeral_home_id" value="0" />
  						
											</div>
										</div>
										
									</div>
								</div>
								
							</div>
							<div class="list_funeral_bottom fix">
								<div class="col-sm-12 text-center">
									<div class="list_funeral_bottom_submit fix">
										
										<div class="list_funeral_check fix">
											<div class="checkbox_wrapper fix">
												   <input type="checkbox" id="checkbox1" name="name">
												   <span class="checked"></span>
											</div>
											<label for="">Add me as a partner.  <a href="" style="color:#561e7a;">(Learn more about My Respects partnership.)</a></label>
										</div>
										<input type="submit" value="submit" class="form_submtbtn">
										<button type="submit" name="create_partner" id="create_partner" class="btn btn-default">Submit</button>
										
									</div>
								</div>
							</div>
				
<?php /*
    				<div class="form-group col-xs-3">
    					<label for="funeral_home_other_link">Other</label>
    					<input type="text" class="form-control" id="funeral_home_other_link" name="funeral_home_other_link" placeholder="Other">
					</div>
	*/	?>		
				
  					
					
				<script type="text/javascript">

					$('#funeral_home_name').change(function(){
						$.ajax({
							type: 'POST',
							url: '/ajax/match-funeral-home.php',
							data: { 'funeral_home_name': $(this).val() },
							beforeSend:function(){},
							success:function( data ){

								data = JSON.parse( data );
								
								if ( data.length > 0 ) {

									$('#possible-matches').html('');
									
									$.each( data, function( key, value ) {
										html ='';
										html = '<div class="col-xs-6">'+
												'<div class="col-xs-6">'+
													'<span>'+value.funeral_home_name+'</span>'+
													'<br>'+
													'<span>'+value.funeral_home_address+'</span>'+
													'<br>'+
													'<span>'+value.funeral_home_city+', '+value.funeral_home_state+' '+value.funeral_home_zip+'</span>'+
												'</div>'+
												'<div class="col-xs-6">'+
													'<button data-id="'+value.funeral_home_id+'" data-name="'+value.funeral_home_name+'" data-address="'+value.funeral_home_address+'" data-city="'+value.funeral_home_city+'" data-state="'+value.funeral_home_state+'" data-zip="'+value.funeral_home_zip+'" data-phone="'+value.funeral_home_phone+'" data-email="'+value.funeral_home_email+'" class="claim-funeral-home" >Claim this Funeral Home!</button>'+
												'</div>'+
											'</div>';
										$('#possible-matches').append( html );
									});
									$('#possible-matches').slideDown();
								}
							},	
							error:function(){}
						});
					});

					$('#possible-matches').on('click', '.claim-funeral-home', function(){

						$('#funeral_home_id').val( $(this).data('id') );
						$('#funeral_home_name').val( $(this).data('name') );
						$('#funeral_home_phone').val( $(this).data('phone') );
						$('#funeral_home_email').val( $(this).data('email') );
						$('#funeral_home_address').val( $(this).data('address') );
						$('#funeral_home_city').val( $(this).data('city') );
						$('#funeral_home_state').val( $(this).data('state') );
						$('#funeral_home_zip').val( $(this).data('zip') );

						$('#possible-matches').slideUp();

					});
				
					$('#facebook-image').click(function(e){
						e.preventDefault();

						FB.getLoginStatus(function(response) {
							if (response.status === 'connected') {

								FB.api( "/me/picture?redirect=false&width=480", function (response) {
									if (response && !response.error) {

										$('#campaign_image').val('');
										$('#image_url').val('');
										$('#funeral_home_image').attr( 'src', response.data.url );
										$('#sideload-image').val( response.data.url );
										$('#useimage').val('facebook'); 
										$('#remove-image').show();
										$('#funeral_home_image').show();
									}
								});
									
							} else {

								FB.login(function(response){
							    	FB.api( "/me/picture?redirect=false&width=480", function (response) {
										if (response && !response.error) {

											$('#campaign_image').val('');
											$('#image_url').val('');
											$('#funeral_home_image').attr( 'src', response.data.url );
											$('#sideload-image').val( response.data.url );
											$('#useimage').val('facebook');
											$('#remove-image').show();
											$('#funeral_home_image').show();
										}
									});
							    });
							}
						 });

					});

					function previewImageFromUpload( file ){

						$('#funeral_home_image').attr( 'src', URL.createObjectURL( file ) );
						$('#useimage').val('upload');
						$('#sideload-image').val('');
						$('#image_url').val('');
						$('#remove-image').show();
						$('#funeral_home_image').show();
					}

					function previewImageFromURL( url ) {

						$('#campaign_image').val('');
						$('#funeral_home_image').attr( 'src', url );
						$('#sideload-image').val( url );
						$('#useimage').val('url');
						$('#remove-image').show();
						$('#funeral_home_image').show();
					} 


					$('#remove-image').click(function(e){
						e.preventDefault();
						$('#funeral_home_image').hide();
						$('#funeral_home_image').removeAttr('src');
						$('#campaign_image').val('');
						$('#image_url').val('');
						$('#sideload-image').val('');
						$('#useimage').val('');
						$('#remove-image').hide();
					});
					

					function validateInput() {

						var invalid = [];
						var valid = [];
						if ( $('#funeral_home_name').val().length == 0 ) {
							invalid.push('funeral_home_name');
						} else {
							valid.push('funeral_home_name');
						}

						if ( $('#funeral_home_contact_name').val().length == 0 ) {
							invalid.push('funeral_home_contact_name');
						} else {
							valid.push('funeral_home_contact_name');
						}

						if ( $('#funeral_home_phone').val().length == 0 ) {
							invalid.push('funeral_home_phone');
						} else {
							if ( /[()\-\s0-9]/.test( $('#funeral_home_phone').val() ) ) {
								valid.push('funeral_home_phone');
							} else {
								invalid.push('funeral_home_phone');
							}
						}

						if ( $('#funeral_home_email').val().length == 0 ) {
							invalid.push('funeral_home_email');
						} else {
							if ( /\w+?@\w+?\.\w+/.test( $('#funeral_home_email').val() ) ) {
								valid.push('funeral_home_email');
							} else {
								invalid.push('funeral_home_email');
							}
						}

						if ( $('#funeral_home_address').val().length == 0 ) {
							invalid.push('funeral_home_address');
						} else {
							valid.push('funeral_home_address');
						}

						if ( $('#funeral_home_city').val().length == 0 ) {
							invalid.push('funeral_home_city');
						} else {
							valid.push('funeral_home_city');
						}

						if ( $('#funeral_home_state').val().length == 0 ) {
							invalid.push('funeral_home_state');
						} else {
							valid.push('funeral_home_state');
						}

						if ( $('#funeral_home_zip').val().length == 0 ) {
							invalid.push('funeral_home_zip');
						} else {
							if ( /[0-9\-]/.test( $('#funeral_home_zip').val() ) ) {
								valid.push('funeral_home_zip');
							} else {
								invalid.push('funeral_home_zip');
							}
						}

						if ( valid.length > 0 ) {
							$.each( valid, function( key, value ) {
								$('#'+value).parent().addClass('has-success');
								$('#'+value).parent().removeClass('has-error');
							});
						}

						if ( invalid.length > 0 ) {
							$.each( invalid, function( key, value ) {
								$('#'+value).parent().addClass('has-error');
							});
							return false;
						}
						return true;
					}
				
				$("form#create_campaign_form").submit(function(e){
					e.preventDefault();


					if ( !validateInput() ) {
						return false;
					}
					
				    var formData = new FormData($(this)[0]);
				    $.ajax({
				        url: "./ajax/create-partner.php",
				        type: 'POST',
				        data: formData,
				        async: false,
				        success: function (data) {
					        console.log(data);
							//results = JSON.parse(data);
							//if( results['result'] == false ) {
							//	alert(results['debug']);
							//} else {
							//	alert("Success");
							//}
				            
				        },
				        cache: false,
				        contentType: false,
				        processData: false
				    });

				    return false;
				});

				

				</script>    			
    			<?php 
    				}
    			?>
				    </div>
					
				</div>
			</div>
		</div>
	</div>

</section>
<!-- #support-campaign ends -->
    
    
<?php require_once '_includes/footer.php'; ?>