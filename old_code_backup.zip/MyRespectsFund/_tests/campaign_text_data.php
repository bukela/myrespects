<?php

/*
 * Used this to generate data for campaigns. Have since added the data it added into the sprint_2_test_data.sql file. If you need another 100 campaigns use this again.
 * 
 */

echo "including campaign_base <br/>";

include_once '../classes/campaign_base.php';



$o_cp = new campaign_base();

$a_zip_codes = array( '12304' );

$s_sql = "SELECT zip_code FROM zip_code_info ORDER BY rand() LIMIT 9";
$o_result = $o_cp->query( $s_sql );
if ( $o_result ) {

	while ( $row = $o_result->fetch_assoc()) {
		$a_zip_codes[] = $row['zip_code'];
    }
    $o_result->free();
}

$last_names = array(
		'Abbott',
		'Acevedo',
		'Acosta',
		'Adams',
		'Adkins',
		'Aguilar',
		'Aguirre',
		'Albert',
		'Alexander',
		'Alford',
		'Allen',
		'Allison',
		'Alston',
		'Alvarado',
		'Alvarez',
		'Anderson',
		'Andrews',
		'Anthony',
		'Armstrong',
		'Arnold',
		'Ashley',
		'Atkins',
		'Atkinson',
		'Austin',
		'Avery',
		'Avila',
		'Ayala',
		'Ayers',
		'Bailey',
		'Baird',
		'Baker',
		'Baldwin',
		'Ball',
		'Ballard',
		'Banks',
		'Barber',
		'Barker',
		'Barlow',
		'Barnes',
		'Barnett',
		'Barr',
		'Barrera',
		'Barrett',
		'Barron',
		'Barry',
		'Bartlett',
		'Barton',
		'Bass',
		'Bates',
		'Battle',
);

for ( $i=0; $i < 100; $i++ ) {

	$a_test_data = array(
			'user_id'			=> rand( 1, 5 ),
			'funeral_home_id'	=> rand( 1, 5 ),
			'campaign_title'	=> $last_names[ rand(0,49) ],
			'campaign_goal'		=> rand( 1000, 50000 ),
			'campaign_zip'		=> $a_zip_codes[ rand(0,9) ],
			'campaign_story'	=> 'Tri-tip cow drumstick venison, doner landjaeger short ribs tongue chuck turkey. Landjaeger beef ribs bresaola spare ribs t-bone burgdoggen strip steak. T-bone shank tenderloin, tongue turducken pork belly pancetta ham tail doner cow shoulder capicola. Jowl turkey salami shank. Porchetta leberkas t-bone ham hock. Prosciutto andouille strip steak pig tongue jerky biltong pancetta tri-tip landjaeger fatback.',
	);

	$o_cp->create_campaign( $a_test_data, '' );
}

