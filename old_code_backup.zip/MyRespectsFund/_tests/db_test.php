<?php

/*
 * Quick test to see if DB connector is working.
 * Include this somewhere in the UI to test... should obviously not be used in production.
 */

echo "including db_base <br/>";

include_once 'classes/db_base.php';

$o_db = new db_base();

if ( ! is_object( $o_db ) ) {
	exit("failed to create db object<br/>");
}

$s_sql = "INSERT INTO test_table (test_value) VALUES ('test value 1');";

echo "running $s_sql<br/>";

$o_result = $o_db->query( $s_sql );

if ( $o_result === false ) {
	echo "query failed:<br/>";
	echo $o_db->get_protected_var("s_debug");
	exit();
}


$i_id = $o_db->get_protected_var("i_last_insert_id");

echo "query didn't fail... lets grab that row. ($i_id)<br/>";

$s_sql = "SELECT * FROM test_table WHERE test_table_id = '" . intval($i_id) . "'";

echo "$s_sql<br/>";

$o_result = $o_db->query( $s_sql );

if ( $o_result === false ) {
	echo "query failed:<br/>";
	echo $o_db->get_protected_var("s_debug");
	exit();
}

$a_row = mysqli_fetch_assoc($o_result);

echo "<pre>" . print_r($a_row, true) . "</pre>";

echo "testing stored procedures<br/>";

$o_result = $o_db->call("test_insert", "'test value " . ($i_id + 1) . "'" );

if ( $o_result === false ) {
	echo "query failed:<br/>";
	echo $o_db->get_protected_var("s_debug");
	echo "<br/>" . $o_db->get_protected_var("s_last_sql") . "<br/>";
	exit();
}

$a_row = mysqli_fetch_assoc($o_result);

echo "<pre>" . print_r($a_row, true) . "</pre>";

$o_result = $o_db->call("test_insert", array('test value ' . ($i_id + 2)) );

if ( $o_result === false ) {
	echo "query failed:<br/>";
	echo $o_db->get_protected_var("s_debug");
	echo "<br/>" . $o_db->get_protected_var("s_last_sql") . "<br/>";
	exit();
}

$a_row = mysqli_fetch_assoc($o_result);

echo "<pre>" . print_r($a_row, true) . "</pre>";


$o_result = $o_db->call("test_select", array($i_id) );

if ( $o_result === false ) {
	echo "query failed:<br/>";
	echo $o_db->get_protected_var("s_debug");
	echo "<br/>" . $o_db->get_protected_var("s_last_sql") . "<br/>";
	exit();
}

while ($a_row = mysqli_fetch_assoc($o_result)) {
	echo "<pre>" . print_r($a_row, true) . "</pre>";
}

echo "<br/><strong>Everything seems to be okay.</strong><br/>";

?>