<?php 
$page = 'partner-dashboard';
$additional_meta = '<link type="text/css" rel="stylesheet" href="assets/css/backend-css.css" />';

require_once '_includes/header.php';
require_once 'classes/funeral_home_base.php';
require_once 'classes/message_base.php';

$o_fb = new funeral_home_base();
$i_funeral_home_id = $o_fb->get_user_funeral_home( $o_user->get_id() ); 
if ( $i_funeral_home_id === FALSE ) {
	header( 'Location: /index.php' );
}
$a_funeral_home = $o_fb->get_funeral_home_details( $i_funeral_home_id );
if ( empty( $a_funeral_home ) ) {
	header( 'Location: /index.php' );
}

$o_messages = new message_base();
$a_messages = $o_messages->get_all_messages_to_partner( $i_funeral_home_id, $o_user->get_id() );
if ( $a_messages['result'] != true ) {
	unset( $a_messages );
} 

$s_current_dashboard_page = isset( $_GET['page'] ) ? addslashes( $_GET['page'] ) : '';

$s_current_url = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];

?>
 <!-- profile starrt -->
<section id="profile-heading">
	<div class="container">
		<div class="col-sm-7">
			<div class="dashboard-top-logo">
				<a href="#"><img src="/assets/images/logo_funeral_mob.png" alt=""></a>
				<div class="dashboard-top-logo-content">
					<h6>Funeral Home</h6>
					<h3>Fundraising for <?php echo $a_funeral_home['funeral_home_name']; ?></h3>
				</div>
			</div>
	
			<ul class="contactlist dashboard-contactlist">
				<li><img src="/assets/images/icon_address_pointer.png" alt="" /> <?php echo $a_funeral_home['funeral_home_city'].", ".$a_funeral_home['funeral_home_state']; ?></li>
				<li><img src="/assets/images/icon_calender.png" alt="" /> Created: <?php echo date( 'F j, Y', strtotime( $a_funeral_home['ts_created'] ) ); ?></li>
				<li><img src="/assets/images/icon_creator.png" alt="" /> Created: <?php echo $a_funeral_home['first_name']." ".$a_funeral_home['last_name']; ?></li>
			</ul>
		</div>
		<div class="col-sm-5">
			<div class="logout">
				<a id="sign-out">log-out</a>
			</div>
			<br>
			<div class="ned_help_btnrow">
				<?php // @todo set up bootstraptour.php and need help overlay ?>
				<a class="need_help_btn dashboard-help-btn" id="dashboard-tour">dashboard tour</a>
				<a class="need_help_btn dashboard-help-btn" href="mailto:admin@myrespects.org">Need Help?</a>
			</div>
		</div>
	</div>
</section> 
<!-- profie end -->

<!-- dashboard menu start -->
<section id="dashboard" class="dashboard-menu-area">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<div class="dash">
					<h2>Partner Dashboard</h2>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- dashboard menu end -->

<!-- dashboard content area start -->
<section id="dash-content" class="dashcont-area clearfix">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="dash-mn">
					<ul class="sdo">
						<li class="home-icon"><a><img src="assets/images/edit-icon.png" alt=""> <h4>edit</h4> </a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'messages' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=messages" ?>">Recent Messages</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'photos' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=photos" ?>">Profile Photos</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'description' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=description" ?>">Profile Description</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'settings' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=settings" ?>">Profile Settings</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'updates' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=updates" ?>">Funeral Home Updates</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'linked' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=linked" ?>">Campaigns Linked</a></li>
						<li <?php echo isset( $s_current_dashboard_page ) && $s_current_dashboard_page == 'requests' ? 'class="active"' : ''; ?>><a href="<?php echo $s_current_url."?page=requests" ?>">Request Literature / MyRespects Call</a></li>
					</ul>
				</div>
			</div>
			
			<div id="dash-ajax-load" class="col-md-6"> <!-- filled with ajax -->
				<?php 
					switch ( $s_current_dashboard_page ) {

						case "messages":
							include_once( 'ajax/partner_profile/messages.php' );
							break;
						case "photos":
							include_once( 'ajax/partner_profile/photos.php' );
							break;
						case "description":
							include_once( 'ajax/partner_profile/description.php' );
							break;
						case "settings":
							include_once( 'ajax/partner_profile/settings.php' );
							break;
						case "updates":
							include_once( 'ajax/partner_profile/updates.php' );
							break;
						case "linked":
							include_once( 'ajax/partner_profile/linked.php' );
							break;
						case "requests":
							include_once( 'ajax/partner_profile/requests.php' );
							break;
						default:
							include_once( 'ajax/partner_profile/dashboard.php' );
							break;
					}
				?>
			 </div>
			
			
			<div class="col-md-3">
				<div class="cres fix">
					<div class="resp-h">
						<div class="hdn-img">
							<img src="assets/images/logo_funeral_mob.png" alt="">
						</div>
						<div class="hdn-hhh"><h3 class="drsh">Contact <br>My Respects</h3></div>
					</div>

					<p><a>CALL: 1.888.123.4567</a></p>
					<p><a>Web Support E-mail</a></p>
				</div>
				<div class="msg sdmdgn fix">
					<div class="hdn">
						<img src="assets/images/edit-icon.png" alt="">
						<h3 class="drsh">Messages <span>(<?php echo isset( $a_messages ) ? $a_messages['count'] : 0; ?>)</span> </h3>
					</div>
					<p><a href="<?php echo $s_current_url."?page=updates" ?>">Send Reminders To Funds</a></p>
					<?php 
						if ( isset( $a_messages ) ) {
							$i_counter = 0;
							foreach ( $a_messages['data'] as $i_message_id => $a_message ) {
								if ( $i_counter >= 2 ) {
									break;
								}
								?>
									<div class="dfrom">
										<h4>From: <?php echo $a_message['name']; ?></h4>
										<h5>Date: <?php echo date( 'F d, Y', strtotime( $a_message['date'] ) ); ?></h5>
										<p><?php echo substr( $a_message['message'], 0, 100 ); ?> ....</p>
							
										<a class="ccbtn" href="<?php echo $s_current_url."?page=messages&id=".$a_message['id']; ?>">REPLY</a>
										<a class="ccbtn delete-message" data-message-id="<?php echo $a_message['id']; ?>">Delete</a>
									</div>				
								<?php 
								$i_counter++;
							}
						}
					?>
					<div class="vbtn"><a class="ccbtn" href="<?php echo $s_current_url."?page=messages" ?>">view all</a></div>
				</div>
				<div class="dclender fix">
					<?php //@todo what is a reminder? ?>
					<div class="set-cal">
						<div class="hdn">
							<img src="assets/images/edit-icon.png" alt="">
							<h3 class="drsh">Reminders <span>(<?php echo isset( $a_messages ) ? $a_messages['count'] : 0; ?>)</span> </h3>
						</div>
					</div>

					<p><a href="<?php echo $s_current_url."?page=updates" ?>">Post An Update</a></p>
				</div>
			</div>
		</div>
	</div>
</section>

<?php require_once '_includes/footer.php'; ?>

<script type="text/javascript">
	jQuery('.ccbtn.update_partner').click(function(event){
		event.preventDefault();

		var form_data = $(this).parentsUntil('form').parent().serialize();
		
		$.ajax( {
			type: "POST",
		    url: "ajax/update_partner.php",
		    data: form_data,
		    success: function( response ) {
		    	var resp_obj = JSON.parse( response );

				if(resp_obj.result == 'Success') {
					location.relaod();
				}
		    	
			}
		});
	
	});

	jQuery('.ccbtn.delete-message').click(function(event){

		var that = $(this);
		
		$.ajax( {
			type: "POST",
		    url: "ajax/update_partner.php",
		    data: { 'message_id' : $(this).data('message-id'), 'action' : 'messages_delete', 'funeral_home_id' : '<?php echo $i_funeral_home_id; ?>' },
		    success: function( response ) {

		    	that.parents('.dfrom').slideUp();
		    	that.parents('.form-mtcl').slideUp();
			}
		});
	});


	jQuery('#dashboard-tour').click(function(){
		partner_tour.restart();
	});

	<?php // @todo: Need content for bootstrap tour ?>
	var partner_tour = new Tour({
	  steps: [
	  {
	    element: "#dash-content",
	    title: "Bootstrap Tour",
	    content: "Need content and targets for this"
	  },{
	    element: "#dashboard",
	    title: "Bootstrap Tour",
	    content: "Need content and targets for this"
	  }
	]});
	partner_tour.init();


</script>