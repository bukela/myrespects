<?php 
use OpenCloud\LoadBalancer\Resource\LoadBalancer;

require_once '_includes/header.php';
require_once 'classes/campaign_base.php';

if ( !isset( $_GET['term'] ) || empty( $_GET['term'] ) ) {
	$_GET['term'] = '';
}

$o_cp = new campaign_base();

$i_number_of_results = $o_cp->get_search_results_count( $_GET['term'] );

unset( $o_cp );
?>
<!-- #Page title starts -->
<section class="page_title_areamain fix">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="page_title_areaall fix">
					<?php if ( !empty( $_GET['term'] ) && $i_number_of_results > 0 ) { ?>
						<div class="page_title_are fix">
								<h1>SEARCH RESULTS</h1>
						</div>
						<div class="page_subtitle_are fix">
							<p>Your search for “<?php echo isset( $_GET['term'] ) ? $_GET['term'] : ''; ?>” produced <?php echo $i_number_of_results; ?> results...</p>
						</div>
					<?php } elseif ( !empty( $_GET['term'] ) && $i_number_of_results <= 0 ) { ?>
						<div class="page_title_are fix">
								<h1>NO RESULTS FOUND</h1>
						</div>
						<div class="page_subtitle_are fix">
							<p>Try searching for a different zip code or name.</p>
						</div>
					<?php } else {  ?>
						<div class="page_title_are fix">
								<h1>ALL CAMPAIGNS</h1>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- #Page title End-->

<!-- #support-campaign starts -->
<div class="comomn_page_container search_page_content fix">
<section id="support-campaign"> 
	<div class="container">
		<div class="col-xs-12">
			<div id="search-results" class="row"> <!-- .row starts -->
				<!-- Filled with Ajax -->
			</div> <!-- .row ends -->
		</div>
	</div>
</section> 
</div>
<!-- #support-campaign ends -->

<div class="show_more_btnarea fix">
	<div class="show_more_btn fix">
		<a id="loadMore" class="show_btn" onclick="javascript:load_search_results();">Show More</a>
	</div>
</div>

<style type="text/css">
	.slider.slider-disabled .slider-track { cursor: auto; }
</style>

<script>

	var start_index = <?php echo isset( $_GET['start'] ) ? intval( $_GET['start'] ) : 0 ; ?>;
	var search_results = [];
    	
	function get_search_results() {
		//Dont fiddle with this function. 
		$.ajax({
			type: 'POST',
			url: '/ajax/get-search-results.php',
			data: { 'search_term': '<?php echo isset( $_GET['term'] ) ? $_GET['term'] : '' ; ?>', 'start': start_index },
			beforeSend:function(){},
			success:function( data ){

				data = JSON.parse( data );
	
				if ( data.result == true ) {
	
					search_results = search_results.concat( data.data );
					load_search_results();
					
				} else {
					
					document.getElementById('loadMore').remove();
					document.getElementById('search-results').innerHTML = data.message;
				}
			},	
			error:function(){
				document.getElementById('loadMore').remove();
				document.getElementById('search-results').innerHTML = data.message;
			}
		});

	}
	get_search_results();

    	
	function load_search_results(){

		var search_results_container = document.getElementById('search-results');

		if ( start_index % 20 == 0 && start_index == search_results.length ) {
			get_search_results();
			return;
		}

		for ( i_counter = start_index; i_counter < start_index + 4; i_counter++ ) {

			if ( i_counter + 1 >= <?php echo $i_number_of_results; ?> ) {
				document.getElementById('loadMore').innerHTML = 'No More Post';
			}
			if ( i_counter >= search_results.length ) {
				document.getElementById('loadMore').innerHTML = 'No More Post';
				break;
			}

			/*
				can change any of the element assignments here, have access to the following values in the array:
				id
				title
				image
				description
				goal
				raised
				formatted_goal
				formatted_raised
			*/
    			
			var campaign_html = '<div class="campaign bg-light col-sm-3 search_result_item">'
				+ '<div class="image">'
					+ '<img class="img-responsive" src="' + search_results[ i_counter ].image + '" alt="" />'
					<?php // @todo: This will be addressed in future versions. ?> 
					<?php // + '<span>Funeral Fund</span>' ?>
				+ '</div>'
				+ '<div class="textbox">'
					+ '<h4>' + search_results[ i_counter ].title + '</h4>'
					+ '<p>' + search_results[ i_counter ].description + '</p>'
				+ '</div>'
				+ '<div class="more text-center">'
					+ '<p><span id="ex' + search_results[ i_counter ].id + 'SliderVal">' + search_results[ i_counter ].formatted_raised + '</span> Raised <small>of ' + search_results[ i_counter ].formatted_goal + '</small></p>'
				+ '</div>'
				+ '<div class="rangeslider">'
					+ '<input id="ex' + search_results[ i_counter ].id + '" data-slider-id="ex' + search_results[ i_counter ].id + 'Slider" type="text" data-slider-min="0" data-slider-max="' + search_results[ i_counter ].goal + '" data-slider-step="50" data-slider-value="' + search_results[ i_counter ].raised + '" data-slider-enabled="false"/>'
				+ '</div>'
				+ '<div class="more text-center">'
					+ '<a href="/campaign.php?id=' + search_results[ i_counter ].id + '">+ VIEW CAMPAIGN</a>'
				+ '</div>'
			+ '</div>';

			search_results_container.innerHTML += campaign_html;

			$('#ex' + search_results[ i_counter ].id).slider({
				formatter: function(value) {
					return 'Current value: ' + value;
				}
			});

			
		}
		start_index += 4;
	}
</script>

<?php require_once '_includes/footer.php'; ?>