<?php 
/*
 * Placeholder UI so we can test functionality
 */

require_once '_includes/header.php';

require_once 'classes/wepay_base.php';



?>

<!-- #support-campaign starts -->
<section class="comomn_page_container search_page_content fix">
	
	<div class="start_campaign_stepone_area fix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php 
					 	$o_wepay = new wepay_base();
					 	
					 	/* from user record */
					 	$s_access_token = "STAGE_860b69785b933e89ca7f5c5dffc6002a805d50f89e41c2a653bfc7f7a933e65f";
					 	
					 	$i_account_id = "2041580157";
					 	
					 	$f_amount = '100';
					 	
					 	$s_description = "This is a test";
					 	
					 	$result = $o_wepay->create_preapproval($s_access_token, $i_account_id, $f_amount, $s_description);
					 	
					 	echo "<pre>" . print_r($result, true) . "</pre>";
					 	
					?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php 

require_once '_includes/footer.php';

?>