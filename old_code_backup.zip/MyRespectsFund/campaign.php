<?php 

require_once 'classes/campaign_base.php';

$o_cb = new campaign_base();
$i_campaign_id = intval( $_GET['id'] );
$a_campaign = $o_cb->get_campaign_details( $i_campaign_id );

if ( empty( $a_campaign ) ) {
	header( 'Location: /search-result.php' );
}

$s_current_url = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

$page = 'profile_page';
$additional_meta = '
	<meta property="og:url"           content="'.$s_current_url.'" />
	<meta property="og:type"          content="website" />
	<meta property="og:title"         content="My Respects" />
	<meta property="og:description"   content="Funeral Fundraising for '.$a_campaign['campaign_title'].'" />
	<meta property="og:image"         content="'.$a_campaign['main_campaign_image'].'" />';

require_once '_includes/header.php';

$a_donations = $o_cb->get_all_campaign_donations( $i_campaign_id );

$f_total_donation_amount = 0;
$s_donation_html = "";
$i_total_donations = count( $a_donations );

if ( $i_total_donations > 0 ) {
	foreach ( $a_donations as $a_donation ) {
		$f_total_donation_amount += $a_donation['amount'];
		$s_donation_name = ($a_donation['anonymous_flag'] == 1 ? "" : $a_donation['first_name'] . " " . $a_donation['last_name'] );
		$s_description = ($a_donation['anonymous_flag'] == 1 ? "" : $a_donation['description'] );
		
		$s_donation_html .= "
				<li style='display:none;'>
					<h4><b>$" . number_format( $a_donation['amount'] ) . "</b> " . $s_donation_name . "   (" . $a_donation['time_diff'] . ")</h4>
					<p>" . $s_description . "</p>
				</li>
				<li style='display:none;'><img class=\"img-responsive\" src=\"/assets/images/border_with_heart.png\" alt=\"\" /></li>";
	}
}

?>
<br class="clearboth">
<div id="fb-root"></div>
<section id="header_sticky">
	<div class="border_sticky_head fix">
		<img src="/assets/images/border_sticky_head.jpg" alt="" />
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="header_sticky_main_area fix">
					<div class="header_sticky_image fix">
						<img src="<?php echo $a_campaign['main_campaign_image']; ?>" alt="" />
					</div>
					<div class="header_sticky_fundrising fix">
						<div class="sticky_funeral fix">
							<div class="sticky_funeral_left fix">
								<img class="img-responsive" src="/assets/images/logo_funeral_mob.png" alt="" />
							</div>	
							<div class="sticky_funeral_right fix">
								<h3>Fundraising for <?php echo $a_campaign['campaign_title']; ?></h3>
								<h4> Goal: $<?php echo number_format( $a_campaign['campaign_goal'] ) ?> <span> <?php echo $a_campaign['time_left']; ?> DAYS LEFT</span></h4>
							</div>		
						</div>
					</div>
					<div class="header_sticky_social_givenow fix profile_stickygive_now_onput_prea">
						<div class="header_sticky_givenowith_input fix">
							<div class="sticky_give_now_input fix">
								<label for="">$</label>
								<input type="number" name="amount" placeholder="0.00" class="give_input_sticky" id="amount" onchange='fixit(this)' />
							</div>
							<div class="sticky_give_now_submit fix">
								<a href="donate.php?id=<?php echo ( $i_campaign_id ); ?>" class="sticky_give_nowsub"> Give Now</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> 

<section id="profile-heading">
	<div class="container">
		<div class="col-sm-7">
			<?php //@todo for future versions ?>
			<?php //<h6>Funeral Expenses</h6> ?>
			<h3>Fundraising for <?php echo $a_campaign['campaign_title']; ?></h3>
			<ul class="contactlist">
				<li><a href="#"><img src="/assets/images/icon_address_pointer.png" alt="" /> <?php echo $a_campaign['funeral_home_city'].", ".$a_campaign['funeral_home_state']; ?></a></li>
				<li><a href="#"><img src="/assets/images/icon_calender.png" alt="" /> Created: <?php echo date( 'F j, Y', strtotime( $a_campaign['start_date'] ) ); ?></a></li>
				<li><a href="#"><img src="/assets/images/icon_creator.png" alt="" /> Created: <?php echo $a_campaign['first_name']." ".$a_campaign['last_name']; ?></a></li>
			</ul>
		</div>
		<div class="col-sm-5">
			<ul class="social row">
				<li class="col-md-4"><a class="facebook" onclick="javascript: share_on_fb( '<?php echo $s_current_url; ?>' );"><img class="img-responsive" src="/assets/images/button_facebook.png" alt="" /></a></li>
				<li class="col-md-4">
					<a class="twitter-share-button" href="<?php echo $s_current_url; ?>" data-size="large">Tweet</a>
<!-- 					<a class="twitter" href="#"><img class="img-responsive" src="/assets/images/button_twitter.png" alt="" /></a> -->
				</li>
				<li class="col-md-4"><a class="edit" href="/campaign-dashboard.php">EDIT CAMPAIGN</a></li>
			</ul>
		</div>
	</div>
</section> <!-- #banner ends -->
<section id="profile-content"> <!-- #profile-content starts -->
	<div class="container">
		<div class="col-sm-7 flush">
			<div class="profile-image">
				<img class="img-responsive" src="<?php echo $a_campaign['main_campaign_image']; ?>" alt="" />
			</div>
			<div class="profile-info col-xs-12">
				<h3>The Life of <?php echo $a_campaign['campaign_title']; ?></h3>
				<p><?php echo $a_campaign['campaign_story']; ?></p>
				<?php if ( isset( $a_campaign['campaign_story_more'] ) && !empty( $a_campaign['campaign_story_more'] ) ) { ?>
					<div class="moredetails">
						<p><?php echo $a_campaign['campaign_story_more']; ?></p>
					</div>
					<a class="ReadMore" href="#">Read More</a>
				<?php } ?>
				<div class="row ">
					<?php 
						$a_gallery = $o_cb->get_campaign_gallery( $a_campaign['campaign_id'] );
						if ( !empty( $a_gallery ) && is_array( $a_gallery ) ) {
							foreach( $a_gallery as $i_image_id => $s_image ) {
	 						?>
								<div class="col-sm-4">
									<img class="img-responsive" src="<?php echo $s_image; ?>" alt="" />
								</div>
							<?php
							} 
						}				
					?>
				</div>
			</div>
			<div class="comments">
				<h2><img src="/assets/images/icon_comments.png" alt="" /> Campaign Comments</h2>
				<div class="fb-comments" data-width="100%" data-numposts="5"></div>
			</div>
		</div>
		<div class="sidebar col-sm-5">
			<div class="left-time col-xs-12">
				<div class="rangeslider">
					<input id="ex<?php echo $a_campaign['campaign_id']; ?>" data-slider-id='ex<?php echo $a_campaign['campaign_id']; ?>Slider' type="text" data-slider-min="0" data-slider-max="<?php echo $a_campaign['campaign_goal']; ?>" data-slider-step="1" data-slider-value="<?php echo ( $f_total_donation_amount );?>"/>
				</div>
				<script>
				$('#ex<?php echo $a_campaign['campaign_id']; ?>').slider({
					formatter: function(value) {
						return 'Current value: ' + value;
					}
				});
				</script>
				<h4><b>$<span id="ex<?php echo $a_campaign['campaign_id']; ?>SliderVal"><?php echo number_format( $f_total_donation_amount ); ?></span> Raised</b> of $<?php echo number_format( $a_campaign['campaign_goal'] ); ?> by <?php echo number_format( $i_total_donations ); ?> backer<?php echo ( $i_total_donations == 1 ? "" : "s" ); ?></h4>
				<h4><b><?php echo $a_campaign['time_left']; ?> DAYS left</b> for this campaign.</h4>
			</div>
			<div class="col-xs-12 text-center">
				<a class="givenow" href="donate.php?id=<?php echo ( $i_campaign_id ); ?>">GIVE NOW</a>
			</div>
			<div class="funeral-details col-xs-12">
				<div class="row">
					<div class="col-sm-3">
						<img class="img-responsive" src="/assets/images/logo_funeral.png" alt="" />
					</div>
					<div class="col-sm-7">
						<h3>Funeral Details</h3>
						<p><b>Funeral Location:</b> <?php echo $a_campaign['funeral_home_name']; ?>*</p>
						<p><b>Funeral Date:</b> <?php echo date( 'F d, Y', strtotime( $a_campaign['funeral_date'] ) ); ?>*</p>
						<?php // @todo this is never gathered. ?>
						<p><b>Funeral Time:</b> 9:00 pm EST*</p>
						<span><i>*Check campaign updates below.</i></span>
					</div>
					<div class="col-sm-2 flush">
						<span class="addtocalendar atc-style-blue">
							<a class="atcb-link"><img src="/assets/images/cal_btn.png" alt="" /></a>
					        <var class="atc_event">
					            <var class="atc_date_start"><?php echo date( 'F d, Y', strtotime( $a_campaign['funeral_date'] ) ); ?> 00:00:00</var>
					            <var class="atc_date_end"><?php echo date( 'F d, Y', strtotime( $a_campaign['funeral_date'] ) ); ?> 23:59:59</var>
					            <var class="atc_timezone">Europe/London</var>
					            <var class="atc_title">Funeral for <?php echo $a_campaign['campaign_title']; ?></var>
					            <var class="atc_description"><?php echo $a_campaign['campaign_story'].' '.$a_campaign['campaign_story_more']; ?></var>
					            <var class="atc_location"><?php echo $a_campaign['funeral_home_name']; ?></var>
					            <var class="atc_organizer">My Respects</var>
					            <var class="atc_organizer_email">info@myrespects.org</var>
					        </var>
					    </span>
    
    					<a class="map_btn" href="http://maps.google.com/?q=<?php echo urlencode( $a_campaign['funeral_home_address']. ', '.$a_campaign['funeral_home_city'].' '.$a_campaign['funeral_home_state'].''.$a_campaign['funeral_home_zip'] ); ?>" target="_blank"><img src="/assets/images/map_btn.png" alt="" /></a>
					</div>
				</div>
			</div>
			<div class="left-time col-xs-12">
				<h3><img src="/assets/images/icon_people_group.png" alt="" /> Current Supporters ( <?php echo $i_total_donations; ?> )</h3>
				<ul class="support">
					<?php echo ($s_donation_html); ?>
					<li><a class="more">SHOW MORE</a></li>
				</ul>
			</div>
			<div class="left-time updates col-xs-12">
				<h3><img src="/assets/images/icon_campain_updates.png" alt="" /> Campaign Updates</h3>
				<ul class="support">
					<?php 
						$a_updates = $o_cb->get_updates( $a_campaign['campaign_id'] ); 
						if ( !empty( $a_updates ) && is_array( $a_updates ) ) {
							foreach ( $a_updates as $a_update ) {
							?>							
								<li>
									<div class="col-sm-3 flush">
										<h5><?php echo strtoupper( date( 'M d', strtotime( $a_update['ts_created'] ) ) ); ?> <br/> <span><?php echo date('Y', strtotime( $a_update['ts_created'] ) ); ?></span></h5>
									</div>
									<div class="col-sm-9">
										<?php if ( !empty( $a_update['image_name'] ) ) { ?>
											<img src="<?php echo $a_update['image_name']; ?>" alt="">
										<?php } ?>
										<p><?php echo $a_update['message']; ?></p>
										<?php if ( !empty( $a_update['video'] ) ) { 
											echo stripslashes( $a_update['video'] );
										} ?>
									</div>
								</li>
								<li><img class="img-responsive" src="/assets/images/border_with_heart.png" alt="" /></li>
							<?php 
							}
						}
					?>
				</ul>
			
			
				<div class="get-updates">
					<h3><?php echo $a_campaign['campaign_title']; ?></h3>
					<h4><i>Get Funeral & Fundraiser Updates</i></h4>
					<div class="col-xs-10 col-xs-offset-1">
						<form>
							<input type="email" value="" />
							
							<div class="check_sumscrib fix">
								<div class="checkbox_wrapper fix">
									   <input type="checkbox" id="checkbox1" name="name">
									   <span class="checked"></span>
								</div>
								<label for="">Subscribe to MyRespects e-mails.</label>
							</div>
							<input type="submit" value="SIGN UP TODAY" />
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> <!-- #profile-content ends -->

<script>
i_counter = 10;

jQuery('.more').click(function(){
	show_more_supporters();
});

function show_more_supporters(){

	var i = 0;
	$('.support li').each(function(k,v){

		if ( i < i_counter ){
			$(v).show();
			i++;
		}
	});

	i_counter += 10;
	if ( i >= $('.support li').length ) {
		$('.more').remove();
	}
}
show_more_supporters();
					
</script>

<?php require_once '_includes/footer.php'; ?>
