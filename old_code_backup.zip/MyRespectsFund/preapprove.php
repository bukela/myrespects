<?php 
use OpenCloud\LoadBalancer\Resource\LoadBalancer;
/*
 * Placeholder UI so we can test functionality
 */

require_once '_includes/header.php';

?>


<section id="profile-content"> <!-- #profile-content starts -->
	<div class="container">
		<div class="col-sm-12 flush">
			<h1>test</h1>
			<?php
			require_once './vendor/autoload.php';
		
		    // application settings
		    $account_id = 820020673;
		    $client_id = "20082";
		    $client_secret = "457babadb5";
		    $access_token = "STAGE_c8fa74d09c6fd1d514dca9c6e514b79da828555ede2e650ff55061309133f61d";
		
		    // change to useProduction for live environments
		    WePay::useStaging($client_id, $client_secret);
		
		    $wepay = new WePay($access_token);
		
		    // create the pre-approval
		    $response = $wepay->request('preapproval/create', array(
		        'account_id'        => $account_id,
		        'period'            => 'once',
		        'amount'            => '19.99',
		        'mode'              => 'regular',
		        'short_description' => 'A pledge for the awesome project',
		        'redirect_uri'      => 'http://myrespects.org.com/success/'
		    ));
		
		    // display the response
		    print_r($response);
		?>
		</div>
	</div>
</section>

<?php 

require_once '_includes/footer.php';

?>