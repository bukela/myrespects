<?php
/**
 *
 * @author Adam F
 * @version 1.0
 * @desc Base class for all other classes
 */

abstract class abstract_base {
	
	function __construct() { }
	
	function __destruct() { }
	
	function get_protected_var( $s_var_name ) {
		return $this->$s_var_name;	
	}
	
	function set_protected_var( $s_var_name, $m_value ) {
		$this->$s_var_name = $m_value;
	}
	
} 

?>