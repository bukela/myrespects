<?php
/**
 *
 * @author Adam F
 * @version 1.0
 * @desc Base db connector
 * @todo 
 * 
 */

require_once 'abstract_base.php';

class db_base extends abstract_base {
	protected $s_db_host = "localhost";
	protected $s_db_user_name = "mrf_db_user";
	protected $s_db_password = "4br54CnCb7VJ92xev86K4w2RpNferm9S";
	protected $s_schema_name = "my_respects_fund";
	protected $s_debug;
	protected $s_last_sql;
	protected $i_last_insert_id;
	
	public $mysqli;
	
	public function __construct() {
		/* local/test/prod connect logic */
	}
	
	public function __destruct() { }
	
	/**
	 * @desc creates a connection to a MySQL database using mysqli connection 
	 * 
	 * @param none
	 * @return boolean TRUE connections was successful, FALSE if connection failed for any reason
	 */
	public function connect() {
		$this->mysqli = @new mysqli($this->s_db_host, $this->s_db_user_name, $this->s_db_password, $this->s_schema_name);
		
		if ($this->mysqli->connect_errno) {
			$this->s_debug = $this->mysqli->connect_error;
			return false;	
		} else {
			return true;
		}
	}
	
	/**
	 * @desc will execute a provided SQL string against the database. This function does not do any sanitzing.
	 *
	 * @param string $s_sql the SQL to execute
	 * @return mixed Upon success it will either be a mysqli results object, boolean true, or boolean false
	 * 
	 * @todo (optional) create similar function that returns an associative array. This creates a little more overhead but may be useful in some instances? 
	 */
	public function query( $s_sql ) {
		if( $this->connect() ) {
			$o_result = $this->mysqli->query( $s_sql );
			$this->s_last_sql = $s_sql;
			
			if( $o_result ) {
				if( is_object( $o_result ) ) {					
					$m_return_results = $o_result;
				} else {
					if( strpos( $s_sql, "INSERT INTO" ) == 0 ) {
						$this->i_last_insert_id = $this->mysqli->insert_id;
					}
					
					$m_return_results = true;
				}
			} else {
				$m_return_results = false;
			}
			
			$this->mysqli->close();
			
			return $m_return_results;
		} 
		return false;
	}
	
	/**
	 * @desc will call a stored procedure using a given set of parameters. 
	 *
	 * @param string $s_stored_proc the stored procedure to call
	 * @param mixed $,_params list of parameters to be called (in order). Params will be sanitized. 
	 * 			Can also provide the list of params in string format: 'val1','val2'
	 * @return mixed Upon success it will either be a mysqli results object, boolean true, or boolean false
	 *
	 * @todo (optional) create similar function that returns an associative array. This creates a little more overhead but may be useful in some instances?
	 */
	public function call( $s_stored_proc, $m_params ) {
		/* array of params should be parsed and sanitized */		
		if( is_array( $m_params ) ) {
			$s_param_list = "";
			foreach ( $m_params as $s_param ) {
				$s_param_list .= ( $s_param_list != "" ? "," : "" ) . "'" . $this->sanitize( $s_param ) . "'";
			}
		} else {
			$s_param_list = $m_params;
		}

		$o_return_val = $this->query("CALL `" . $this->s_schema_name . "`.`" . addslashes( $s_stored_proc ) . "`(" . $s_param_list .")");
		
		return $o_return_val;
	}
	
	/**
	 * @desc generic sanitization function to prepare data for db.
	 * 
	 * @param unknown $data data to sanititze
	 * @return string sanitized data
	 */
	public function sanitize( $data ) {
		return addslashes( $data );
	}	
	
	/**
	 * @desc log to general log table
	 * @param array $a_params assoc array of params to log 
	 * @return mixed
	 */
	public function log_it( $a_params ) {
		$a_param = array(
				$a_params['user_id'],
				$a_params['campaign_id'],
				$a_params['funeral_home_id'],
				$a_params['log_type'],
				$a_params['log_event']
		);
		
		return $this->call( "general_log_insert", $a_param );
	}
}