<?php

/**
 *
 * @version 1.0
 * @desc class to handle sending/viewing messages
 *
 */

require_once 'db_base.php';

class message_base extends db_base {


	public function send_message( $a_message ){
		
		
		$o_results = $this->call( 'send_message', "'".addslashes($a_message['message'])."','".intval($a_message['campaign_id'])."','".addslashes($a_message['to_user'])."','".addslashes($a_message['from_user'])."'" );
		
		return $o_results;
	}
	
	public function get_sent_messages_partner( $user_id ) {
	
		$a_return = array(
				'result'	=> false,
				'debug'		=> "Failed to find any messages.",
				'message'	=> "We're sorry, but we could not find any messages to match your search critera."
		);
	
		$o_results = $this->call( 'get_sent_messages_partner', "'$user_id'" );
	
		if ( $o_results->num_rows > 0 ) {
	
			unset( $a_return['debug'] );
			unset( $a_return['message'] );
	
			$a_return['result'] = true;
	
			while ( $a_row = $o_results->fetch_assoc() ) {
	
				$a_return['data'][] = $a_row;
			}
	
			$a_return['count'] = count( $a_return['data'] );
		}
	
		return $a_return;
	}
	
	public function get_all_messages_to_partner( $i_funeral_home_id, $user_id ) {
		
		$a_return = array(
				'result'	=> false,
				'debug'		=> "Failed to find any messages.",
				'message'	=> "We're sorry, but we could not find any messages to match your search critera."
		);
		
		$o_results = $this->call( 'get_all_messages_to_partner', "'$user_id'" );
		
		if ( $o_results->num_rows > 0 ) {
		
			unset( $a_return['debug'] );
			unset( $a_return['message'] );
		
			$a_return['result'] = true;
		
			while ( $a_row = $o_results->fetch_assoc() ) {
		
				$a_return['data'][] = $a_row;
			}
				
			$a_return['count'] = count( $a_return['data'] );
		}
		
		return $a_return;
	}
	
	public function get_all_messages( $i_campaign_id, $user_id ){

		$a_return = array(
				'result'	=> false,
				'debug'		=> "Failed to find any messages.",
				'message'	=> "We're sorry, but we could not find any messages to match your search critera."
		);
		
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return $a_return;
		}
		
		$o_results = $this->call( 'get_all_messages', "'$i_campaign_id','$user_id'" );
		
		if ( $o_results->num_rows > 0 ) {
		
			unset( $a_return['debug'] );
			unset( $a_return['message'] );
		
			$a_return['result'] = true;
		
			while ( $a_row = $o_results->fetch_assoc() ) {
		
				$a_return['data'][] = $a_row;
			}
			
			$a_return['count'] = count( $a_return['data'] );
		}
		
		return $a_return;
	}
	
	public function delete_message( $i_message_id ) {
		
		$o_results = $this->call( 'delete_message_by_id', "'$i_message_id'" );
		
		return $o_results;
	}
	
	public function reply_message( $a_data ){
		
		$o_results = $this->call( 'reply_to_message', "'".intval( $a_data['user_id'] )."','".intval( $a_data['from_user'] )."','".intval( $a_data['campaign_id'] )."','".intval( $a_data['message_id'] )."','".addslashes( $a_data['message-text'] )."'" );

		return $o_results;
	}
	
}