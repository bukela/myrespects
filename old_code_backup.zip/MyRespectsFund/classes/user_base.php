<?php

/**
 * 
 * @version 1.0
 * @desc class to handle all user validation/creation/retrieval of information 
 *
 */

require_once 'abstract_base.php';
require_once 'wepay_base.php';
require_once 'db_base.php';

class user_base extends abstract_base {
	
	/**
	 * @var string $s_google_client_id this will be from our google api access. This will be the only place this exists
	 */
	private $s_google_client_id = '40989211664-2lg8e805sqer9lu7op17stlo6e4mttn4.apps.googleusercontent.com';
	
	/**
	 * 
	 * @var array $_a_original_data - Will hold all the original data of the user incase something needs to be updated 
	 */
	private $_a_original_data;
	
	/**
	 * 
	 * @var int $i_user_id ID of the current user
	 */
	private $i_user_id;
	
	/**
	 * @var string $s_email Will hold the users email once we know it and they are logged in
	 */
	private $s_email;

	/**
	 * @var string $s_first_name Will hold the users first name once we know it and they are logged in
	 */
	private $s_first_name;
	
	/**
	 * @var string $s_last_name Will hold the users last name once we know it and they are logged in
	 */
	private $s_last_name;
	
	/**
	 * @var string $s_profile_picture Will hold the users profile picture url once we know it and they are logged in
	 */
	private $s_profile_picture;
	
	/**
	 * @var array $a_default_login_values the *ONLY* accepted inputs from the login form
	 */
	private $a_default_login_values = array( 'login_nonce', 'last_name', 'first_name', 'user-email', 'email', 'user-password', 'google-token', 'g-recaptcha-response', 'facebook-token', 'phone_number', 'address', 'city', 'state', 'zip', 'dob' );
	
	/**
	 * @var boolean $b_is_logged_in Weither or not the user is logged in
	 */
	private $b_is_logged_in = FALSE;
	
	/**
	 * @desc create new user object
	 *
	 */
	public function __construct( ) {
		
		$this->o_db = new db_base();
	}
	
	/**
	 * @desc Will return the users ID
	 *
	 * @return int user's id
	 */
	public function get_id() {
		return $this->i_user_id; 
	}
	
	/**
	 * @desc Will return the users first name and last name joined
	 * 
	 * @return string users first and last name if available 
	 */
	public function get_full_name() {
		return $this->s_first_name." ".$this->s_last_name;
	}
	
	/**
	 * @desc Will give users first name
	 * 
	 * @return string users first name if available
	 */
	public function get_first_name() {
		return $this->s_first_name;
	}
	
	/**
	 * @desc Will give users last name
	 * 
	 * @return string users first and last name if available
	 */
	public function get_last_name() {
		return $this->s_last_name;
	}
	
	/**
	 * @desc Will give the users email address
	 * 
	 * @return string users email address
	 */
	public function get_email() {
		return $this->s_email;
	}

	/**
	 * @desc will give URL to users profile picture
	 * 
	 * @return string URL of users profile picture
	 */
	public function get_profile_picture() {
		return $this->s_profile_picture;
	}
	
	// @todo implement these
	public function get_phone_number() {
		return $this->s_phone_number;
	}
	
	public function get_address() {
		return $this->s_address;
	}
	
	public function get_city() {
		return $this->s_city;
	}
	
	public function get_state() {
		return $this->s_state;
	}
	
	public function get_zip() {
		return $this->s_zip;
	}
	
	public function get_dob() {
		return $this->s_dob;
	}
	
	/**
	 * @desc Will return the current login status of the user
	 * 
	 * @return boolean true/false if user is loged in/out
	 */
	public function is_logged_in() {
		return $this->b_is_logged_in;
	}
	
	/**
	 * @desc Will check if the user is admin. This would give them premissions to log
	 * 			into the admin portal to view stats, CMS, dashboard, etc.
	 * 
	 * @return boolean true/false if user is admin
	 */
	public function is_admin() {
		
		$a_result = $this->o_db->call( 'check_user_is_admin', "'".$this->i_user_id."'" );
		
		$a_result = $a_result->fetch_row();
		
		if ( $a_result[0] == '0' ) {
				
			return FALSE;
		}
		
		return TRUE;
	}
	
	/**
	 * @desc Will filter out and unknown login form fields
	 * 			Note: This will filter against the a_default_login_values class array
	 * 
	 * @param string $s_data_key form field name to filter 
	 * 
	 * @return array array of filtered fields
	 */
	protected function filter_login_data( $s_data_key ) {

		return in_array( $s_data_key, $this->a_default_login_values );
	}
	
	/**
	 * @desc Will determin the login method used
	 * 
	 * @param array $a_unsanitized_data array of all the login form fields
	 * @return string google|facebook|normal depending on the method used. Normal denotes an email and password were used.
	 */
	protected function get_login_type( $a_unsanitized_data ) {
		
		if ( isset( $a_unsanitized_data['google-token'] ) && !empty( $a_unsanitized_data['google-token'] ) ) {

			return 'google';
		
		} elseif ( isset( $a_unsanitized_data['facebook-token'] ) && !empty( $a_unsanitized_data['facebook-token'] ) ) {
			
			return 'facebook';
					
		} else {
			
			return 'normal';
		}
	}
	
	/**
	 * @desc Will check if the email address already exists in the database
	 * 
	 * @return boolean true|false depending on if the email exists
	 */
	protected function check_user_exists() {
		
		$a_result = $this->o_db->call( 'check_user_exists', "'".$this->s_email."'" );
		
		if( $a_result ) {
			$a_result = $a_result->fetch_row();
			
			if ( $a_result[0] == '0' ) {
				
				return FALSE;
			}
		} else {
			return FALSE;
		}
			
		return TRUE;
	}
	
	/**
	 * @desc Will handle all aspects of the login process. Will filter data, validate data, check if user exists, create user if there is none
	 * 
	 * @param array $a_raw_data the raw login form data
	 * @return boolean true|false depending on if a valid login request was made
	 */
	public function login( $a_raw_data ) {
		
		$a_unsanitized_data = $a_raw_data;
		$a_unsanitized_data = array_filter( $a_raw_data, array( $this, 'filter_login_data' ), ARRAY_FILTER_USE_KEY );
		
		if ( $this->check_recaptcha( $a_unsanitized_data ) === FALSE ) {
			$this->b_is_logged_in = FALSE;
			return FALSE; 
		}
		
		$s_login_type = $this->get_login_type( $a_unsanitized_data );

		if ( $s_login_type == 'google' ) {

			// check the integraty of the google login.
			$b_valid = $this->verify_google_login( $a_unsanitized_data['google-token'] );
			if ( $b_valid === FALSE ) {
				return FALSE;
			}
			$this->b_is_logged_in = TRUE;
			
			// check if the user exists in our system now that we know the email is good otherwise create user
			if ( $this->check_user_exists() === FALSE ) {
				$this->create_user( $s_login_type );
			}
			
		} elseif ( $s_login_type == 'facebook' ) {
			
			// check the integraty of the facebook login.
			$b_valid = $this->verify_facebook_login( $a_unsanitized_data['facebook-token'] );
			if ( $b_valid === FALSE ) {
				return FALSE;
			}
			$this->b_is_logged_in = TRUE;
			
			// check if the user exists in our system now that we know the email is good otherwise create user
			if ( $this->check_user_exists() === FALSE ) {
				$this->create_user( $s_login_type );
			}
			
		} elseif ( $s_login_type == 'normal' ) {
			$this->s_email = addslashes( isset( $_POST['user-email'] ) ? $_POST['user-email'] : '' );
			$this->s_password = addslashes( isset( $_POST['user-password'] ) ? md5( $_POST['user-password'] ) : '' );
			$this->s_first_name = addslashes( isset( $_POST['first_name'] ) ? $_POST['first_name'] : '' );
			$this->s_last_name = addslashes( isset( $_POST['last_name'] ) ? $_POST['last_name'] : '' );
			
			// check if the user exists first, this is different than google and facebook because the user provided 
			// the email so we have nothing to double check against a 3rd party system
			if ( $this->check_user_exists() === FALSE ) {
				$this->create_user( $s_login_type );
			}

			$b_valid = $this->verify_normal_login( $a_unsanitized_data );
			if ( $b_valid === FALSE ) {
				return FALSE;
			}
			$this->b_is_logged_in = TRUE;
		}

		// @todo do we want to change this to a whole login_log table/function?
		// good to keep track of the last time a user logged in
		$this->o_db->call( 'update_last_login', "'".$this->s_email."'" );
		
		$this->retrieve_user_info();

		return $this->b_is_logged_in;
	}
	
	
	/**
	 * @desc Will verify google reCatpcha 2.0 against Google
	 * 
	 * @param array $a_unsanitized_data filterd post data
	 * @return boolean
	 */
	protected function check_recaptcha( $a_unsanitized_data ) {
		
		$a_data = array(
			'secret'	=> '6LfVPikUAAAAAAAzn4lebxbQ3MeMtvyhgzU53lYm',
			'response'	=> $a_unsanitized_data['g-recaptcha-response'],
			'remoteip'	=> $_SERVER['REMOTE_ADDR']
		);
		
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify" );
		curl_setopt( $ch, CURLOPT_HEADER, 0 );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt( $ch, CURLOPT_POST, 1 );
		curl_setopt( $ch, CURLOPT_POSTFIELDS,$a_data );
		
		$o_response = json_decode( curl_exec( $ch ) );
		curl_close( $ch );
		
		if ( $o_response->success === TRUE ) {
			return TRUE;
		} else {
			return FALSE;
		}
		
		return FALSE;
	}
	
	protected function retrieve_user_info() {

		$o_result = $this->o_db->call( 'get_user_info', "'".$this->s_email."'" );

		if ( $o_result->num_rows > 0 ) {
		
			$a_row = $o_result->fetch_assoc();
			
			$this->i_user_id = $a_row['user_id'];
			$this->s_email = $a_row['email'];
			$this->s_first_name = $a_row['first_name'];
			$this->s_last_name = $a_row['last_name'];
			$this->s_profile_picture = $a_row['picture'];
			$this->s_phone_number = $a_row['phone_number'];
			$this->s_address = $a_row['address'];
			$this->s_city = $a_row['city'];
			$this->s_state = $a_row['state'];
			$this->s_zip = $a_row['zip'];
			$this->s_dob = $a_row['dob'];
			
			$this->_a_original_data = array(
				'_email' 		=> $a_row['email'],
				'_first_name'	=> $a_row['first_name'],
				'_last_name'	=> $a_row['last_name'],
				'_picture'		=> $a_row['picture'],
				'_phone_number'	=> $a_row['phone_number'],
				'_address'		=> $a_row['address'],
				'_city'			=> $a_row['city'],
				'_state'		=> $a_row['state'],
				'_zip'			=> $a_row['zip'],
				'_dob'			=> $a_row['dob'],
			);
		}
		return;
	}
	
	/**
	 * @desc Will create a new user based off of the CLASS VARIABLES
	 * 
	 * @param string $s_created_by what the user used to log in NOTE: this should be the return of the get_login_type function 
	 * @todo should this return something?
	 */
	protected function create_user( $s_created_by ) {
		
		$a_default = array(
			'first_name'	=> '',
			'last_name'		=> '',
			'email'			=> '',
			'password'		=> '',
			'picture'		=> '',
			'picture_from'	=> '',
			'created_by'	=> '',				
		);

		$s_first_name = !empty( $this->s_first_name ) ? $this->s_first_name : '';
		$s_last_name = !empty( $this->s_last_name ) ? $this->s_last_name : '';
		$s_email = !empty( $this->s_email ) ? $this->s_email : '';
		$s_password = !empty( $this->s_password ) ? $this->s_password : '';
		$s_picture = !empty( $this->s_profile_picture ) ? $this->s_profile_picture : '';
		
		$this->o_db->call( 'create_user', "'$s_first_name','$s_last_name','$s_email','$s_password','$s_picture','$s_created_by','$s_created_by'" );
		
		//@todo error check the above
		
		$o_wepay = new wepay_base();
		
		$o_response = $o_wepay->create_wepay_user( $s_first_name, $s_last_name, $s_email );

		if( $o_response === false ) {
			//should be a little more user friendly here...
			return false;
		}
		
		$this->o_db->call( 'user_update_wepay_by_email', "'$s_email','$o_response->user_id','$o_response->access_token','$o_response->token_type','$o_response->expires_in'");
		
		//$o_wepay->send_wepay_confirmation( $o_response->access_token );
	}
	
	/**
	 * @desc Will verify if the email + password are valid
	 * 
	 * @param array $a_unsanitized_data array of filtered login form data
	 * @return boolean true|false depending on if the email + password are valid in our system
	 */
	protected function verify_normal_login( $a_unsanitized_data ) {
		
		$s_password = md5( $a_unsanitized_data['user-password'] );
		
		$a_result = $this->o_db->call( 'check_user_password', "'".$a_unsanitized_data['user-email']."', '$s_password'" );
		
		if ( $a_result->num_rows == 1 ) {
			
			$a_result = $a_result->fetch_assoc();

			if ( !isset( $a_result[0] ) ) {
				$this->s_first_name = $a_result['first_name'];
				$this->s_last_name = $a_result['last_name'];
				$this->s_email = $a_result['email'];
				$this->s_profile_picture = $a_result['picture'];
		 
				$this->s_password = $s_password;
				
				return TRUE;
			}
		}
		
		return FALSE;
	}
	
	/**
	 * @desc Verify if the facebook access token is valid and get user information
	 * 
	 * @param string $s_access_token access token returned from facebook login ( authResponse.accessToken )
	 * @return boolean true|false depending on if this is a valid facebook user that has access to our system
	 */
	protected function verify_facebook_login( $s_access_token ) {
		
		// this call will give us the facebook users first name, last name, email and profile picture.
		// the access token is the token we should have received from the facebook login.
		$a_facebook_response = json_decode( file_get_contents( "https://graph.facebook.com/v2.8/me?fields=first_name%2Clast_name%2Cemail%2Cpicture&access_token=".$s_access_token ), true );

		// if the access token was invalid or the user didnt give us access to their profile this call will return an error array
		if ( isset( $a_facebook_response['error'] ) ) {
			return FALSE;
		}

		$this->s_email = $a_facebook_response['email'];
		$this->s_first_name = $a_facebook_response['first_name'];
		$this->s_last_name = $a_facebook_response['last_name'];
		$this->s_profile_picture = $a_facebook_response['picture']['data']['url'];
		
		return TRUE;
	}
	
	/**
	 * @desc Verify if the google user is logged in, if the google token is valid and get user information
	 * 
	 * @param string $s_google_token google access token returned from the google login ( googleUser.getAuthResponse().id_token )
	 * @return boolean true|false depending on if this is a valid google user that has access to our system
	 */
	protected function verify_google_login( $s_google_token ) {
		
		$a_google_response = json_decode( file_get_contents( "https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=$s_google_token" ), true );
		$a_google_keys = json_decode( file_get_contents( "https://www.googleapis.com/oauth2/v3/certs" ), true );
		
		if ( !is_array( $a_google_keys ) ) {
			return FALSE;
		}
		
		$b_valid_signatures = FALSE;
		foreach ( $a_google_keys['keys'] as $a_signatures ) {
			// we have to verify that the token validation we recieved with from google and not intercepted anywhere along the line
			if ( $a_signatures['alg'] != $a_google_response['alg'] || $a_signatures['kid'] != $a_google_response['kid'] ) {
				continue;
			}
			$b_valid_signatures = TRUE;
		}
		if ( $b_valid_signatures === FALSE ) {
			return FALSE;
		}

		// make sure we didnt get passed an expired google token. This could happen if someone was doing malicious things
		if ( $a_google_response['exp'] <= time() ) {
			return FALSE;
		}
		
		// double check that this access token really is for our app.
		if ( $a_google_response['aud'] != $this->s_google_client_id ) {
			return FALSE;
		}
		
		$this->s_email = $a_google_response['email']; 
		$this->s_first_name = $a_google_response['given_name'];
		$this->s_last_name = $a_google_response['family_name'];
		$this->s_profile_picture = $a_google_response['picture'];
		
		return TRUE;
	}
	
	private function update_user_db( $a_data ) {
		$a_result = $this->o_db->call( 'update_user_info', "'{$this->get_id()}', '{$a_data['first_name']}', '{$a_data['last_name']}', '{$a_data['email']}',
															'{$a_data['address']}', '{$a_data['city']}', '{$a_data['state']}',
															'{$a_data['zip']}', '".preg_replace('/\D/', '', $a_data['phone_number'])."', '".date('Y-m-d', strtotime( $a_data['dob'] ) )."'" );
		
		$this->retrieve_user_info();
	}
	
	private function _remove_leading_underscore( $value ) {
		return ltrim( $value, "_" );
	}
	
	public function update_user( $a_raw_data, $b_force_update = FALSE, $i_user_id = NULL ) {

		if ( !is_null( $i_user_id ) ) {
			$this->i_user_id = $i_user_id;
		}
		
		if ( $b_force_update === FALSE ) {
			$s_updated = FALSE;
			
			$a_data_keys = array_map( array( $this, "_remove_leading_underscore" ), array_keys( $this->_a_original_data ) ); 
	
			foreach ( $a_raw_data as $s_key => $s_value ) {
				if ( in_array( $s_key, $a_data_keys ) ) {
					if ( ( !isset( $this->_a_original_data[ "_$s_key" ] ) || $s_value != $this->_a_original_data[ "_$s_key" ] ) && !empty( $s_value ) && $s_value != '' )  {
						$s_updated = TRUE;
						break;
					}
				}
			}
		} else {
			$s_updated = TRUE;
		}
		
		if ( $s_updated === TRUE ) {
			
			$a_unsanitized_data = $a_raw_data;
			$a_unsanitized_data = array_filter( $a_raw_data, array( $this, 'filter_login_data' ), ARRAY_FILTER_USE_KEY );
			
			$this->update_user_db( $a_unsanitized_data );
		}
	}
	
	public function refresh_data(){
		$this->retrieve_user_info();
	}
	
	public function get_user_campaign() {
		
		
		$a_result = $this->o_db->call( 'get_user_campaign', "'{$this->i_user_id}'" );
		
		if ( $a_result->num_rows == 1 ) {
				
			$a_result = $a_result->fetch_assoc();

			if ( !isset( $a_result[0] ) ) {
				return $a_result['campaign_id'];
			}
		}
		return FALSE;
	}
	
	/**
	 * @desc Will generate a random password string of length $password_length
	 * 
	 * @param int $password_length number 1 - 255 
	 * @return 'random' string of length $password_length
	 */
	private function randomPassword( $password_length ) {
		
		if ( !is_numeric( $password_length ) || $password_length < 0 || $password_length > 255 ) {
			return FALSE;
		}
		
		$s_alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$a_pass = array ();
		$i_alphaLength = strlen( $s_alphabet ) - 1;
		for ( $i = 0; $i < $password_length; $i ++ ){
			$n = rand( 0, $i_alphaLength );
			$a_pass[] = $s_alphabet[$n];
		}
		return implode ( $a_pass ); // turn the array into a string
	}

	public function reset_password( $a_raw_data ) {
		
		if ( !is_array( $a_raw_data ) ) {
			return FALSE;
		}
		
		$a_unsanitized_data = $a_raw_data;
		$a_unsanitized_data = array_filter( $a_raw_data, array( $this, 'filter_login_data' ), ARRAY_FILTER_USE_KEY );
		
		if ( empty( $a_unsanitized_data ) || !is_array( $a_unsanitized_data ) ) {
			return FALSE;
		}
		
		if ( !isset( $a_unsanitized_data['user-email'] ) ) {
			return FALSE;
		}
		
		$this->s_email = $a_unsanitized_data['user-email'];
		
		if ( $this->check_user_exists() === FALSE ) {
			return FALSE;
		}
		
		$s_new_password = $this->randomPassword( 32 );
		if ( $s_new_password === FALSE ) {
			return FALSE;	
		}

		$a_result = $this->o_db->call( 'reset_password', "'{$this->s_email}','$s_new_password'" );
		if ( $a_result->num_rows == 1 ) {
			$a_result = $a_result->fetch_assoc();
			if ( $a_result['ROW_COUNT()'] != '1' ) {
				return FALSE;
			}
		}

		include_once '../classes/email_base.php';
		$o_email = new email_base();
		
		$s_html = "Password reset for MyRespects.<br>Password: {$s_new_password}. <br> If you did not request this please contact us at info@myrespects.org";
		$s_raw_text = " Password reset for MyRespects. \r\n Password: {$s_new_password}. \r\n If you did not request this please contact us at info@myrespects.org";
		
		$o_email->send_email( $this->s_email, "Password Reset", $s_html, $s_raw_text );
		
		return true;
	}
	
	function get_session_string() {
		return base64_encode( session_encode() );
	}
	
	function decode_session_string( $s_session ) {
		return session_decode(base64_decode($s_session));
	}

}