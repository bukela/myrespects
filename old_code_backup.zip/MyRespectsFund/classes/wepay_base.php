<?php

use OpenCloud\Common\Exceptions\ObjectCopyError;
/**
 *
 * @author Adam F
 * @version 1.0
 * @desc class to handle all integrations with we pay API
 * @todo this class should really extend WePay
 */

require_once 'abstract_base.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once 'db_base.php';

class wepay_base extends abstract_base {
	private $i_client_id = "20082";
	private $s_client_secret = "457babadb5";
	
	public function __construct() {
		if( 1 > 2 ) { //put some good logic here to determine if we are on production
			WePay::useProduction( $this->i_client_id, $this->s_client_secret );
		} else {
			$this->i_client_id = "114086";
			$this->s_client_secret = "5b73d15f1e";
			WePay::useStaging( $this->i_client_id, $this->s_client_secret );
		}
	}
	
	public function __destruct() { }
	
	/**
	 * @desc this creates the actual user for wepay. This should be called when we create the user account.
	 * 
	 * @param string $s_first_name
	 * @param string $s_last_name
	 * @param string $s_email
	 * @return boolean|StdClass if we failed return false. If not reture success Object:
	 * 		[user_id] [access_token] [token_type] [expires_in]
	 */
	public function create_wepay_user( $s_first_name, $s_last_name, $s_email ) {
		try {
			$o_wepay = new WePay(null);
		
			// register new merchant
			$o_response = $o_wepay->request('user/register/', array(
					'client_id'        		=> $this->i_client_id,
					'client_secret'    		=> $this->s_client_secret,
					'email'            		=> $s_email,
					'scope'            		=> 'collect_payments,view_user,preapprove_payments,manage_accounts',
					'first_name'       		=> $s_first_name,
					'last_name'        		=> $s_last_name,
					'original_ip'      		=> $_SERVER['REMOTE_ADDR'],
					'original_device'  		=> $_SERVER['HTTP_USER_AGENT'],
					'tos_acceptance_time'	=> time()
			));
		} catch (WePayException $e) {
			//@todo log this and warn
			echo $e->getMessage();
			return false;
		}
		return $o_response;
	}
	
	/**
	 * @desc sends a confirmation email to the new user through wepay api
	 * @param string $s_access_token access token of user
	 * 
	 * @return boolean|StdClass if we failed return false. If not reture success Object:
	 * 		[user_id] [first_name] [last_name] [email] [state]
	 */

	public function send_wepay_confirmation( $s_access_token ) {
		try {
			$o_wepay = new WePay( $s_access_token );
		
			// send confirmation
			$a_response = $o_wepay->request('user/send_confirmation/', array());
		} catch ( WePayException $e ) {
			//@todo log this and warn
			echo $e->getMessage();
			return false;
		}
		
		return $o_response;
	}
	
	/**
	 * @desc creates a merchant account through wepay. This should be called when creating a campaign.
	 * 
	 * @param string $s_access_token
	 * @param string $s_name - name of the campaign (title)
	 * @param unknown $s_desc - desc of the campaing (story)
	 */
	public function create_wepay_account( $s_access_token, $s_name, $s_desc ) {
		try {
			$o_wepay = new WePay( $s_access_token );
				
			// create an account for a user
			$o_response = $o_wepay->request('account/create/', array(
					'name'         => $s_name,
					'description'  => $s_desc
			));
		} catch ( WePayException $e ) {
			//@todo log this and warn
			echo $e->getMessage();
			return false;
		}
	
		return $o_response;
	}
	
	public function create_preapproval( $s_access_token, $i_account_id, $f_amount, $s_description, $i_campaign_id, $s_donation_hash ) {
		try {
			$wepay = new WePay($s_access_token);
			
			// create the pre-approval
			$o_response = $wepay->request('preapproval/create', array(
					'account_id'        => $i_account_id,
					'period'            => 'once',
					'app_fee'			=> '4', //4% app fee to go to MyRespects
					'amount'            => $f_amount,
					'mode'              => 'regular',
					'short_description' => 'A pledge for the awesome project',
					'redirect_uri'      => 'http://www.myrespects.org/thankyou.php?cid=' . $i_campaign_id . '&dh=' . $s_donation_hash
			));
		} catch ( WePayException $e ) {
			//@todo log this and warn
			echo $e->getMessage();
			return false;
		}
		
		return $o_response;
	}
	
	public function withdraw_funds( $i_campaign_id ) {
		$o_db = new db_base();
		
		$o_result = $o_db->query( "SELECT c.wepay_account_id, u.wepay_access_token FROM campaign c JOIN user u ON c.user_id = u.user_id WHERE c.campaign_id = '" . intval( $i_campaign_id ) . "'" );
		
		if ( intval( $o_result->num_rows ) == 0 ) {
			return false;
		}
		
		$a_result_info = mysqli_fetch_assoc( $o_result );
		
		$s_access_token = $a_result_info['wepay_access_token'];
		$i_account_id = $a_result_info['wepay_account_id'];
		
		$o_donation_results = $o_db->query( "SELECT * FROM donation WHERE complete_flag = 1 AND campaign_id = '" . intval( $i_campaign_id ) . "' LIMIT 1" );
		
		if( intval( $o_donation_results->num_rows ) < 1 ) {
			return false;
		}
		
		$a_donations = mysqli_fetch_assoc( $o_donation_results );
		
		if( is_array( $a_donations ) && count( $a_donations ) > 0 ) {
			foreach ( $a_donations as $a_donation ) {
				$o_checkout = $this->checkout_create($s_access_token, $i_account_id, $a_donation['amount'], $a_donation['description'] );
			}
		} else {
			return false;
		}
		
	}
	
	public function checkout_create( $s_access_token, $i_account_id, $i_preapproval_id, $f_amount, $s_description ) {
		$wepay = new WePay( $s_access_token );
		
		$o_db = new db_base();
		
		// create the checkout
		$o_response = $wepay->request('checkout/create', array(
				'account_id'        => $i_account_id,
				'amount'            => $f_amount,
				'currency'          => 'USD',
				'short_description' => $s_description,
				'type'              => 'donation',
				'payment_method'    =>  array(
					'type'          =>  'preapproval',
					'preapproval'   =>  array(
						'id'        => $i_preapproval_id
					)
				)
		));
		
		return $o_response;
	}	
} 



?>