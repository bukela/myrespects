<?php
/**
 *
 * @author Adam F
 * @version 1.0
 * @desc class to handle everything that has to do with location... getting zip code, distance comparison, searching?, etc
 *
 */

require_once 'abstract_base.php';
require_once 'db_base.php';

class location_base extends abstract_base {
	
	/**
	 * 
	 * @var string API of service to get zip code based on IP
	 */
	private $s_search_url = "http://api.ipinfodb.com/v3/ip-city/?key=b51fc350b41228f16ae16a543109582b737404285c0aa9a90c3777916457a48c&format=json&ip=";
	
	/**
	 * 
	 * @var string base URL for google place search
	 */
	private $s_google_place_search_url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?";
	
	/**
	 * 
	 * @var string base URL for a detailed google place search
	 */
	private $s_google_place_search_detail_url = "https://maps.googleapis.com/maps/api/place/details/json?";
	
	/**
	 * @todo replace this key
	 * @var string google place api key
	 */
	private $s_google_place_key = "AIzaSyCRQliZkxPQ_xvpRom2CUQOzh-bSbmy5As";
	
	
	public function __construct() { }
	
	public function __destruct() { }
	
	/**
	 * @desc get the clients location information. This way we can default their location when searching for campaigns, funeral homes, etc.
	 * @param string $s_zip_code zip code if we already have it.
	 * @return array location data.
	 */
	function get_location( $s_zip_code = null ) {
		if( is_null( $s_zip_code ) ) {
			$s_ip = $this->get_ip();
			$s_search_url = $this->s_search_url . $s_ip;
			$a_data = json_decode( file_get_contents( $s_search_url ), true );
			$s_zip_code = $a_data['zipCode'];
		}
		
		$o_db = new db_base();
		
		$o_result = $o_db->call( "get_location_info_by_zip", "'" . addslashes( $s_zip_code ) . "'" );
		
		if( $o_result->num_rows > 0 ) {
			$a_zip_info = mysqli_fetch_assoc( $o_result );
		}
	
		unset($db);
		
		return $a_zip_info;
	}
	
	/**
	 * @desc translate a physical address to a lat and lng
	 * @param string $s_address address in the form of street address,+city,+state
	 * @return array|boolean array of lat/lng on success, bool false on fail
	 */
	function address_to_lat_lng( $s_address ) {
		
		$s_address = urlencode( $s_address );
		$a_result = json_decode( file_get_contents( "https://maps.googleapis.com/maps/api/geocode/json?address=$s_address&key=".$this->s_google_place_key ), true );
		if ( $a_result['status'] == "OK" ) {
			
			return array(
				'lat'	=> $a_result['results'][0]['geometry']['location']['lat'],
				'lng'	=> $a_result['results'][0]['geometry']['location']['lng']
			);
		}
		return false;
	}
	
	/**
	 * @desc grab the client's ip address
	 * @return string the client's ip`
	 */
	function get_ip() {
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$s_ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$s_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$s_ip = $_SERVER['REMOTE_ADDR'];
		}
		
		//@todo remove on go live
		if( $s_ip == '127.0.0.1') {
			$s_ip = '74.109.187.69';
		}
		
		return $s_ip;
	}
	
	/**
	 * @desc Will find all funeral homes within a 30 mile radius for the provided lat lng
	 * 
	 * @param float $i_lat Latitude for search to center on
	 * @param float $i_lng Longitude for search to center on
	 * @return array of arrays, listing the funeral home name and google place id 
	 */
	function find_new_funeral_homes( $i_lat, $i_lng ) {
		
		// 30 miles in meters
		$i_search_meters = '48280.3';
		
		$s_search_url = $this->s_google_place_search_url."&location=".$i_lat.",".$i_lng."&types=funeral_home&radius=".$i_search_meters."&key=".$this->s_google_place_key;
		
		$a_results = json_decode( file_get_contents( $s_search_url ), true );
		
		$a_funeral_homes = array();
		if ( $a_results['status'] == "OK" ) {
			
			foreach ( $a_results['results'] as $a_homes ) {

				$a_funeral_homes[] = array(
					'name'			=> $a_homes['name'],
					'place_id'		=> $a_homes['place_id'],
				);
			}
		}
		
		return $a_funeral_homes;
	}
	
	/**
	 * @desc Will get detailed information about a funeral home based on the Google Place ID. This function should be used ONLY if it is a brand
	 * 			new funeral home we do not already have in our db
	 * 
	 * @param string $s_place_id Google Place ID. Can be gotten from the find_new_funeral_homes function in this class
	 * @return boolean|array Boolean FALSE if we can not get information on this funeral home, otherwise array of information ready to be sent to funeral_home_base's create_funeral_home function
	 */
	function get_detailed_google_info( $s_place_id ) {
		
		$s_search_url = $this->s_google_place_search_detail_url."&placeid=".$s_place_id."&key=".$this->s_google_place_key;
		
		$a_result = json_decode( file_get_contents( $s_search_url ), true );
		
		if ( $a_result['status'] != "OK" ) {
			return false;
		}
		
		$a_return = array(
				'partner_id'					=> '',
				'funeral_home_name'				=> '',
				'funeral_home_contact_name'		=> '',
				'funeral_home_phone'			=> '',
				'funeral_home_email'			=> '',
				'funeral_home_address'			=> '',
				'funeral_home_city'				=> '',
				'funeral_home_state'			=> '',
				'funeral_home_zip'				=> '',
				'funeral_home_lat'				=> '',
				'funeral_home_lng'				=> '',
				'funeral_home_facebook_link'	=> '',
				'funeral_home_twitter_link'		=> '',
				'funeral_home_google_link'		=> '',
				'funeral_home_other_link'		=> '',
				'funeral_home_about'			=> '',
				
			
		);
		foreach ( $a_result['result']['address_components'] as $a_address ) {
			
			
			if ( in_array( 'street_number', $a_address['types'] ) ) {
				$a_return['street_number'] = $a_address['long_name'];
			}
			
			if ( in_array( 'route', $a_address['types'] ) ) {
				$a_return['street'] = $a_address['long_name'];
			}
			
			if ( in_array( 'locality', $a_address['types'] ) ) {
				$a_return['funeral_home_city'] = $a_address['long_name'];
			}
			
			if ( in_array( 'administrative_area_level_1', $a_address['types'] ) ) {
				$a_return['funeral_home_state'] = $a_address['short_name'];
			}
			
			if ( in_array( 'postal_code', $a_address['types'] ) ) {
				$a_return['funeral_home_zip'] = $a_address['long_name'];
			}
		} 
		
		$a_return['funeral_home_lat'] = $a_result['result']['geometry']['location']['lat'];
		$a_return['funeral_home_lng'] = $a_result['result']['geometry']['location']['lng'];
		$a_return['funeral_home_address'] = $a_return['street_number']." ".$a_return['street'];
		$a_return['funeral_home_name'] = $a_result['result']['name'];
		$a_return['funeral_home_phone'] = $a_result['result']['international_phone_number'];
		$a_return['google_place_id'] = $a_result['result']['place_id'];

		return $a_return;
	}
}