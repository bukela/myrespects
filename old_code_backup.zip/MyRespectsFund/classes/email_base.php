<?php

require_once 'abstract_base.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../vendor/phpmailer/phpmailer/PHPMailerAutoload.php';

class email_base extends abstract_base {
	// @todo enter real information here from mailchimp
	protected $s_from_address = "";
	protected $s_username = "";
	protected $s_password = "";
	protected $s_host= "";
	
	public function __construct() { }
	
	public function __destruct() { }
	
	/**
	 * @desc function to send an email using mail gun. if it fails for some reason, use default smtp as back up.
	 * 
	 * @param string $s_to_email email address of recipient
	 * @param string $s_subject subject of email
	 * @param string $s_html_message html version of email
	 * @param string $alt_message none html versions of email
	 * @return boolean
	 */
	function send_email( $s_to_email, $s_subject, $s_html_message, $alt_message = "" ) {
		
		$s_headers = "From: No Reply <" . $this->s_from_address . ">. \r\n";
		$s_headers .= "Reply-To: noreply@myrespects.org \r\n";
		
		$s_headers .= "MIME-Version: 1.0\r\n";
		$s_headers .= "Content-Type: UTF-8;\r\n";

		$mail = new PHPMailer;

		$mail->isSMTP();                        // Set mailer to use SMTP
		$mail->Host = $this->s_host;       		// Specify main and backup SMTP servers
		$mail->SMTPAuth = true;                 // Enable SMTP authentication
		$mail->Username = $this->s_username;	// SMTP username
		$mail->Password = $this->s_password;	// SMTP password
		$mail->SMTPSecure = 'tls';              // Enable encryption, only 'tls' is accepted

		$mail->CharSet = "UTF-8;";

		$mail->From = $this->s_from_address;
		$mail->FromName = $this->s_from_address;

		$mail->Subject = $s_subject;

		$mail->IsHTML(true);

		$mail->Body = $s_html_message;
		$mail->AltBody = $alt_message;

		$mail->addAddress($s_to_email);
					
		if(!$mail->send() ) {
			$this->s_debug =  'Mailer Error: ' . $mail->ErrorInfo;
			$b_success = mail($s_to_email, $s_subject, $s_html_message, $s_headers);
		} 
		
		return $b_success;
	}
}
?>