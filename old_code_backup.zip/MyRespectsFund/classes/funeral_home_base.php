<?php

/**
 *
 * @author Adam F
 * @version 1.0
 * @desc class to handle all funeral home related functions.
 *
 */

require_once 'db_base.php';
require_once 'image_base.php';

class funeral_home_base extends db_base {
	
	public function __construct() { }
	
	public function __destruct() { }
	
	/**
	 * 
	 * @param array $a_params params for SP call
	 * @return int funeral home id or 0 if failed
	 */
	public function create_funeral_home( $a_params, $a_file_data = null ) {
		$this->connect();
		
		if ( isset( $a_params['funeral_home_id'] ) && $a_params['funeral_home_id'] != "0" ) {
			return $this->update_funeral_home( $a_params, $a_file_data );
		}
		
		$a_defaults = array(
				'partner_id'					=> '',
				'funeral_home_name'				=> '',
				'funeral_home_contact_name'		=> '',
				'funeral_home_phone'			=> '',
				'funeral_home_email'			=> '',
				'funeral_home_address'			=> '',
				'funeral_home_city'				=> '',
				'funeral_home_state'			=> '',
				'funeral_home_zip'				=> '',
				'funeral_home_lat'				=> '',
				'funeral_home_lng'				=> '',
				'funeral_home_facebook_link'	=> '',
				'funeral_home_twitter_link'		=> '',
				'funeral_home_google_link'		=> '',
				'funeral_home_other_link'		=> '',
				'funeral_home_about'			=> '',
				'google_place_id'				=> '',
		);
		
		$a_params = array_merge( $a_defaults, $a_params );
		
		$a_query_params = array(
				intval( $a_params['partner_id'] ),
				addslashes( $a_params['funeral_home_name'] ),
				addslashes( $a_params['funeral_home_contact_name'] ),
				addslashes( $a_params['funeral_home_phone'] ),
				addslashes( $a_params['funeral_home_email'] ),
				addslashes( $a_params['funeral_home_address'] ),
				addslashes( $a_params['funeral_home_city'] ),
				addslashes( $a_params['funeral_home_state'] ),
				addslashes( $a_params['funeral_home_zip'] ),
				addslashes( $a_params['funeral_home_lat'] ),
				addslashes( $a_params['funeral_home_lng'] ),
				addslashes( $a_params['funeral_home_facebook_link'] ),
				addslashes( $a_params['funeral_home_twitter_link'] ),
				addslashes( $a_params['funeral_home_google_link'] ),
				addslashes( $a_params['funeral_home_other_link'] ),
				addslashes( $a_params['funeral_home_about'] ),
				addslashes( $a_params['google_place_id'] ),
		);
		
		$o_result = $this->call("funeral_home_insert", $a_query_params);

		$a_result = mysqli_fetch_assoc( $o_result );
		
		$i_funeral_home_id = intval( $a_result['funeral_home_id'] );
		
		if (  ( isset( $a_params['sideload-image'] ) && !empty( $a_params['sideload-image'] ) ) 
				|| ( isset( $a_file_data ) && !empty( $a_file_data['tmp_name'] ) ) ) {
			
			if ( isset( $a_params['sideload-image'] ) && !empty( $a_params['sideload-image'] ) ) {
				
				$s_tmp_file_name = md5( time() . $i_funeral_home_id . $a_params['sideload-image'] );
				copy( $a_params['sideload-image'], "/tmp/$s_tmp_file_name" );
				
				$a_file_data['tmp_name'] = "/tmp/$s_tmp_file_name";
				
			}
			
			$o_image = new image_base();
			
			$i_image_id = intval( $o_image->save_image( $a_file_data['tmp_name'], "funeral_home", $i_funeral_home_id ) );
			
			if ( isset( $s_tmp_file_name ) && !empty( $s_tmp_file_name ) ) {
				unlink( $a_file_data['tmp_name'] );
			}
			
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us." );
			
				return $a_response;
			}
		}
		
		return true;
	}
	
	/**
	 * @desc if this is just an update for the funeral home this will update it
	 * 
	 * @param array $a_params params for SP call
	 * @param array $a_file_data file data from $_FILES
	 * @return int funeral home id or 0 if failed
	 */
	public function update_funeral_home( $a_params, $a_file_data = null ) {
		$this->connect();
	
		$a_defaults = array(
				'partner_id'					=> '',
				'funeral_home_name'				=> '',
				'funeral_home_contact_name'		=> '',
				'funeral_home_phone'			=> '',
				'funeral_home_email'			=> '',
				'funeral_home_address'			=> '',
				'funeral_home_city'				=> '',
				'funeral_home_state'			=> '',
				'funeral_home_zip'				=> '',
				'funeral_home_lat'				=> '',
				'funeral_home_lng'				=> '',
				'funeral_home_facebook_link'	=> '',
				'funeral_home_twitter_link'		=> '',
				'funeral_home_google_link'		=> '',
				'funeral_home_other_link'		=> '',
				'funeral_home_about'			=> '',
				'google_place_id'				=> '',
		);
	
		$a_params = array_merge( $a_defaults, $a_params );
	
		$a_query_params = array(
				intval( $a_params['funeral_home_id'] ),
				intval( $a_params['partner_id'] ),
				addslashes( $a_params['funeral_home_name'] ),
				addslashes( $a_params['funeral_home_contact_name'] ),
				addslashes( $a_params['funeral_home_phone'] ),
				addslashes( $a_params['funeral_home_email'] ),
				addslashes( $a_params['funeral_home_address'] ),
				addslashes( $a_params['funeral_home_city'] ),
				addslashes( $a_params['funeral_home_state'] ),
				addslashes( $a_params['funeral_home_zip'] ),
				addslashes( $a_params['funeral_home_lat'] ),
				addslashes( $a_params['funeral_home_lng'] ),
				addslashes( $a_params['funeral_home_facebook_link'] ),
				addslashes( $a_params['funeral_home_twitter_link'] ),
				addslashes( $a_params['funeral_home_google_link'] ),
				addslashes( $a_params['funeral_home_other_link'] ),
				addslashes( $a_params['funeral_home_about'] ),
				addslashes( $a_params['google_place_id'] ),
		);
	
		$o_result = $this->call("funeral_home_update", $a_query_params);
	
		$a_result = mysqli_fetch_assoc( $o_result );
	
		$i_funeral_home_id = intval( $a_result['funeral_home_id'] );
	
		if (  ( isset( $a_params['sideload-image'] ) && !empty( $a_params['sideload-image'] ) )
		|| ( isset( $a_file_data ) && !empty( $a_file_data['tmp_name'] ) ) ) {
				
			if ( isset( $a_params['sideload-image'] ) && !empty( $a_params['sideload-image'] ) ) {
	
				$s_tmp_file_name = md5( time() . $i_funeral_home_id . $a_params['sideload-image'] );
				copy( $a_params['sideload-image'], "/tmp/$s_tmp_file_name" );
	
				$a_file_data['tmp_name'] = "/tmp/$s_tmp_file_name";
	
			}
				
			$o_image = new image_base();
				
			$i_image_id = intval( $o_image->save_image( $a_file_data['tmp_name'], "funeral_home", $i_funeral_home_id ) );
				
			if ( isset( $s_tmp_file_name ) && !empty( $s_tmp_file_name ) ) {
				unlink( $a_file_data['tmp_name'] );
			}
				
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us." );
					
				return $a_response;
			}
		}
	
		return true;
	}
	
	/**
	 * @desc Will search the db and google to find all funeral homes within 30 miles of the zip code. Will check google to see if there are any
	 * 			new funeral homes we do not have in the db, if there are we will get detailed information about them and insert them into the db
	 * 			will then return array of matching funeral home information
	 * 
	 * @param int $i_zip_code zip code to search for funeral homes around
	 * @return boolean|array boolean FALSE if we do not reconize the zip code sent otherwise array of matching funeral homes
	 */
	public function find_funeral_home_by_zip( $i_zip_code ) {
		require_once 'location_base.php';
		
		$o_zip_info = $this->call( "get_location_info_by_zip", "'".intval( $i_zip_code )."'" );
		if ( $o_zip_info->num_rows == 0 ) {
			return false;
		}
		$a_row = $o_zip_info->fetch_assoc();
		$i_lat = $a_row['lat'];
		$i_lng = $a_row['lng'];
		$o_zip_info->free();

		// query db for funeral homes around this zip code, grab the name, address, google place id
		$a_place_ids = array();
		$o_results = $this->call( "funeral_home_search", "'$i_lat', '$i_lng'" );

		if ( $o_results->num_rows > 0 ) {
			
			while( $a_row = $o_results->fetch_assoc() ) {
				
				$a_place_ids[] = $a_row['funeral_home_place_id'];
			}
		}
		
		$o_lb = new location_base();
		
		$a_new_funeral_homes = $o_lb->find_new_funeral_homes( $i_lat, $i_lng );
		
		if ( is_array( $a_new_funeral_homes ) ) {
			foreach ( $a_new_funeral_homes as $a_funeral_homes ) {
				
				// only make this API call if we dont already have the funeral home in our db - we have a limited number of API calls per day.
				if ( !in_array( $a_funeral_homes['place_id'], $a_place_ids ) ) {
					
					$a_details = $o_lb->get_detailed_google_info( $a_funeral_homes['place_id'] );
					// create new db entry
					$this->create_funeral_home( $a_details );
				}
			}
		}

		$o_results = $this->call( "funeral_home_search", "'$i_lat', '$i_lng'" );
		
		$a_return = array();
		if ( $o_results->num_rows > 0 ) {
				
			while( $a_row = $o_results->fetch_assoc() ) {
		
				$a_return[] = $a_row;
			}
		}
		return $a_return;
	}
	
	/**
	 * @desc will get the detailed information about a funeral home
	 * 
	 * @param unknown $i_funeral_home_id
	 * @return array details of the funeral home
	 */
	public function get_details( $i_funeral_home_id ) {
		
		$o_result = $this->call( 'get_funeral_home_details', "'".$i_funeral_home_id."'" );
		
		$a_return = array();
		if ( $o_result->num_rows > 0 ) {
				
			$a_return = $o_result->fetch_assoc();
		}
		return $a_return;
	}
	
	/**
	 * @desc will check our local database for a already existing funeral home with a similar/matching name
	 * 
	 * @param string $s_funeral_home_name the funeral home name
	 * @return array list of matching funeral homes if any
	 */
	public function find_funeral_home_by_name( $s_funeral_home_name ) {

		$o_result = $this->call( 'check_funeral_home_by_name', "'".$s_funeral_home_name."'" );
		
		$a_return = array();
		if ( $o_result->num_rows > 0 ) {
			
			while ( $a_row = $o_result->fetch_assoc() ) {
				
				$a_return[] = $a_row;
			}
		}
		return $a_return;
	}

	
	public function get_user_funeral_home( $i_user_id ) {
	
	
		$a_result = $this->call( 'get_user_funeral_home', "'".intval( $i_user_id )."'" );
	
		if ( $a_result->num_rows == 1 ) {
	
			$a_result = $a_result->fetch_assoc();
	
			if ( !isset( $a_result[0] ) ) {
				return $a_result['funeral_home_id'];
			}
		}
		return FALSE;
	}
	
	public function get_funeral_home_details( $i_funeral_home_id ) {
	
		$o_details = $this->call("get_funeral_home_data", "'" . intval( $i_funeral_home_id ) . "'");
	
		$a_details = array();
		if ( $o_details->num_rows > 0 ) {
				
			while ( $a_row = $o_details->fetch_assoc() ) {
	
				foreach ( $a_row as $s_key => $s_value ) {
						
					if ( $s_key == 'funeral_home_image' ) {
						$o_image = new image_base();
						$a_details[ $s_key ] = isset( $a_row['funeral_home_image'] ) && !empty( $a_row['funeral_home_image'] ) ? $o_image->get_full_url( $a_row['funeral_home_image'] ) : '';
					} else {
						$a_details[ $s_key ] = $s_value;
					}
				}
			}
		}
	
		return $a_details;
	}

	public function update_funeral_home_image( $a_post_data, $a_file_data, $b_is_url = FALSE ) {
	
		$i_funeral_home_id = $this->get_protected_var('funeral_home_id');
		if ( empty( $i_funeral_home_id ) || intval( $i_funeral_home_id ) == 0 ) {
			return false;
		}
	
		if ( $b_is_url == FALSE ) {
			$s_image_path = $a_file_data['tmp_name'];
		} else {
			$s_image_path = $a_post_data['campaign_main_url'];
		}
	
		$o_image = new image_base();
	
		if( $s_image_path != '' ) {
	
			$i_image_id = intval( $o_image->save_image( $s_image_path , "funeral_home", $i_funeral_home_id ) );
	
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us(2)." );
					
				return $a_response;
			}
		}
	}
	
	public function update_description( $s_description ) {

		$i_funeral_home_id = $this->get_protected_var('funeral_home_id');
		if ( empty( $i_funeral_home_id ) || intval( $i_funeral_home_id ) == 0 ) {
			return false;
		}
		
		$this->call( 'update_partner_description', "'$i_funeral_home_id','$s_description'" );
		
		return true;
		
	
	}
	
	public function update_funeral_home_info( $a_data ) {
		
		$i_funeral_home_id = $this->get_protected_var('funeral_home_id');
		if ( empty( $i_funeral_home_id ) || intval( $i_funeral_home_id ) == 0 ) {
			return false;
		}
		
		$this->call( 'update_funeral_home_info', "'".intval($a_data['funeral_home_id'])."','".addslashes($a_data['funeral_home_name'])."',
													'".addslashes($a_data['funeral_home_other_link'])."','".addslashes($a_data['funeral_home_contact_name'])."',
													'".addslashes($a_data['funeral_home_contact_name_last'])."','".addslashes($a_data['funeral_home_address'])."',
													'".addslashes($a_data['funeral_home_city'])."','".addslashes($a_data['funeral_home_state'])."',
													'".addslashes($a_data['funeral_home_zip'])."','".addslashes($a_data['funeral_home_email'])."',
													'".addslashes($a_data['funeral_home_phone'])."'" );
		
		return true;
	}
	
	public function get_linked_funds( $i_funeral_home_id = null ){
		
		if ( is_null( $i_funeral_home_id ) ) 
			$i_funeral_home_id = $this->get_protected_var('funeral_home_id');
		
		if ( empty( $i_funeral_home_id ) || intval( $i_funeral_home_id ) == 0 ) {
			return false;
		}
		
		$o_details = $this->call("get_funeral_home_linked_funds", "'" . intval( $i_funeral_home_id ) . "'");
		
		$a_details = array();
		if ( $o_details->num_rows > 0 ) {
		
			while ( $a_row = $o_details->fetch_assoc() ) {
		
				$temp = array();
				
				foreach ( $a_row as $s_key => $s_value ) {
		
					if ( $s_key == 'main_campaign_image' ) {
						$o_image = new image_base();
						$temp[ $s_key ] = isset( $s_value ) && !empty( $s_value ) ? $o_image->get_full_url( $s_value ) : '';
					} else {
						$temp[ $s_key ] = $s_value;
					}
				}

				$a_details[] = $temp;
			}
		}
		
		return $a_details;
		
	}
	
}









