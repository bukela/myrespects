<?php
use OpenCloud\Common\Constants\Datetime;
/**
 *
 * @author Adam F
 * @version 1.0
 * @desc class to handle all campaign related functions.
 *
 */

require_once 'db_base.php';
require_once 'image_base.php';
require_once 'wepay_base.php';

class campaign_base extends db_base {
	
	public function __construct() { }
	
	public function __destruct() { }
	
	public function create_campaign( $a_post_data, $a_file_data ) {
		$a_errors = $this->validate_create_campaign_form( $a_post_data );
		
		if( count( $a_errors ) > 0 ) {
			$a_response = array("result" => false, "errors" => $a_errors, "message" => "Please fill out all required fields" );
		
			return $a_response;
		}
		
		$this->connect();
		
		$o_campaign_insert_result = $this->call("campaign_insert", "'" . intval( $a_post_data['user_id'] ) . "',
																	'" . intval( $a_post_data['funeral_home_id'] ) . "',
																	'',
																	'" . addslashes( $a_post_data['campaign_title'] ) . "',
																	'" . intval( $a_post_data['campaign_goal'] ) . "',
																	'" . addslashes( $a_post_data['campaign_zip'] ) . "',
																	'" . addslashes( $a_post_data['campaign_story'] ) . "',
																	'" . date( 'Y-m-d', strtotime( $a_post_data['campaign_end'] ) ) . "'");
		
		$a_result = mysqli_fetch_assoc( $o_campaign_insert_result );
		
		$i_campaign_id = intval( $a_result['campaign_id'] );
		
		if( $i_campaign_id == 0 ) {
			$a_response = array("result" => false, "debug" => "Failed to insert campaign.", "message" => "We were unable to verify your campaign. Please contact us(1)." );
			
			return $a_response;
		}
		
		$o_image = new image_base();
		
		if( $a_file_data['tmp_name'] != '' ) {
			$i_image_id = intval( $o_image->save_image( $a_file_data['tmp_name'], "campaign", $i_campaign_id ) );
			
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us(2)." );
					
				return $a_response;
			}
			
			$o_result = $this->call("campaign_assign_main_image", "'" . intval( $i_campaign_id ) . "','" . intval( $i_image_id ) . "'");
		}
		
		$o_get_result = $this->call( "get_wepay_token_by_user_id", "'" . intval( $a_post_data['user_id'] ) . "'");
		
		$a_user_info = mysqli_fetch_assoc( $o_get_result );
		
		$o_wepay = new wepay_base();
		
		$o_result = $o_wepay->create_wepay_account( $a_user_info['wepay_access_token'], $a_post_data['campaign_title'], $a_post_data['campaign_story']);
		
		$this->call( 'campaign_update_wepay_by_id', "'$i_campaign_id','$o_result->account_id','$o_result->state'");
		
		return true;
	}
	
	/**
	 * @desc Get the *TOTAL* number of results for the search term
	 * 
	 * @param string $s_search_value search term, will be sanitized in this function
	 * 
	 * @return int Number of matching campaigns
	 */
	public function get_search_results_count( $s_search_value ) {
		
		$o_campaign_search_count = $this->call( "get_search_result_count", "'".addslashes( $s_search_value )."'" );

		return $o_campaign_search_count->fetch_row()[0];
	}

	/**
	 * @desc Get the matching campaigns for the search term. Will return sets of 30 results at a time. Increment the $i_start_index parm
	 * 			to get the next set of 30 results if needed.
	 * 
	 * @param string $s_search_value search term, will be sanitized in this function
	 * @param int $i_start_index integer for the start offset. Will be sanitized in this function
	 * 
	 * @return array will contain an array starting the 'result', a 'message' if 'result' is boolean false or 'data' if 'result' is boolean true
	 */
	public function get_search_results( $s_search_value, $i_start_index ) {
		
		$o_search_results = $this->call( "get_search_results", "'".addslashes( $s_search_value )."', '".intval( $i_start_index )."'" );
		
		$a_return = array(
			'result'	=> false,
			'debug'		=> "Failed to find any campaigns.",
			'message'	=> "We're sorry, but we could not find any campaign to match your search critera."
		);
		
		if ( $o_search_results->num_rows > 0 ) {
			
			$o_image = new image_base();
			
			unset( $a_return['debug'] );
			unset( $a_return['message'] );
			
			$a_return['result'] = true;
			
			while ( $a_row = $o_search_results->fetch_assoc() ) {
				
				$a_return['data'][] = array(
						'id'				=> $a_row['campaign_id'],
						'title'				=> $a_row['campaign_title'],
						'image'				=> isset( $a_row['image_name'] ) && !empty( $a_row['image_name'] ) ? $o_image->get_full_url( $a_row['image_name'] ) : '',
						'formatted_raised'	=> "$".number_format( $a_row['raised'] ), 
						'formatted_goal'	=> "$".number_format( $a_row['campaign_goal'] ),
						'raised'			=> $a_row['raised'],
						'goal'				=> $a_row['campaign_goal'],
						'description'		=> $a_row['campaign_story'],
				);
			}
		} elseif ( $i_start_index > 0 ) {
			// need this case for when we found X number of results and this is the same as a breakpoint for the query, the query will return empty but we didnt fail to find campaigns.
			$a_return = array(
				'result'	=> true,
				'debug'		=> "No more campaigns found.",
				'message'	=> "",
				'data'		=> array()
			);
		}
		unset( $o_image );
		
		return $a_return;
	}
	
	/**
	 * @desc take raw post data and validate it.
	 * @param array $a_post_data raw post data from create campaign form
	 * @return array $a_errors array of errors found (empty if all valid)
	 */
	public function validate_create_campaign_form( $a_post_data ) {
		$a_errors = array();
		$a_not_required = array("campaign_referral"); 
		
		foreach ( $a_post_data as $s_name => $m_value ) {
			switch ($s_name) {
				case "campaign_goal":
					if( intval( $m_value ) == 0 ) {
						array_push( $a_errors, array( $s_name => "Please enter a valid goal amount" ) );
					}
					break;
				case "phone_number":
					$m_value = preg_replace( "/\D/", '', $m_value );
					$i_length = strlen( $m_value );
					if ( !($i_length == 7 || $i_length == 10) ) {
						array_push( $a_errors, array( $s_name => "Please enter a valid phone number" ) );
					}
					break;
				case "email":
					if ( !filter_var( $m_value, FILTER_VALIDATE_EMAIL ) ) {
						array_push( $a_errors, array( $s_name => "Please enter a valid email" ) );
					}
					break;
				case "ssn":
					$m_value = preg_replace( "/\D/", '', $m_value );
					if ( strlen( $m_value ) != 9 ) {
						array_push( $a_errors, array( $s_name => "Please enter a valid Social Security Number" ) );
					}
					break;
				case "dob":
				case "campaign_end":
					$test_arr  = explode('/', $m_value);
					if ( !checkdate( $test_arr[0], $test_arr[1], $test_arr[2] ) ) {
						array_push( $a_errors, array( $s_name => "Please enter a valid date" ) );
					}
					break;
				default:
					if( $s_name == "" && ! in_array( $s_name, $a_not_required ) ) {
						array_push( $a_errors, array( $s_name => "This field is required" ) );
					}
			}
		}
		
		return $a_errors;
	}
	
	/**
	 * @desc Wiill give back all the detailed information about a campaign to build the single campaign page
	 * 
	 * @param int $i_campaign_id id of the campaign
	 * @return array of all the detailed information about this campaign
	 */
	public function get_campaign_details( $i_campaign_id ) {

		$o_details = $this->call("get_campaign_data", "'" . intval( $i_campaign_id ) . "'");
		
		$a_campaign_details = array();
		if ( $o_details->num_rows > 0 ) {
			
			while ( $a_row = $o_details->fetch_assoc() ) {

				foreach ( $a_row as $s_key => $s_value ) {
					
					if ( $s_key == 'campaign_story' ) {
						if ( strlen( $s_value ) > 140 ) {
							$i_space_index = strpos( $s_value, ' ', 140 );
							
							$a_campaign_details[ $s_key ] = substr( $s_value, 0, $i_space_index );
							$a_campaign_details[ $s_key."_more" ] = substr( $s_value, $i_space_index );
						} else {
							$a_campaign_details[ $s_key ] = $s_value;
						}
					} elseif ( $s_key == 'main_campaign_image' ) {
						$o_image = new image_base();
						$a_campaign_details[ $s_key ] = isset( $a_row['main_campaign_image'] ) && !empty( $a_row['main_campaign_image'] ) ? $o_image->get_full_url( $a_row['main_campaign_image'] ) : '';
					} elseif ( $s_key == 'funeral_home_image' ) {
						$o_image = new image_base();
						$a_campaign_details[ $s_key ] = isset( $a_row['funeral_home_image'] ) && !empty( $a_row['funeral_home_image'] ) ? $o_image->get_full_url( $a_row['funeral_home_image'] ) : '';
					} elseif ( $s_key == 'campaign_end' ) {
						$a_campaign_details['time_left'] = preg_replace( '/\D/', '', $this->get_datetime_diff( date('Y-m-d'), $s_value ) );
						$a_campaign_details[ $s_key ] = $s_value;
					} else {
						$a_campaign_details[ $s_key ] = $s_value;
					}
				}
				
				
			}
		}
		
		return $a_campaign_details;
	}

	public function get_campaign_gallery( $i_campaign_id ) {
		
		$o_details = $this->call("get_campaign_gallery", "'" . intval( $i_campaign_id ) . "'");
		$a_gallery = array();
		if ( $o_details->num_rows > 0 ) {
				
			$o_image = new image_base();
			
			while ( $a_row = $o_details->fetch_assoc() ) {
				
				$a_gallery[ $a_row['campaign_image_id'] ] = $o_image->get_full_url( $a_row['image_name'] );
			}
		}
		
		return $a_gallery;
	}
	
	public function get_all_campaign_donations( $i_campaign_id ) {
		$o_donation = $this->query("SELECT * FROM donation WHERE campaign_id = '" . intval( $i_campaign_id ) . "' AND complete_flag = 1");
		
		$a_donation_details = array();
		if ( $o_donation->num_rows > 0 ) {
			while ( $a_row = $o_donation->fetch_assoc() ) {
				$temp = $a_row;
				$temp['time_diff'] = $this->get_datetime_diff( $a_row['ts_created'] ); 
				
				array_push( $a_donation_details, $temp );
			}
		}
		
		return $a_donation_details;
	}
	
	public function get_campaign_total_donations( $i_campaign_id ) {
		$o_donation = $this->query("SELECT SUM( amount ) as total_donation FROM donation WHERE campaign_id = '" . intval( $i_campaign_id ) . "' and complete_flag = 1");
		if ( $o_donation->num_rows > 0 ) {
			$a_donation = mysqli_fetch_assoc( $o_donation );
			
			return $a_donation['total_donation'];
		} else {
			return 0;
		}
	}
	
	/**
	 * @desc Will get local campaigns first, otherwise show the highest funded campaigns 
	 * 
	 */
	public function get_current_campaigns_homepage(){
		
		$a_return = array(
				'result'	=> false,
				'debug'		=> "Failed to find any campaigns.",
				'message'	=> "We're sorry, but we could not find any campaign to match your search critera."
		);
		
		include_once 'location_base.php';
		$o_lb = new location_base();
		$a_location_info = $o_lb->get_location();
		
		
		// if we have location data, grab the 8 closest campaigns
		if ( isset( $a_location_info['lat'] ) && isset( $a_location_info['lng'] ) && !empty( $a_location_info['lat'] ) && !empty( $a_location_info['lng'] ) ) {
			
			$o_search_results = $this->call( "get_local_campaigns", "'".floatval( $a_location_info['lat'] )."', '".floatval( $a_location_info['lng'] )."'" );
		
			if ( $o_search_results->num_rows > 0 ) {
					
				$o_image = new image_base();
					
				unset( $a_return['debug'] );
				unset( $a_return['message'] );
					
				$a_return['result'] = true;
					
				while ( $a_row = $o_search_results->fetch_assoc() ) {
			
					$a_return['data'][] = array(
							'id'				=> $a_row['campaign_id'],
							'title'				=> $a_row['campaign_title'],
							'image'				=> isset( $a_row['image_name'] ) && !empty( $a_row['image_name'] ) ? $o_image->get_full_url( $a_row['image_name'] ) : '',
							'formatted_raised'	=> "$".number_format( $a_row['raised'] ),
							'formatted_goal'	=> "$".number_format( $a_row['campaign_goal'] ),
							'raised'			=> $a_row['raised'],
							'goal'				=> $a_row['campaign_goal'],
							'description'		=> $a_row['campaign_story'],
					);
				}
			}
		}
		
		if ( isset( $a_return['data'] ) && count( $a_return['data'] ) >= 8 ) {
			return $a_return;
		}
		
		$o_search_results = $this->call( "get_highest_funded", '' );
			
		if ( $o_search_results->num_rows > 0 ) {
				
			$o_image = new image_base();
				
			unset( $a_return['debug'] );
			unset( $a_return['message'] );
				
			$a_return['result'] = true;
				
			while ( $a_row = $o_search_results->fetch_assoc() ) {
				
				if ( isset( $a_return['data'] ) && count( $a_return['data'] ) >= 8 ) {
					break;
				}
				
				$a_return['data'][] = array(
						'id'				=> $a_row['campaign_id'],
						'title'				=> $a_row['campaign_title'],
						'image'				=> isset( $a_row['image_name'] ) && !empty( $a_row['image_name'] ) ? $o_image->get_full_url( $a_row['image_name'] ) : '',
						'formatted_raised'	=> "$".number_format( $a_row['raised'] ),
						'formatted_goal'	=> "$".number_format( $a_row['campaign_goal'] ),
						'raised'			=> $a_row['raised'],
						'goal'				=> $a_row['campaign_goal'],
						'description'		=> $a_row['campaign_story'],
				);
			}
		}
		
		return $a_return;
	}
	
	public function update_goal( $i_goal ) {
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
		
		$this->call( 'update_campaign_goal', "'$i_campaign_id','$i_goal'" );
		
		return true;
	}
	
	public function update_title( $s_title ) {
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
		
		$this->call( 'update_campaign_title', "'$i_campaign_id','$s_title'" );
		
		return true;
	}
	
	public function update_story( $s_story ) {
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
		
		$this->call( 'update_campaign_story', "'$i_campaign_id','$s_story'" );
		
		return true;
	}
	
	public function update_funeral_home( $i_funeral_home_id ) {
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
	
		$this->call( 'update_campaign_funeral_home', "'$i_campaign_id','$i_funeral_home_id'" );
	
		return true;
	}
	
	public function update_funeral_date( $s_funeral_date ) {
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
	
		$this->call( 'update_campaign_funeral_date', "'$i_campaign_id','".date( 'Y-m-d', strtotime( $s_funeral_date ) )."'" );
	
		return true;
	}
	
	public function get_datetime_diff( $s_time, $s_time2 = NULL ) {
		
		$datetime1 = date_create( $s_time );
		if ( is_null( $s_time2 ) ) {
			$datetime2 = date_create( 'now' );
		} else {
			$datetime2 = date_create( $s_time2 );
		}
		$interval = date_diff($datetime1, $datetime2);
		
		$ago = $interval->format( '%y' );
		if ( $ago > 0 ) {
			return $ago." years ago";
		}
		
		$ago = $interval->format( '%m' );
		if ( $ago > 0 ) {
			return $ago." months ago";
		}
		
		$ago = $interval->format( '%d' );
		if ( $ago > 0 ) {
			return $ago." days ago";
		}
		
		$ago = $interval->format( '%h' );
		if ( $ago > 0 ) {
			return $ago." hours ago";
		}
		
		$ago = $interval->format( '%i' );
		if ( $ago > 0 ) {
			return $ago." minutes ago";
		}
		
		$ago = $interval->format( '%s' );
		if ( $ago > 0 ) {
			return $ago." seconds ago";
		}
		
		return $interval->format('%a days');
	}
	
	public function retrieve_donated( $i_campaign_id = NULL ){
		if ( is_null( $i_campaign_id ) ) {
			$i_campaign_id = $this->get_protected_var('campaign_id');
			if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
				return false;
			}
		}
		
		$o_results = $this->call( 'retrieve_basic_donation_info', "'$i_campaign_id'" );
		
		$a_return = array(
				'result'	=> false,
				'debug'		=> "Failed to find any campaigns.",
				'message'	=> "We're sorry, but we could not find any campaign to match your search critera."
		);
		
		if ( $o_results->num_rows > 0 ) {

			unset( $a_return['debug'] );
			unset( $a_return['message'] );
			
			$a_return['result'] = true;
			
			while ( $a_row = $o_results->fetch_assoc() ) {
		
				$a_return['data'][] = array(
						'first_name'	=> $a_row['first_name'],
						'last_name'		=> $a_row['last_name'],
						'amount'		=> number_format( $a_row['amount'] ),
						'description'	=> $a_row['description'],
						'time'			=> $this->get_datetime_diff( $a_row['ts_created'] ),
				);
			}
		}
		
		return $a_return;
	}
	
	
	public function update_main_campaign_photo( $a_post_data, $a_file_data, $b_is_url = FALSE ) {

		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
	
		if ( $b_is_url == FALSE ) {
			$s_image_path = $a_file_data['tmp_name']; 
		} else {
			$s_image_path = $a_post_data['campaign_main_url'];
		}
		
		$o_image = new image_base();
		
		if( $s_image_path != '' ) {

			$i_image_id = intval( $o_image->save_image( $s_image_path , "campaign", $i_campaign_id ) );
				
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us(2)." );
					
				return $a_response;
			}
				
			$o_result = $this->call("campaign_assign_main_image", "'" . intval( $i_campaign_id ) . "','" . intval( $i_image_id ) . "'");
		}
	}
	
	public function update_campaign_photos_gallery( $a_post_data, $a_file_data ) {
	
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
		
		$o_image = new image_base();

		if ( isset( $a_post_data['removed'] ) && !empty( $a_post_data['removed'] ) ) {
			foreach ( $a_post_data['removed'] as $i_image_id ) {
				$o_image->delete_image( $i_image_id, 'campaign' );
			}
		}

		if ( !empty( $a_file_data ) ) {
			
			foreach ( $a_file_data as $a_image ) {
				
				$s_image_path = $a_image['tmp_name'];
				if( $s_image_path == '' ) {
					continue;
				}

				$i_image_id = intval( $o_image->save_image( $s_image_path , "campaign", $i_campaign_id ) );
			}
		}
		
	}
	
	public function post_update( $a_post_data, $a_file_data, $b_is_url = FALSE ) {
		
		$i_campaign_id = $this->get_protected_var('campaign_id');
		if ( empty( $i_campaign_id ) || intval( $i_campaign_id ) == 0 ) {
			return false;
		}
		
		
		$o_result =  $this->call( 'create_campaign_update', "'".intval($i_campaign_id)."','".addslashes( $a_post_data['update_content'] )."','".addslashes( $a_post_data['video'] )."'" ); 
		$a_result = mysqli_fetch_assoc( $o_result );
		
		$i_update_id = $a_result['update_id'];
		
		if ( $b_is_url == FALSE && !empty( $a_file_data ) ) {
			$s_image_path = $a_file_data['tmp_name'];
		} elseif ( $b_is_url == TRUE && isset( $a_post_data['image_url'] ) && !empty( $a_post_data['image_url'] ) ) {
			$s_image_path = $a_post_data['image_url'];
		} else {
			$s_image_path = '';
		}
		
		
		if( $s_image_path != '' ) {
		
			$o_image = new image_base();
			
			$i_image_id = intval( $o_image->save_image( $s_image_path , "campaign_update", $i_update_id ) );
		
			if( $i_image_id == 0 ) {
				$a_response = array("result" => false, "debug" => $o_image->get_protected_var("a_call_stack"), "message" => "We were unable to verify your campaign. Please contact us(2)." );
					
				return $a_response;
			}
		
			$o_result = $this->call("campaign_update_assign_image_id", "'" . intval( $i_update_id ) . "','" . intval( $i_image_id ) . "'");
		}
		
	}
	
	public function get_updates( $i_campaign_id ) {
		
		$o_details = $this->call("get_campaign_updates", "'" . intval( $i_campaign_id ) . "'");
		
		$a_updates = array();
		if ( $o_details->num_rows > 0 ) {
				
			while ( $a_row = $o_details->fetch_assoc() ) {
		
				foreach ( $a_row as $s_key => $s_value ) {
						
					if ( $s_key == 'image_name' ) {
						$o_image = new image_base();
						$temp[ $s_key ] = !empty( $s_value ) ? $o_image->get_full_url( $s_value ) : '';
					} else {
						$temp[ $s_key ] = $s_value;
					}
					
				}
				$a_updates[] = $temp;
			}
		}
		
		return $a_updates;
		
	}
}