<?php

/**
 *
 * @author Adam F
 * @version 1.0
 * @desc class to handle all image handling. In v1.0 images files will be stored in rackspace cdn and meta data in local db.
 *
 */

require_once __DIR__ . '/../vendor/autoload.php';
use OpenCloud\Rackspace;

require_once 'db_base.php';

class image_base extends abstract_base {
	protected $s_key = "c2bd5559390c4e8dabb54e9a0d9a8f1f";
	protected $s_user_name = "Atechnyrs";
	protected $s_message;
	protected $a_call_stack = array();
	protected $s_container_url = "http://0984323faf1e4e7edaae-3b65e8d5a761ad9122d99f43b759a381.r93.cf5.rackcdn.com/";
	
	protected $s_container_name = "mrf-staging"; //change when taking live
	
	public $a_allowed_file_types = array("image/png", "image/jpeg","image/jpg");
	public $a_image_types = array("user", "campaign", "funeral_home", "campaign_update"); 

	public function __construct() { }
	
	public function __destruct() { }
	
	/**
	 * @desc Connnect to a rackspace contianer to store images
	 * 
	 * @param string $s_container_name name of the container to connect to.
	 * @return \OpenCloud\ObjectStore\Resource\Container container to store images in.
	 */
	public function connect_to_container( $s_container_name = null ) {
		if( is_null( $s_container_name ) ) {
			$s_container_name = $this->s_container_name;
		}
		
		try {
			$o_client = new Rackspace(Rackspace::US_IDENTITY_ENDPOINT, array(
					'username' => $this->s_user_name,
					'apiKey'   => $this->s_key
			));
			$o_service = $o_client->objectStoreService('cloudFiles', 'IAD'); 
			$o_container = $o_service->getContainer( $s_container_name ); 
			
			return $o_container;
		} catch ( Exception $e ) {
			$this->s_message = "Unable to connect to container";
			array_push( $this->a_call_stack, $this->message );
			array_push( $this->a_call_stack, $e->getMessage() );
			return false;
		}
	}
	
	public function get_full_url( $s_file_name ) {
		return $this->s_container_url.$s_file_name;
	}
	
	/**
	 * @desc function to save an image to the CDN. v1.0 uses rackspace CDN 
	 * 
	 * @param string $s_full_file_path full file location of image to upload.
	 * @param string $s_file_cdn_name The name of the image that will be used by CDN. 
	 * 			Note that this may differ from local name (should probably use a unique hash).
	 * 			This may overwrite images that already exist.
	 * 			*File name should include extension. UI will grab image straight from CDN.
	 * 
	 * @return boolean true/false upon success/failure
	 */
	public function save_image_to_cdn( $s_full_file_path, $s_file_cdn_name ) {
		$o_container = $this->connect_to_container();
		
		if( ! is_object( $o_container ) ) {
			$this->s_message = "Unable to connect to container.";
			array_push( $this->a_call_stack, $this->message );
			return false;
		}
		
		if( !$this->does_file_exist( $s_full_file_path ) ) { return false; }	
		
		$s_image_data = file_get_contents( $s_full_file_path );
			
		if( $s_image_data == false ) {
			$this->s_message = "Unable to read file.";
			array_push( $this->a_call_stack, $this->message );
			return false;
		}
			
		$a_files = array(
			array(
				'name' => $s_file_cdn_name,
				'body' => $s_image_data
			)
		);
			
		$a_results = $o_container->uploadObjects( $a_files );
		
		if( $a_results[0]->getReasonPhrase() != "Created" ) {
			$this->s_message = "Unable to put file: " . $a_results[0]->getReasonPhrase();
			array_push( $this->a_call_stack, $this->message );
			return false;
		}
		
		return true;
	}
	
	/** 
	 * @desc take an image and store the file in CDN and meta data in appropriate local db.
	 * 
	 * @param string $s_full_file_path location of file
	 * @param string $s_type type of image (user|campaign|funeral_home)
	 * @param int $i_attachement_id foreign key of entity this image is attached to
	 * 
	 * @return boolean success/failure
	 */
	public function save_image( $s_full_file_path, $s_type, $i_attachement_id ) {

		if( !$this->does_file_exist( $s_full_file_path ) ) { return false; }		
		$a_file_info = $this->get_file_info( $s_full_file_path );
		
		if( ! in_array( $a_file_info['file_type'], $this->a_allowed_file_types ) ) {
			$this->s_message = "File type " . $a_file_info['file_type'] . " is not allowed.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		if( ! in_array( $s_type, $this->a_image_types ) ) {
			$this->s_message = "Unsupported image type.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		$s_image_hash = md5( time() . $a_file_info['file_name'] . $a_file_info['file_size'] );
		$s_file_cdn_name = $s_image_hash  . "." . $a_file_info['extension'];
		
		if( ! $this->save_image_to_cdn( $s_full_file_path , $s_file_cdn_name ) ) {
			return false;
		}
		
		$o_db = new db_base();
		
		$a_params = array(
				intval( $i_attachement_id ),
				$s_file_cdn_name,
				$this->s_container_name,
				$a_file_info['file_size'],
				$a_file_info['file_type']
		);
		
		$o_result = $o_db->call( addslashes( $s_type ) . "_image_insert", $a_params );
		
		unset( $o_db );
		
		$a_result = mysqli_fetch_assoc( $o_result );
		
		return $a_result[ $s_type . '_image_id'];
	}
	
	/**
	 * @desc removes images from our CDN and local storage (metadata)
	 * @param int $i_image_id id of image to remove
	 * @param string $s_type type of the image (user|campaign|funeral_home)
	 * @return boolean success/fail
	 */
	public function delete_image( $i_image_id, $s_type ) {
		if( ! in_array( $s_type, $this->a_image_types ) ) {
			$this->s_message = "Unsupported image type.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		$o_db = new db_base();
		
		$o_result = $o_db->query( "SELECT image_name FROM " . addslashes( $s_type) . "_image WHERE " . addslashes( $s_type) . "_image_id = '" . intval( $i_image_id ) . "'" );
		
		$s_image_name = false;
		
		if( $o_result->num_rows == 1 ) {
			$a_image_info = mysqli_fetch_assoc( $o_result );
		
			if( $a_image_info['image_name'] != "" ) {
				$s_image_name = $a_image_info['image_name']; 
			}
		}
		
		if( $s_image_name === false ) {
			$this->s_message = "Could not find image.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		if( ! $this->delete_image_from_cdn( $s_image_name ) ) {
			$this->s_message = "Unable to delete image.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		$b_result = $o_db->call( addslashes( $s_type ) . "_image_delete", "'" . intval( $i_image_id ) . "'" );
		
		if( ! $b_result ) {
			echo $o_db->get_protected_var("s_last_sql");
			$this->s_message = "Unable to delete image.";
			array_push( $this->a_call_stack, $this->s_message );
			return false;
		}
		
		return true;
	}
	
	/**
	 * @desc Remove file from CDN based on its name
	 * 
	 * @param string $s_image_name name of image to remove
	 * @return boolean succes/fail
	 * 
	 * @todo add more error checking.
	 */
	public function delete_image_from_cdn( $s_image_name ) {
		$o_container = $this->connect_to_container();
		
		$o_object = $o_container->getObject( $s_image_name );

		$o_object->delete();
		
		return true;
	}
	
	/**
	 * @desc might be a little overkill now but could be useful in the future to expand test/logs
	 * 
	 * @param string $s_full_file_location loc of file to check
	 * @return boolean 
	 */
	public function does_file_exist( $s_full_file_location ) {
		if ( ! file_exists( $s_full_file_location ) ) {
			$this->s_message = "File does not exist.";
			array_push( $this->a_call_stack, $this->message );
			return false;
		}
		
		return true;
	}
	
	/**
	 * @desc get metadata about file
	 * 
	 * @param unknown $s_full_file_path full file path of the file
	 * @return boolean|multitype:unknown false if file doesn't exist, array of metadata if it does.
	 */
	public function get_file_info( $s_full_file_path ) {
		if( !$this->does_file_exist( $s_full_file_path ) ) { return false; }
		echo "info here ";
		$a_file_info = array();
		
		$a_path_info = pathinfo( $s_full_file_path );
		
		$a_file_info['file_name'] = $a_path_info['basename'];
		
		$a_file_info['dir'] = $a_path_info['dirname'];
		
		$a_file_info['file_type'] = mime_content_type( $s_full_file_path );
		
		$s_extension = substr( $a_file_info['file_type'], ( strpos( $a_file_info['file_type'], "/" ) + 1 ) ); 
		
		$a_file_info['extension'] = $s_extension;
		
		$a_file_stats = stat( $s_full_file_path );
		
		
		$a_file_info['file_size'] = $a_file_stats['size'];
		
		return $a_file_info;
	}
}