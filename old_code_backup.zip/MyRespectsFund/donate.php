<?php 

ob_start();

require_once '_includes/header.php';

require_once 'classes/campaign_base.php';


$o_cb = new campaign_base();


$i_campaign_id = intval( $_GET['id'] );

$a_campaign = $o_cb->get_campaign_details( $i_campaign_id );


if(isset($_POST['submit']) == "CONTINUE") {
	
	require_once 'classes/wepay_base.php';
	
	$o_wepay = new wepay_base();

	
	//@todo error check
	
	$f_amount = $_POST['amount'];

	$s_donation_hash = md5( time() . $i_campaign_id . session_id() );
	
	
	$o_result = $o_wepay->create_preapproval($a_campaign['wepay_access_token'], $a_campaign['wepay_account_id'], $f_amount, $_POST['description'], $i_campaign_id, $s_donation_hash);
		
		

	if ( ! is_object( $o_result ) ) {
		//error
		$error = "WePay Error: <pre>" . print_r($o_result) . "</pre>";
	}
	
	if ($_POST['anonymous_flag'] == "on") {
		$i_anon_flag = 1;
	} else {
		$i_anon_flag = 0;
	}
	
	
	$b_insert_result = $o_db->call("donation_insert", array(
			$i_campaign_id,
			$o_result->preapproval_id,
			$_POST['first_name'],
			$_POST['last_name'],
			$_POST['address'],
			$_POST['city'],
			$_POST['state'],
			$_POST['zip'],
			'country',
			$_POST['email'],
			$f_amount,
			$_POST['description'],			
			$i_anon_flag,
			$o_result->preapproval_uri,
			$s_donation_hash
	));
	
	
	if( $b_insert_result ) {		
		header( "location: " . $o_result->preapproval_uri );
		
	} else {
		//error
		$error .= "DB Error: <pre>" . print_r($b_insert_result) . "</pre>" . $o_db->get_protected_var('s_last_sql');
	}
	
}

ob_end_flush();
?>
<section id="profile-heading">
	<div class="container">
		<div class="col-sm-7">
			<h6>Funeral Expenses</h6>
			<h3>Fundraising for Susan A. Smith</h3>
			<ul class="contactlist">
				<li><a href="#"><img src="assets/images/icon_address_pointer.png" alt="" /> San Francisco, CA</a></li>
				<li><a href="#"><img src="assets/images/icon_calender.png" alt="" /> Created: March 15, 2017</a></li>
				<li><a href="#"><img src="assets/images/icon_creator.png" alt="" /> Created: Jonathan E. Gicewicz (Son)</a></li>
			</ul>
		</div>
		<div class="col-sm-5">
			<div class="ned_help_btnrow">
				<a class="need_help_btn" href="#">Need Help?</a>
				<a class="need_help_btn" href="#">BACK TO CAMPAIGN</a>
			</div>
		</div>
	</div>
</section> <!-- #banner ends -->
<section id="profile-content" class="container_donate_step margin-bottom-form"> <!-- #profile-content starts -->
	<div class="container">
		<div class="col-sm-6">
			<form action="donate.php?id=<?php echo( $i_campaign_id ); ?>" method="post">
				<div class="your_donation_checkbox_area fix">
					<div class="your_doncheckbox_titl fix">
						<h2>YOUR DONATION</h2>
					</div>
					<div class="your_doncheckbox_cont fix">
						<div class="check_donation_item fix">
							<!-- <div class="checkbox_wrapper fix">
								<input type="radio" id="checkbox1" name="name" value="300">
								<span class="checked"></span>
							</div> -->
							<label for=""> </label>
							<button class="clickable_amount fix" value="300" type="button">$300</button>
						</div>
						<div class="check_donation_item fix">
							
							<button class="clickable_amount fix" value="200" type="button">$200</button>
						</div>
						<div class="check_donation_item fix">
							
							<button class="clickable_amount fix" value="100" type="button">$100</button>
						</div>
						<div class="check_donation_item fix">
							
							<button class="clickable_amount fix" value="50" type="button">$50</button>
						</div>
						<div class="check_donation_item fix">
							
							<button class="clickable_amount fix" value="25" type="button">$25</button>
						</div>
						<div class="check_donation_item fix">
							
							<button class="clickable_amount fix" value="15" type="button">$15</button>
						</div>
					</div>
					<div class="your_doncheckbox_titl_botm fix">
						<h1>My Choice: $<input type="number" class="take_val" name="amount" id="amount"></h1>
					</div>
				</div>
				<div class="mr_donate_step_content fix">
					<div class="mr_donate_step_onee fix">
						<div class="row">
							<div class="mr_donate_step_onee_title fix">
								<h2>Your Information</h2>
							</div>
							<div class="mr_donate_step_onee_form fix">
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="first_name">First Name</label>
										<input type="text" class="form_input_field" name="first_name" id="first_name" />
									</div>
								</div>
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="last_name">Last Name</label>
										<input type="text" class="form_input_field" name="last_name" id="last_name"/>
									</div>
								</div>
								<div class="donate_step_chek fix col-sm-12">
									<div class="checkbox_wrapper fix">
										<input type="checkbox" id="anonymous_flag" name="anonymous_flag" >
										<span class="checked"></span>
									</div>
									<label for="anonymous_flag">Make My Donation Anonymous. </label>
								</div>
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="address">Address</label>
										<input type="text" class="form_input_field" name="address" id="address" />
									</div>
								</div>
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="city">City</label>
										<input type="text" class="form_input_field" name="city" id="city" />
									</div>
								</div>
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="state">State</label>
										<select name="state" id="state" class="form_select_field">
											<option value="AL">Alabama</option>
											<option value="AK">Alaska</option>
											<option value="AZ">Arizona</option>
											<option value="AR">Arkansas</option>
											<option value="CA">California</option>
											<option value="CO">Colorado</option>
											<option value="CT">Connecticut</option>
											<option value="DE">Delaware</option>
											<option value="DC">District Of Columbia</option>
											<option value="FL">Florida</option>
											<option value="GA">Georgia</option>
											<option value="HI">Hawaii</option>
											<option value="ID">Idaho</option>
											<option value="IL">Illinois</option>
											<option value="IN">Indiana</option>
											<option value="IA">Iowa</option>
											<option value="KS">Kansas</option>
											<option value="KY">Kentucky</option>
											<option value="LA">Louisiana</option>
											<option value="ME">Maine</option>
											<option value="MD">Maryland</option>
											<option value="MA">Massachusetts</option>
											<option value="MI">Michigan</option>
											<option value="MN">Minnesota</option>
											<option value="MS">Mississippi</option>
											<option value="MO">Missouri</option>
											<option value="MT">Montana</option>
											<option value="NE">Nebraska</option>
											<option value="NV">Nevada</option>
											<option value="NH">New Hampshire</option>
											<option value="NJ">New Jersey</option>
											<option value="NM">New Mexico</option>
											<option value="NY">New York</option>
											<option value="NC">North Carolina</option>
											<option value="ND">North Dakota</option>
											<option value="OH">Ohio</option>
											<option value="OK">Oklahoma</option>
											<option value="OR">Oregon</option>
											<option value="PA">Pennsylvania</option>
											<option value="RI">Rhode Island</option>
											<option value="SC">South Carolina</option>
											<option value="SD">South Dakota</option>
											<option value="TN">Tennessee</option>
											<option value="TX">Texas</option>
											<option value="UT">Utah</option>
											<option value="VT">Vermont</option>
											<option value="VA">Virginia</option>
											<option value="WA">Washington</option>
											<option value="WV">West Virginia</option>
											<option value="WI">Wisconsin</option>
											<option value="WY">Wyoming</option>
										</select>
									</div>
								</div>
								<div class="donate_step_left fix col-sm-6">
									<div class="form_input_area fix">
										<label for="zip">Zip/Postal code</label>
										<input type="text" class="form_input_field" name="zip" id="zip" />
									</div>
								</div>
								<div class="donate_step_left fix col-sm-12">
									<div class="form_input_area fix">
										<label for="email">Email</label>
										<input type="email" class="form_input_field" name="email" id="email" />
									</div>
								</div>
							</div>
							<!-- 
							<div class="donate_step_chek fix col-sm-12">
								<div class="checkbox_wrapper fix">
									<input type="checkbox" id="checkbox1" name="name">
									<span class="checked"></span>
								</div>
								<label for="">Get Campaign Updates to your inbox. </label>
							</div>
							<div class="donate_step_chek fix col-sm-12">
								<div class="checkbox_wrapper fix">
									<input type="checkbox" id="checkbox1" name="name">
									<span class="checked"></span>
								</div>
								<label for="">Save information for future donations. </label>
							</div>
							 -->
							<div class="form_input_area fix col-sm-12">
								<label for="description">Leave a Comment</label>
								<textarea class="textarea_tellstory" name="description" id="description" cols="30" rows="10"></textarea>
									
							</div>
							<div class="text-center dontae_conti_submit col-sm-12">
								<button type="submit" name="submit" id="submit" value="CONTINUE" class="strt_camp_step_conti">CONTINUE</button>
							</div>	
							</form>
						</div>					
					</div>
				</div>
			</form>
		</div>
		<div class="sidebar col-sm-6">
			<div class="sidebar-profile-image">
				<div class="profile-image">
					<img class="img-responsive" src="assets/images/susan-a-smith.jpg" alt="" />
				</div>
				<div class="profile-info col-xs-12">
					<h3>The Life of Susan A. Smith</h3>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
				</div>
			</div>
		
			<div class="sidebar_donate_range_content fix">
				<div class="sidebar_donate_range_left maktit_full">
					<div class="rangeslider">
						<input id="ex1" data-slider-id='ex1Slider' type="text" data-slider-min="0" data-slider-max="2500" data-slider-step="1" data-slider-value="1200"/>
					</div>
					<h4><b>$<span id="ex1SliderVal">1,200</span> Raised</b> of $2,500 by 667 backers</h4>
					
					<h4><b>27 DAYS left</b> for this campaign.</h4>
				</div>
				<!--<div class="sidebar_donate_range_right">
					<h3>View Current Supporters (667)</h3>
					<img src="assets/images/icon_people_group.png" alt="" />
				</div>-->
			</div>

			<div class="sidebar_donate_range_content fix">
					<div class="sidebar_donate_range_left maktit_full">
						<div class="row">
							<div class="col-sm-3">
								<img class="img-responsive" src="assets/images/logo_funeral.png" alt="" />
							</div>
							<div class="col-sm-7">
								<h3>Funeral Details</h3>
								<p><b>Funeral Location:</b> Dave�s Funeral Home*</p>
								<p><b>Funeral Date:</b> August 20th, 2017*</p>
								<p><b>Funeral Time:</b> 9:00 pm EST*</p>
								<span><i>*Check campaign updates below.</i></span>
							</div>
							<div class="col-sm-2 flush mobil_sotokoro">
								<a class="cal_btn" href="#"><img src="assets/images/cal_btn.png" alt="" /></a>
								<a class="map_btn" href="#"><img src="assets/images/map_btn.png" alt="" /> </a>
							</div>
						</div>
					</div>
					<!--<div class="sidebar_donate_range_right">
						<img src="assets/images/icon_campain_updates.png" alt="" />
						<h3>View Campaign Updates</h3>
					</div>-->
			</div>
			
			
		</div>
	</div>
</section> <!-- #profile-content ends -->

<?php 

require_once '_includes/footer.php';

?>