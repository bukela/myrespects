<?php 

require_once '_includes/header.php';

require_once 'classes/campaign_base.php';

$o_cb = new campaign_base();

$a_current_campaigns = $o_cb->get_current_campaigns_homepage();
?>
<section id="banner">
	<div class="container-fluid">
		<div class="row">
			<ul class="bxslider">
				<li class="slide bannerimage_slide" style="">
					<img src="assets/images/bg_banner2.jpg" />
					<div class="textbox col-sm-6">
						<div class="row">
							<div class="col-sm-10 pull-right">
								<div class="heading">
									<h2>GET HELP FUNDING A FUNERAL</h2>
									<h2 class="small"><a href="#">Start a campaign today...</a></h2>
								</div>
								<ul class="funeral-list">
									<li>Very easy to set up.</li>
									<li>Obituary &amp; funeral tools.</li>
									<li>No deadlines.</li>
									<li>24 hour support.</li>
								</ul>
								<a class="start-fund" href="#">start a fund now</a>
							</div>
						</div>
					</div>
				</li>
				<li class="slide bannerimage_slide" style="">
					<img src="assets/images/bg_banner2.jpg" />
					<div class="textbox col-sm-6">
						<div class="row">
							<div class="col-sm-10 pull-right">
								<div class="heading">
									<h2>GET HELP FUNDING A FUNERAL</h2>
									<h2 class="small">Start a campaign today...</h2>
								</div>
								<ul class="funeral-list">
									<li>Very easy to set up.</li>
									<li>Obituary &amp; funeral tools.</li>
									<li>No deadlines.</li>
									<li>24 hour support.</li>
								</ul>
								<a class="start-fund" href="#">start a fund now</a>
							</div>
						</div>
					</div>
				</li>
				<li class="slide bannerimage_slide" style="">
					<img src="assets/images/bg_banner2.jpg" />
					<div class="textbox col-sm-6">
						<div class="row">
							<div class="col-sm-10 pull-right">
								<div class="heading">
									<h2>GET HELP FUNDING A FUNERAL</h2>
									<h2 class="small">Start a campaign today...</h2>
								</div>
								<ul class="funeral-list">
									<li>Very easy to set up.</li>
									<li>Obituary &amp; funeral tools.</li>
									<li>No deadlines.</li>
									<li>24 hour support.</li>
								</ul>
								<a class="start-fund" href="#">start a fund now</a>
							</div>
						</div>
					</div>
				</li>
				<li class="slide bannerimage_slide" style="">
					<img src="assets/images/bg_banner2.jpg" />
					<div class="textbox col-sm-6">
						<div class="row">
							<div class="col-sm-10 pull-right">
								<div class="heading">
									<h2>GET HELP FUNDING A FUNERAL</h2>
									<h2 class="small">Start a campaign today...</h2>
								</div>
								<ul class="funeral-list">
									<li>Very easy to set up.</li>
									<li>Obituary &amp; funeral tools.</li>
									<li>No deadlines.</li>
									<li>24 hour support.</li>
								</ul>
								<a class="start-fund" href="#">start a fund now</a>
							</div>
						</div>
					</div>
				</li>
			</ul>
			<div class="banner-bottom">
			</div>
		</div>
	</div>
</section> <!-- #banner ends -->
<?php if ( isset( $a_current_campaigns['result'] ) && $a_current_campaigns['result'] == true ) { ?>
	<section class="cuurent_support-title"> <!-- .spl-title starts -->
		<div class="container">
			<div class="col-xs-12 text-center">
				<h1>CURRENT CAMPAIGNS</h1>
			</div>
		</div>
	</section> <!-- .spl-title ends -->
	<section id="support-campaign"> <!-- #support-campaign starts -->
		<div class="container">
			<div class="col-xs-12">
				<?php foreach ( $a_current_campaigns['data'] as $i_index => $a_campaign ) { ?>
					
					<?php if ( $i_index == 0 || $i_index == 4 ) { ?>
					<div class="row row-eq-height"> <!-- .row starts -->
					<?php } ?>
						<div class="campaign last bg-light col-sm-3"> <!-- .campaign starts -->
							<div class="image">
								<img class="img-responsive" src="<?php echo $a_campaign['image']; ?>" alt="" />
							</div>
							<div class="textbox">
								<h4><?php echo $a_campaign['title']; ?></h4>
								<p><?php echo $a_campaign['description']; ?></p>
							</div>
							<div class="more text-center">
								<p>$<span id="ex<?php echo $a_campaign['id']; ?>SliderVal"><?php echo !empty( $a_campaign['raised'] ) ? $a_campaign['raised'] : '0'; ?></span> Raised <small>of <?php echo $a_campaign['formatted_goal']; ?> USD</small></p>
							</div>
							<div class="rangeslider">
								<input id="ex<?php echo $a_campaign['id']; ?>" data-slider-id='ex<?php echo $a_campaign['id']; ?>Slider' type="text" data-slider-min="0" data-slider-max="<?php echo $a_campaign['goal']; ?>" data-slider-step="50" data-slider-value="<?php echo $a_campaign['raised']; ?>"/>
							</div>
							<div class="more text-center">
								<a href="/campaign.php?id=<?php echo $a_campaign['id']; ?>">+ VIEW CAMPAIGN</a>						
							</div>
							
							<script>
								$('#ex<?php echo $a_campaign['id']; ?>').slider({
									formatter: function(value) {
										return 'Current value: ' + value;
									}
								});
							</script>
						</div> <!-- .campaign ends --> 
					<?php if ( $i_index == 3 || $i_index == 7 ) { ?>
						</div> <!-- .row ends -->
					<?php } ?>
				<?php } ?>
			</div>
		</div>
	</section> <!-- #support-campaign ends -->
<?php } ?>
<div class="start_acmpain_titlea_area fix">
<h1><a style="color: inherit;" href="/start-campaign.php">Start a Campaign</a></h1>
</div>


<section id="tools_two"> <!-- #tools starts -->
	<img style="width:100%" src="assets/images/bg_ourtime.png" alt="" />
	<div class="tool_ara_content_wrapper fix">
		<div class="tool_ara_title fix">
			<div class="container">
				<div class="title col-xs-12">
					<h2>TOOLS THAT HELPED,  IN <span>Our Time</span> OF NEED <a href="#" id="backtotop"><img src="assets/images/up_arrow.png" alt="" /></a></h2>
				</div>
			</div>
		</div>
		<div class="tools-quote">
			<div class="container">
			    <div class="text">
    			    <div class="testibxslider">
        				<div class="text_testi">
        					<h4>"Their tools helped me contact friends and family, and made this sad time in my life much easier to manage, thank you."</h4>
        					<h6>-�Avery Family, California</h6>
        					<img src="assets/images/premium_stamp.png" alt="" />
        				</div>
        				<div class="text_testi">
        					<h4>"2Their tools helped me contact friends and family, and made this sad time in my life much easier to manage, thank you."</h4>
        					<h6>-�Avery Family, California2</h6>
        					<img src="assets/images/premium_stamp.png" alt="" />
        				</div>
        				<div class="text_testi">
        					<h4>"3Their tools helped me contact friends and family, and made this sad time in my life much easier to manage, thank you."</h4>
        					<h6>- Avery Family, California3</h6>
        					<img src="assets/images/premium_stamp.png" alt="" />
        				</div>
    				</div>
				</div>
				<img class="rightborder" src="assets/images/border_right.png" alt="" />
			</div>
			<img class="leftborder" src="assets/images/border_left.png" alt="" />
		</div>
	</div>
</section> <!-- #tools ends -->


<?php 

require_once '_includes/footer.php';

?>